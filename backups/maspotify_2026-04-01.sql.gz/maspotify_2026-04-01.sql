--
-- PostgreSQL database dump
--

\restrict IEyNgchqznkRi6yHNtv2yACLWBPIcFoFv7V3qa16vQyMYUdnbbw4otAh0rxD4b6

-- Dumped from database version 16.13
-- Dumped by pg_dump version 16.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: maspotify
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO maspotify;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: maspotify
--

COMMENT ON SCHEMA public IS '';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: playlist_tracks; Type: TABLE; Schema: public; Owner: maspotify
--

CREATE TABLE public.playlist_tracks (
    id integer NOT NULL,
    playlist_id integer,
    spotify_track_id text NOT NULL,
    isrc text,
    title text NOT NULL,
    artist text NOT NULL,
    added_by_spotify_id text,
    added_at timestamp with time zone,
    ai_facts text,
    genre text
);


ALTER TABLE public.playlist_tracks OWNER TO maspotify;

--
-- Name: playlist_tracks_id_seq; Type: SEQUENCE; Schema: public; Owner: maspotify
--

CREATE SEQUENCE public.playlist_tracks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.playlist_tracks_id_seq OWNER TO maspotify;

--
-- Name: playlist_tracks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: maspotify
--

ALTER SEQUENCE public.playlist_tracks_id_seq OWNED BY public.playlist_tracks.id;


--
-- Name: playlists; Type: TABLE; Schema: public; Owner: maspotify
--

CREATE TABLE public.playlists (
    id integer NOT NULL,
    spotify_id text NOT NULL,
    name text NOT NULL,
    number integer,
    url text,
    status text DEFAULT 'listened'::text,
    is_thematic boolean DEFAULT false,
    track_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now(),
    invite_url text,
    CONSTRAINT playlists_status_check CHECK ((status = ANY (ARRAY['listened'::text, 'active'::text, 'upcoming'::text])))
);


ALTER TABLE public.playlists OWNER TO maspotify;

--
-- Name: playlists_id_seq; Type: SEQUENCE; Schema: public; Owner: maspotify
--

CREATE SEQUENCE public.playlists_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.playlists_id_seq OWNER TO maspotify;

--
-- Name: playlists_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: maspotify
--

ALTER SEQUENCE public.playlists_id_seq OWNED BY public.playlists.id;


--
-- Name: ratings; Type: TABLE; Schema: public; Owner: maspotify
--

CREATE TABLE public.ratings (
    id integer NOT NULL,
    session_track_id integer,
    telegram_id bigint NOT NULL,
    rhymes integer,
    structure integer,
    style integer,
    charisma integer,
    vibe integer,
    rated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT ratings_charisma_check CHECK (((charisma >= 1) AND (charisma <= 5))),
    CONSTRAINT ratings_rhymes_check CHECK (((rhymes >= 1) AND (rhymes <= 5))),
    CONSTRAINT ratings_structure_check CHECK (((structure >= 1) AND (structure <= 5))),
    CONSTRAINT ratings_style_check CHECK (((style >= 1) AND (style <= 5))),
    CONSTRAINT ratings_vibe_check CHECK (((vibe >= 1) AND (vibe <= 5)))
);


ALTER TABLE public.ratings OWNER TO maspotify;

--
-- Name: ratings_id_seq; Type: SEQUENCE; Schema: public; Owner: maspotify
--

CREATE SEQUENCE public.ratings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ratings_id_seq OWNER TO maspotify;

--
-- Name: ratings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: maspotify
--

ALTER SEQUENCE public.ratings_id_seq OWNED BY public.ratings.id;


--
-- Name: session_participants; Type: TABLE; Schema: public; Owner: maspotify
--

CREATE TABLE public.session_participants (
    id integer NOT NULL,
    session_id integer,
    telegram_id bigint NOT NULL,
    joined_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.session_participants OWNER TO maspotify;

--
-- Name: session_participants_id_seq; Type: SEQUENCE; Schema: public; Owner: maspotify
--

CREATE SEQUENCE public.session_participants_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.session_participants_id_seq OWNER TO maspotify;

--
-- Name: session_participants_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: maspotify
--

ALTER SEQUENCE public.session_participants_id_seq OWNED BY public.session_participants.id;


--
-- Name: session_tracks; Type: TABLE; Schema: public; Owner: maspotify
--

CREATE TABLE public.session_tracks (
    id integer NOT NULL,
    session_id integer,
    spotify_track_id text NOT NULL,
    title text NOT NULL,
    artist text NOT NULL,
    album text,
    cover_url text,
    added_by_spotify_id text,
    "position" integer,
    vote_result text DEFAULT 'pending'::text,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT session_tracks_vote_result_check CHECK ((vote_result = ANY (ARRAY['pending'::text, 'keep'::text, 'drop'::text])))
);


ALTER TABLE public.session_tracks OWNER TO maspotify;

--
-- Name: session_tracks_id_seq; Type: SEQUENCE; Schema: public; Owner: maspotify
--

CREATE SEQUENCE public.session_tracks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.session_tracks_id_seq OWNER TO maspotify;

--
-- Name: session_tracks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: maspotify
--

ALTER SEQUENCE public.session_tracks_id_seq OWNED BY public.session_tracks.id;


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: maspotify
--

CREATE TABLE public.sessions (
    id integer NOT NULL,
    playlist_spotify_id text NOT NULL,
    playlist_name text NOT NULL,
    started_at timestamp with time zone DEFAULT now(),
    ended_at timestamp with time zone,
    status text DEFAULT 'active'::text,
    CONSTRAINT sessions_status_check CHECK ((status = ANY (ARRAY['active'::text, 'ended'::text])))
);


ALTER TABLE public.sessions OWNER TO maspotify;

--
-- Name: sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: maspotify
--

CREATE SEQUENCE public.sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sessions_id_seq OWNER TO maspotify;

--
-- Name: sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: maspotify
--

ALTER SEQUENCE public.sessions_id_seq OWNED BY public.sessions.id;


--
-- Name: spotify_tokens; Type: TABLE; Schema: public; Owner: maspotify
--

CREATE TABLE public.spotify_tokens (
    id integer NOT NULL,
    refresh_token text NOT NULL,
    access_token text NOT NULL,
    expires_at timestamp with time zone
);


ALTER TABLE public.spotify_tokens OWNER TO maspotify;

--
-- Name: spotify_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: maspotify
--

CREATE SEQUENCE public.spotify_tokens_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.spotify_tokens_id_seq OWNER TO maspotify;

--
-- Name: spotify_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: maspotify
--

ALTER SEQUENCE public.spotify_tokens_id_seq OWNED BY public.spotify_tokens.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: maspotify
--

CREATE TABLE public.users (
    id integer NOT NULL,
    telegram_id bigint NOT NULL,
    telegram_name text NOT NULL,
    spotify_id text,
    is_admin boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now(),
    telegram_username text
);


ALTER TABLE public.users OWNER TO maspotify;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: maspotify
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO maspotify;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: maspotify
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: votes; Type: TABLE; Schema: public; Owner: maspotify
--

CREATE TABLE public.votes (
    id integer NOT NULL,
    session_track_id integer,
    telegram_id bigint NOT NULL,
    vote text NOT NULL,
    voted_at timestamp with time zone DEFAULT now(),
    CONSTRAINT votes_vote_check CHECK ((vote = ANY (ARRAY['keep'::text, 'drop'::text])))
);


ALTER TABLE public.votes OWNER TO maspotify;

--
-- Name: votes_id_seq; Type: SEQUENCE; Schema: public; Owner: maspotify
--

CREATE SEQUENCE public.votes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.votes_id_seq OWNER TO maspotify;

--
-- Name: votes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: maspotify
--

ALTER SEQUENCE public.votes_id_seq OWNED BY public.votes.id;


--
-- Name: playlist_tracks id; Type: DEFAULT; Schema: public; Owner: maspotify
--

ALTER TABLE ONLY public.playlist_tracks ALTER COLUMN id SET DEFAULT nextval('public.playlist_tracks_id_seq'::regclass);


--
-- Name: playlists id; Type: DEFAULT; Schema: public; Owner: maspotify
--

ALTER TABLE ONLY public.playlists ALTER COLUMN id SET DEFAULT nextval('public.playlists_id_seq'::regclass);


--
-- Name: ratings id; Type: DEFAULT; Schema: public; Owner: maspotify
--

ALTER TABLE ONLY public.ratings ALTER COLUMN id SET DEFAULT nextval('public.ratings_id_seq'::regclass);


--
-- Name: session_participants id; Type: DEFAULT; Schema: public; Owner: maspotify
--

ALTER TABLE ONLY public.session_participants ALTER COLUMN id SET DEFAULT nextval('public.session_participants_id_seq'::regclass);


--
-- Name: session_tracks id; Type: DEFAULT; Schema: public; Owner: maspotify
--

ALTER TABLE ONLY public.session_tracks ALTER COLUMN id SET DEFAULT nextval('public.session_tracks_id_seq'::regclass);


--
-- Name: sessions id; Type: DEFAULT; Schema: public; Owner: maspotify
--

ALTER TABLE ONLY public.sessions ALTER COLUMN id SET DEFAULT nextval('public.sessions_id_seq'::regclass);


--
-- Name: spotify_tokens id; Type: DEFAULT; Schema: public; Owner: maspotify
--

ALTER TABLE ONLY public.spotify_tokens ALTER COLUMN id SET DEFAULT nextval('public.spotify_tokens_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: maspotify
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: votes id; Type: DEFAULT; Schema: public; Owner: maspotify
--

ALTER TABLE ONLY public.votes ALTER COLUMN id SET DEFAULT nextval('public.votes_id_seq'::regclass);


--
-- Data for Name: playlist_tracks; Type: TABLE DATA; Schema: public; Owner: maspotify
--

COPY public.playlist_tracks (id, playlist_id, spotify_track_id, isrc, title, artist, added_by_spotify_id, added_at, ai_facts, genre) FROM stdin;
4639	70	00bOuKgzbRkOHmgCAL7ChZ	\N	Zoning	The Bloody Beetroots, ZHU	1qzcdqlwqtm8lnthmvh2a70p9	2024-02-15 11:57:49+00	\N	electro house
2869	10	00xjqwQs0kTCw3yoCLupwD	\N	Reverse	James Lee	313neyxbfwxtbi2t52gjvliqxisa	2026-01-11 06:10:05+00	\N	k-rock
5027	89	00yD9lbY4zjHa1vFugKbgg	\N	For The Taking	Fox Stevenson	313neyxbfwxtbi2t52gjvliqxisa	2023-07-13 12:31:05+00	\N	drum and bass, dubstep, drumstep
3726	40	02846iBEHz7g1pFLvpRllW	\N	MUKANJYO	Survive Said The Prophet	1qzcdqlwqtm8lnthmvh2a70p9	2025-02-07 11:16:25+00	\N	anime, j-rock
3800	43	02JIdsrod3BYucThfUFDUX	\N	Le Festin	Camille, Michael Giacchino	31433d6i5sfekboj5hr2fjtnwe7u	2025-01-11 07:50:39+00	\N	french jazz
4354	62	040IEiMlCYxNYcW5Sd8L5Z	\N	No Nein	1tbsp, Mietze Conte	31ghi62vkgnlb4wqr6muaisx7ldi	2024-04-12 13:15:50+00	\N	lo-fi house
3261	23	04w57GO5p1763E44KQ8AKB	\N	My Name (feat. Eminem & Nate Dogg)	Xzibit, Eminem, Nate Dogg	31pd6hnytykuevog22xwj5yn2qjy	2025-09-07 05:32:03+00	\N	west coast hip hop, gangster rap, g-funk, old school hip hop, hardcore hip hop, hip hop
4691	72	05tGmdz9dVZ4yGqz4YJdPK	\N	La Intención	Christian Nodal, Peso Pluma	1qzcdqlwqtm8lnthmvh2a70p9	2024-02-01 12:46:01+00	\N	banda, ranchera, mariachi, norteño, música mexicana, grupera
4797	79	077AjPx334yMPROFwWZOUb	\N	Balearic Mornings (Rave Mix)	Reinier Zonneveld, Oliver Heldens, HI-LO	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-31 09:32:02+00	\N	techno, acid techno, hard techno, tekno, minimal techno
3491	31	07wsDQjOfhVDIz8mizvNnF	\N	Kiss of Death - BADVOID Remix	JEANIE, DOIL, TINYKVT, BADVOID	313neyxbfwxtbi2t52gjvliqxisa	2025-05-02 07:01:22+00	\N	riddim, dubstep, deathstep
4154	54	08Es2lfNCjngJa9a7WQktW	\N	Hell Of It	Kasabian	31pd6hnytykuevog22xwj5yn2qjy	2024-07-19 08:45:51+00	\N	britpop, indie, indie rock
4032	50	08FrL2S2aHgXbexMJge9js	\N	Where Does the DJ Go?	Kylie Minogue	31ghi62vkgnlb4wqr6muaisx7ldi	2024-09-21 08:08:34+00	\N	dance pop
3431	29	09iJcJvLSE4kiGtuY4RTQg	\N	Dimension	Wolfmother	31ghi62vkgnlb4wqr6muaisx7ldi	2025-05-29 16:36:26+00	\N	stoner rock
4085	52	09mtCMVyjY5De8EvakhW37	\N	Done - Going Deeper Remix	Sasha Holiday, Going Deeper	1qzcdqlwqtm8lnthmvh2a70p9	2024-09-07 07:15:15+00	\N	future house
4950	85	0AQ1twwDGVlIVpcHDkGkXD	\N	Sleepless	D.O.D	313neyxbfwxtbi2t52gjvliqxisa	2023-09-23 02:51:51+00	\N	house
3873	45	0AfFbb64vnVzqS0gZa4TY9	\N	PURE CODEI (feat. Yamê)	Gazo, Yamê	1qzcdqlwqtm8lnthmvh2a70p9	2024-12-08 06:20:31+00	\N	french rap, french r&b, pop urbaine, drill
3361	26	0B8drtTSp68pZdkmVrG9ZA	\N	Twinz (Deep Cover 98) (feat. Fat Joe)	Big Pun, Fat Joe	313neyxbfwxtbi2t52gjvliqxisa	2025-07-09 14:52:25+00	\N	east coast hip hop, old school hip hop, hardcore hip hop
4715	74	0BvYYottMAxdwdzDnPWei4	\N	Moonshine	Panuma, Nina Carr	1qzcdqlwqtm8lnthmvh2a70p9	2024-01-15 09:10:58+00	\N	deep house
30	2	4Gc1SJ7eN65EcTvDMPcCzz	\N	YaYaYa	RY X	313neyxbfwxtbi2t52gjvliqxisa	2026-03-24 12:34:50+00	"YaYaYa" — это трек от австралийского артиста RY X, который стал особенно популярным благодаря своему атмосферному звучанию и глубоким текстам. \n\nИнтересно, что RY X изначально планировал записать этот трек в более меланхоличном ключе, но в итоге музыка сама подтолкнула его к более яркому и жизнеутверждающему звучанию. 🎶 \n\nКстати, RY X также известен своим проектом The Acid, который сочетает элементы электронной музыки с живыми инструментами. Это классный пример того, как один артист может экспериментировать в разных жанрах! 🌌	indie folk
25	2	56Dpy24WiCzKoNl1xwsDYf	\N	HIT THE FLOOR	Monument Of A Memory	313neyxbfwxtbi2t52gjvliqxisa	2026-03-24 12:34:13+00	"HIT THE FLOOR" — это не просто трек, а настоящая энергетическая бомба! 💥 \n\nОснователи Monument Of A Memory записали его в студии, находящейся в старом заброшенном здании, и говорят, что звук старых труб и эха добавил особую атмосферу к записи. 🎤 \n\nИнтересно, что в тексте песни есть ссылка на классический трек от Linkin Park, что делает "HIT THE FLOOR" еще более крутым для фанатов нью-метала! 🤘	metalcore, deathcore
14	2	7zkLpY72g6lKQbiHDqri1S	\N	Sunrise	Norah Jones	1qzcdqlwqtm8lnthmvh2a70p9	2026-03-18 05:09:29+00	"Sunrise" – это одна из самых известных баллад Норы Джонс, и она была написана в соавторстве с её другом. Интересно, что песня стала хитом благодаря случайной записи на одном из её концертов, где публика была просто в восторге от исполнения!\n\nНа Grammy Awards в 2003 году "Sunrise" получила номинацию на "Лучшее женское вокальное поп-исполнение", что подтвердило статус Норы как одной из самых ярких певиц того времени 🎤✨.\n\nКроме того, эта песня является частью её второго альбома "Feels Like Home", который стал не менее успешным, чем дебютный, и укрепил её репутацию настоящей звезды джаза и соула! 🎶🌅	jazz pop
35	2	2Zk7GbM6pfouSACjW1gtcE	\N	Pull Up	Collect 200	31ghi62vkgnlb4wqr6muaisx7ldi	2026-03-31 11:36:18+00	Трек "Pull Up" от Collect 200 стал настоящим хитом благодаря своему заразительному ритму и необычному использованию семплов. 🎶\n\nИнтересно, что песня была написана всего за одну ночь, когда артист вдохновился атмосферой вечеринки, на которой он оказался. 🔥\n\nТакже, "Pull Up" быстро взлетел в чарты благодаря тренду в TikTok, где пользователи начали создавать под него забавные танцы и челленджи! 🎉	trap
4584	69	016z46SJwcRosW9Xb8JKmF	\N	scars	Novulent	31433d6i5sfekboj5hr2fjtnwe7u	2024-02-21 16:35:33+00	\N	shoegaze
3169	21	0C6ZNMoXKeRe0eF0rNDHtT	\N	DIVIDE - Acoustic	PhaseOne, Intervals, Micah Martin	313neyxbfwxtbi2t52gjvliqxisa	2025-09-26 12:52:34+00	\N	dubstep, deathstep, riddim, bass music
4931	84	0C8mZZLRaf2X8MKCVkbMbC	\N	Heaven Shall Burn	Imminence	313neyxbfwxtbi2t52gjvliqxisa	2023-09-26 13:35:15+00	\N	metalcore, metal
3048	16	0DLjcGTmH2NV9AjzecAGT6	\N	Breathe Into Me	Red	1qzcdqlwqtm8lnthmvh2a70p9	2025-11-19 23:41:57+00	\N	christian rock, christian alternative rock
4266	58	0DiWol3AO6WpXZgp0goxAV	\N	One More Time	Daft Punk	1qzcdqlwqtm8lnthmvh2a70p9	2024-05-30 10:06:54+00	\N	french house, electronic, electro
3009	15	0E5KbePTY8cZvkI4z0Qwcp	\N	Tom & Jerry	Enoo Napa, Phila De Giant	313neyxbfwxtbi2t52gjvliqxisa	2025-11-22 08:18:01+00	\N	afro tech, afro house, tribal house, 3 step
3085	17	0EW1auxcM42hjotYkgjPDn	\N	Rusalki	Krasa Rosa	1qzcdqlwqtm8lnthmvh2a70p9	2025-11-12 19:55:52+00	\N	organic house, melodic house, progressive house
2797	8	0Ens69V11FD5lmo3docNED	\N	Break My World 2026	JETFIRE, Meital De Razon	313neyxbfwxtbi2t52gjvliqxisa	2026-02-11 10:02:36+00	\N	big room, electro house
4864	81	0HAr4QR1xI8nwC7VfzYidu	\N	Dead Memories	Slipknot	313neyxbfwxtbi2t52gjvliqxisa	2023-10-19 13:21:38+00	\N	nu metal, metal, alternative metal, rap metal, heavy metal
2965	13	0I3q5fE6wg7LIfHGngUTnV	\N	Ms. Jackson	Outkast	313neyxbfwxtbi2t52gjvliqxisa	2025-12-11 12:35:14+00	\N	southern hip hop, hip hop
3773	42	0If2JUJWMTdpFcvVYQ6dwI	\N	Flightless Bird, American Mouth - Twilight Soundtrack Version	Iron & Wine	1qzcdqlwqtm8lnthmvh2a70p9	2025-01-11 19:11:13+00	\N	indie folk
3708	39	0JmQv0FaamddsrDj0G3SqU	\N	La fessée	Claire Laffut	31ghi62vkgnlb4wqr6muaisx7ldi	2025-02-14 11:15:21+00	\N	french indie pop, french pop, french house
3019	15	0LfJkvPNCNEMLpZJgDQiV1	\N	The Wonder of You	Elvis Presley	1qzcdqlwqtm8lnthmvh2a70p9	2025-11-25 07:17:38+00	\N	rockabilly, rock and roll
3120	19	0MSC5BYWcNhcBNNYORXZyj	\N	Lying Is the Most Fun a Girl Can Have Without Taking Her Clothes Off	Panic! At The Disco	1qzcdqlwqtm8lnthmvh2a70p9	2025-10-25 01:56:28+00	\N	emo
4308	60	02vHDkck9uQjZnYuEpGoOK	\N	Заводной апельсин	Обстоятельства	31pd6hnytykuevog22xwj5yn2qjy	2024-05-17 08:35:25+00	\N	rock
4839	80	03tBrjFI5Vbu807AewP8HO	\N	Сердце из пластика	KOMMO	313neyxbfwxtbi2t52gjvliqxisa	2023-10-23 05:05:46+00	\N	pop
4798	79	04zVcQYcV9iPQVsQVVDkKD	\N	Human	Apashe, Wasiu	313neyxbfwxtbi2t52gjvliqxisa	2023-10-31 00:25:01+00	\N	dubstep
2796	8	05e5yq2u2CmxOGL6h3x8Sa	\N	BUCKET HELMET	BOI WHAT	313neyxbfwxtbi2t52gjvliqxisa	2026-02-11 10:02:06+00	\N	phonk
3163	20	05fbTFpcc7ZvJ13MKpmFqx	\N	Любовь	Бонд с кнопкой	31ghi62vkgnlb4wqr6muaisx7ldi	2025-10-22 10:56:28+00	\N	pop
3383	27	08MM0MZ2oeChIHj98AvfRO	\N	Last Night I Watched Myself Sleep and I Saw Things That I Wish I Could Forget	Aurora View	1qzcdqlwqtm8lnthmvh2a70p9	2025-06-18 09:25:40+00	\N	shoegaze
3616	36	0BAlC3pMYdzmk0DQ3pYus2	\N	Boom Boom	2WEI, Bri Bryant	31ghi62vkgnlb4wqr6muaisx7ldi	2025-03-11 10:20:40+00	\N	electronic
4113	53	0D7BSKbkJrF47wcVj0A8Jj	\N	Поколение Z	Stigmata	313neyxbfwxtbi2t52gjvliqxisa	2024-07-30 11:34:51+00	\N	metalcore
4502	67	0H9QStpQ5xwHPnVKmqloGk	\N	All Good Things (Come To An End)	Nelly Furtado	31pd6hnytykuevog22xwj5yn2qjy	2024-03-03 23:30:24+00	\N	pop
3742	41	0HTWavNi7vymHNML1laLoU	\N	Таити	Людмил Огурченко	313neyxbfwxtbi2t52gjvliqxisa	2025-01-30 23:41:36+00	\N	folk
4125	53	0HcpaE1ifqieH7INetrdJc	\N	Рассвета не будет	Куок, SEDA PARTIZ	1qzcdqlwqtm8lnthmvh2a70p9	2024-08-05 11:47:55+00	\N	rap
3147	20	0HeEz3p1yVoAIOjAULJzrD	\N	Foaming	Day We Ran	31pd6hnytykuevog22xwj5yn2qjy	2025-10-13 08:47:02+00	\N	indie
4705	73	0ITqNqYxI5l0uhrmYm6ayG	\N	So Low	Shiloh Dynasty, Sublab	1qzcdqlwqtm8lnthmvh2a70p9	2024-01-22 20:37:40+00	\N	downtempo
2976	14	0MRBhe9wjupFpmdKGh3Xhp	\N	Можно я с тобой	AP$ENT	31ghi62vkgnlb4wqr6muaisx7ldi	2025-12-04 13:17:06+00	\N	rap
4281	59	0MuDhSPR7wZxIBHDk6NDoD	\N	Vento Alecrim	Gilsons	1qzcdqlwqtm8lnthmvh2a70p9	2024-05-22 17:23:11+00	\N	new mpb, mpb
3839	43	0Ph6L4l8dYUuXFmb71Ajnd	\N	Livin' la Vida Loca	Ricky Martin	313neyxbfwxtbi2t52gjvliqxisa	2025-01-16 13:55:32+00	\N	latin pop
4999	88	0RwiVl8S1BFgRgu4YK5w9m	\N	October	deadmau5	1qzcdqlwqtm8lnthmvh2a70p9	2023-07-18 22:34:13+00	\N	edm, progressive house, dubstep
3505	31	0SsqcxoWkXtgyvO0HZuzaT	\N	Malika	Hiatus Kaiyote	1qzcdqlwqtm8lnthmvh2a70p9	2025-05-02 07:38:53+00	\N	neo soul, indie soul, alternative r&b
3943	48	0UN5OvKlbg06LnZyVk48ll	\N	Loungin (Who Do Ya Luv) - Remix	LL COOL J, Total	31433d6i5sfekboj5hr2fjtnwe7u	2024-09-25 08:28:24+00	\N	old school hip hop, east coast hip hop
3783	42	0a6jzYgYdtGJIoj5NtflVE	\N	Die alone	HYUKOH	31ghi62vkgnlb4wqr6muaisx7ldi	2025-01-24 11:16:51+00	\N	k-rock, k-ballad
4488	66	0azv85p0Zjg27D8SfJdSnE	\N	Calorific	Feed Me	1qzcdqlwqtm8lnthmvh2a70p9	2024-03-15 21:13:13+00	\N	dubstep, electro house
4370	62	0bFJJI9u8LhJRs2uYBLg1s	\N	Killa	Geoxor	1qzcdqlwqtm8lnthmvh2a70p9	2024-04-15 12:56:24+00	\N	dubstep, future bass
3666	38	0ceW5TkemJUEmJERavfqQq	\N	wonderful life (feat. Dani Filth)	Bring Me The Horizon, Dani Filth	313neyxbfwxtbi2t52gjvliqxisa	2025-02-18 12:58:29+00	\N	metalcore, emo, rock, screamo, post-hardcore
4242	57	0jY829pCMnstlNtaE72vSB	\N	Decadence	Disturbed	313neyxbfwxtbi2t52gjvliqxisa	2024-06-16 06:16:29+00	\N	metal, nu metal, alternative metal, rap metal, hard rock
3735	41	0kEZlJh4mK1QRfb3CT5LPk	\N	Kill Yourself (Part III)	$uicideboy$	31433d6i5sfekboj5hr2fjtnwe7u	2025-01-24 15:26:49+00	\N	emo rap, horrorcore, cloud rap, trap metal, underground hip hop
3455	30	0mROspyBziPHPyxTPFvKaH	\N	God Is A Weapon	Falling In Reverse, Marilyn Manson	313neyxbfwxtbi2t52gjvliqxisa	2025-05-21 03:03:16+00	\N	emo, rap metal
4161	54	0maCwhZTO3PybhSiQcsjAf	\N	G.O.A.T.	Polyphia	1qzcdqlwqtm8lnthmvh2a70p9	2024-07-21 00:51:53+00	\N	math rock, djent, progressive metal, progressive rock
4746	76	0ncHMpFGT96pis5pi4iJDm	\N	Until the World Goes Cold	Trivium	313neyxbfwxtbi2t52gjvliqxisa	2023-12-20 15:53:13+00	\N	metalcore, metal, heavy metal
4926	84	0pJDnLRe38vYS1zAhpsESV	\N	Children - Edit Mix	Tinlicker, Robert Miles	1qzcdqlwqtm8lnthmvh2a70p9	2023-09-26 11:18:01+00	\N	melodic house, progressive house, melodic techno
3229	22	0ptNPzAaewqAlfoQFCoiLT	\N	Mercia	Thornhill	313neyxbfwxtbi2t52gjvliqxisa	2025-09-26 10:30:34+00	\N	metalcore, djent, shoegaze
4495	66	0r0bbdctse0ntHvKagcdsL	\N	This Could Be Us - Franky Nuts & Oliverse Remix	Virtual Riot, Modestep, FRANK ZUMMO, Franky Nuts, Oliverse	313neyxbfwxtbi2t52gjvliqxisa	2024-03-16 11:13:41+00	\N	dubstep, riddim, deathstep, bass music, future bass, edm, dub, drumstep
4378	63	0r3nMF80NSIuPIxeod4aoG	\N	Beso (Fruta Fresca)	Wakyin, Carlos Vives	1qzcdqlwqtm8lnthmvh2a70p9	2024-04-03 19:14:18+00	\N	afro house, latin house
5006	88	0sYalxPCX8OcwdYZcFzRgN	\N	Intuition	Jewel	1qzcdqlwqtm8lnthmvh2a70p9	2023-07-20 12:47:50+00	\N	singer-songwriter
4840	80	0sZ7125n1GTxvrq0anThNy	\N	The Shower Scene	Ice Nine Kills	313neyxbfwxtbi2t52gjvliqxisa	2023-10-23 06:36:05+00	\N	metalcore, metal
2821	9	0t7LcUic4qolMCysPrKeAd	\N	Die, Die My Darling	Metallica	313neyxbfwxtbi2t52gjvliqxisa	2026-01-29 00:29:25+00	\N	metal, thrash metal, rock, heavy metal, hard rock
2921	12	0t8h41n20K1BkByBDqWAoN	\N	Dance with Somebody	Mando Diao	313neyxbfwxtbi2t52gjvliqxisa	2025-12-16 12:59:09+00	\N	swedish pop
4600	69	0trHOzAhNpGCsGBEu7dOJo	\N	N.Y. State of Mind	Nas	31pd6hnytykuevog22xwj5yn2qjy	2024-02-23 18:45:26+00	\N	old school hip hop, east coast hip hop, hip hop
3284	24	0yuAWlxq59xT3agQ965OxE	\N	Sunsetz	Cigarettes After Sex	31pd6hnytykuevog22xwj5yn2qjy	2025-08-20 10:18:17+00	\N	dream pop
3097	17	13HwHS7iqH42L1BzDcIowI	\N	Lost and Left Behind	Imminence	313neyxbfwxtbi2t52gjvliqxisa	2025-11-14 00:34:38+00	\N	metalcore, metal
3911	47	14boA065HMHWvqyPPEeN4y	\N	I don’t even speak spanish lol - feat. Rio Santana, Judah, Andrez Babii	XXXTENTACION, Rio Santana, Judah, Andrez Babii	31433d6i5sfekboj5hr2fjtnwe7u	2024-10-20 12:43:48+00	\N	emo rap
4969	86	18ty2CvaOkyz3WOD3DkqNk	\N	CALYPSO	ero808, NXSTY	313neyxbfwxtbi2t52gjvliqxisa	2023-09-15 13:37:53+00	\N	bass house
4889	82	0O45fw2L5vsWpdsOdXwNAR	\N	SexyBack (feat. Timbaland)	Justin Timberlake, Timbaland	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-09 09:22:40+00	\N	pop
3631	36	0OE33CpFvSN8m1cN1Zi72u	\N	Самолёты - Acoustic version	Женя Трофимов, Роман Рудыка	1qzcdqlwqtm8lnthmvh2a70p9	2025-03-13 12:11:22+00	\N	folk
2770	7	0PeQFcr1VnU0BTrKD2MvcA	\N	Suburban Sociopath	Buggpint	31ghi62vkgnlb4wqr6muaisx7ldi	2026-02-17 17:23:25+00	\N	punk
4531	68	0Tcy9RRWvcnqepvmVcqv05	\N	Black Out Days - Subtronics Remix	Phantogram, Subtronics	1qzcdqlwqtm8lnthmvh2a70p9	2024-02-26 14:42:47+00	\N	dubstep
4428	65	0bkTdkWwGk3OGFX0afD3Wj	\N	Mystery Lady	Masego, Don Toliver	31pd6hnytykuevog22xwj5yn2qjy	2024-03-19 15:11:01+00	\N	r&b
3330	25	0eRtOlUsMueyPH3jIjkZrX	\N	Music Sounds Better With Me	Young Franco, Master Peace, BCBC	31pd6hnytykuevog22xwj5yn2qjy	2025-07-18 07:52:48+00	\N	house
3888	46	0eaVIYo2zeOaGJeqZ5TwYz	\N	No Pole	Don Toliver	31433d6i5sfekboj5hr2fjtnwe7u	2024-11-14 05:05:47+00	\N	rap
4673	72	0jeRoIMD1LHhUkQEbjkXQv	\N	Where Do We Go Now? (Music from Lil Nas X: Long Live Montero)	Lil Nas X	31pd6hnytykuevog22xwj5yn2qjy	2024-01-27 23:24:50+00	\N	soundtrack
2896	11	0lrjqMt3JDyRTnqmONDwx7	\N	Первый снег	Moralny Kodex	1qzcdqlwqtm8lnthmvh2a70p9	2025-12-23 22:56:27+00	\N	rock
3118	18	0rk5ahfnID1fRBlJiawxwB	\N	Вечно молодой	Артем Пора Домой, Сергей Бобунец	1qzcdqlwqtm8lnthmvh2a70p9	2025-11-07 08:55:05+00	\N	pop
4302	60	0s8FWN0lVIpCfMETG81tOI	\N	Твоя любовь манила (Slowed Version)	Тахмина Умалатова	1qzcdqlwqtm8lnthmvh2a70p9	2024-05-13 15:46:18+00	\N	r&b
3011	15	0uIGzK6ukV0A5yWoCxPkRL	\N	California King Bed	Rihanna	1qzcdqlwqtm8lnthmvh2a70p9	2025-11-22 18:13:19+00	\N	pop
4010	50	0xXjCtTg7slLvEA3fuHSfR	\N	Гуляй без меня	КРИМ ПЛИН	1qzcdqlwqtm8lnthmvh2a70p9	2024-08-27 14:59:00+00	\N	pop
3584	35	11iIikXxC6NP0Ma8vMD27x	\N	Alien Blues	Vundabar	31ghi62vkgnlb4wqr6muaisx7ldi	2025-03-20 16:18:56+00	\N	indie
4074	52	16Cn3glUv9usZKmSepH6XG	\N	I'll Been Waiting - Radio Edit	Dear David	1qzcdqlwqtm8lnthmvh2a70p9	2024-09-07 21:16:07+00	\N	pop
4643	71	19YD6ICSnydge6cjk0Tfnz	\N	Делай, что хочется	Гости Гаррисона	1qzcdqlwqtm8lnthmvh2a70p9	2024-02-04 00:10:48+00	\N	pop
3867	45	19fKJrO9XdOf6Xla2QHecO	\N	Run Your Mouth	The Marías	31pd6hnytykuevog22xwj5yn2qjy	2024-12-02 08:09:54+00	\N	bedroom pop
5008	88	1A0tHVc6xznJHSA6vE5QDG	\N	Fading (Toxic Wraith & PKAY Remix)	Dirty Palm, Toxic Wraith, PKAY	1qzcdqlwqtm8lnthmvh2a70p9	2023-07-21 11:42:51+00	\N	melbourne bounce, future house, bass house, bounce
4411	64	1CcLA0eaauck34YEIrvAAq	\N	When We Were Young (The Logical Song)	David Guetta, Kim Petras	31pd6hnytykuevog22xwj5yn2qjy	2024-03-26 17:02:03+00	\N	edm
3442	29	1Chjeu7itQhIgeL1HpVDuN	\N	Antimatter	Silent Planet	313neyxbfwxtbi2t52gjvliqxisa	2025-05-30 09:48:22+00	\N	metalcore, djent, deathcore, metal, post-hardcore
4249	57	1DbdQp5dwuawBGmxSHw6Fr	\N	Empire (Let Them Sing)	Bring Me The Horizon	313neyxbfwxtbi2t52gjvliqxisa	2024-06-16 05:45:43+00	\N	metalcore, emo, rock, screamo, post-hardcore
2870	10	1DidXplJuVK5wLrLpUupwM	\N	Driven By My Heart	Venjent	313neyxbfwxtbi2t52gjvliqxisa	2026-01-11 06:12:08+00	\N	drum and bass
3757	41	1H05u9gUX86XDLcSF75PZD	\N	Box Chevy	Yelawolf, Rittz The Rapper	31ghi62vkgnlb4wqr6muaisx7ldi	2025-01-31 11:35:36+00	\N	country hip hop, southern hip hop
3223	22	1A5V1sxyCLpKJezp75tUXn	\N	Closing Time	Semisonic	31pd6hnytykuevog22xwj5yn2qjy	2025-09-26 08:20:45+00	\N	rock
2985	14	1D8YNsgMfBjkJucqbWgN7r	\N	Юность в сапогах	Конец фильма	1qzcdqlwqtm8lnthmvh2a70p9	2025-12-04 17:06:16+00	\N	rock
4337	61	1E2WB9LAgRDZIpNf5lCk41	\N	Still Mine	Ashley Singh	31pd6hnytykuevog22xwj5yn2qjy	2024-05-01 21:55:48+00	\N	r&b
4564	69	1FFxPYBh43TJIubiD6FLxQ	\N	What Winds Are Driving Me?	UBEL, Nikolai Mishchenko	313neyxbfwxtbi2t52gjvliqxisa	2024-02-19 02:14:07+00	\N	downtempo
4088	52	1N7hcSjMbz8XMK878vH3eI	\N	I Loved You	Dj Sava, Irina Rimes	1qzcdqlwqtm8lnthmvh2a70p9	2024-09-07 07:14:58+00	\N	europop
3827	43	1SFh43No2uLaVZARFnCfy2	\N	Aloy's Theme - Forbidden West (feat. Julie Elven) - (From "Horizon Forbidden West" Video Game Soundtrack)	Joris de Man, Julie Elven	1qzcdqlwqtm8lnthmvh2a70p9	2025-01-12 08:47:09+00	\N	soundtrack
4182	55	1Sgj10byiGzPpI2IrXSFEn	\N	Protect Ya Neck	Wu-Tang Clan	31pd6hnytykuevog22xwj5yn2qjy	2024-06-22 11:23:57+00	\N	old school hip hop, east coast hip hop, hip hop, gangster rap, hardcore hip hop
3489	31	1U8eAAGHamravF1o9kqthG	\N	Nothing to hide	BLVKES, DIIA	313neyxbfwxtbi2t52gjvliqxisa	2025-05-02 07:01:13+00	\N	dark r&b
3135	19	1VDTID3slfUZKPFCA1FdFA	\N	Fantasmas	Ambar Lucid	31ghi62vkgnlb4wqr6muaisx7ldi	2025-10-30 14:02:19+00	\N	latin indie, bedroom pop
3225	22	1XXXlTqAXwhsa9OQ95Wu8a	\N	Red Moon	Dance With the Dead, Elliot Sloan	313neyxbfwxtbi2t52gjvliqxisa	2025-09-26 10:30:01+00	\N	synthwave, darkwave, vaporwave
4322	61	1ZLqz5HjWXvx5Tjq8z8DZB	\N	Best Way 2 Die (feat. Jin Dogg, LEX & YOUNGBONG)	DJ CHARI, DJ TATSUKI, Jin Dogg, LEX, YOUNGBONG	313neyxbfwxtbi2t52gjvliqxisa	2024-04-24 05:13:51+00	\N	j-rap, hip hop, j-r&b
3300	24	1ZgMsA55GIY7ICkQh5MILA	\N	Space Song	Beach House	31ghi62vkgnlb4wqr6muaisx7ldi	2025-08-20 16:04:24+00	\N	dream pop
4216	56	1bqmaIBGwlo4MtrAxjRDHB	\N	Helvegen	Wardruna	31ghi62vkgnlb4wqr6muaisx7ldi	2024-06-22 12:44:54+00	\N	neofolk, celtic, ambient folk, medieval, folk metal, folk
4064	52	1c0zagykmGPDYuxJeDqZhJ	\N	World Hold on (Children of the Sky) [Radio Edit]	Bob Sinclar, Steve Edwards	1qzcdqlwqtm8lnthmvh2a70p9	2024-09-07 21:16:07+00	\N	french house, disco house
3900	46	1cC17T8gB7aaQz905lkzl4	\N	аудио	ста2тика	1qzcdqlwqtm8lnthmvh2a70p9	2024-11-24 07:36:44+00	\N	experimental hip hop
3660	38	1erXDiGCnmUQvG6DZRqpuM	\N	Electric Indigo	The Paper Kites	31pd6hnytykuevog22xwj5yn2qjy	2025-02-17 12:12:51+00	\N	indie folk
4109	53	1o4Pf2GIMDCD7ifIM2yI77	\N	Last to Know	Three Days Grace	313neyxbfwxtbi2t52gjvliqxisa	2024-07-30 11:32:00+00	\N	post-grunge, rock
4533	68	1pTw2cNrp9L3esxLAvWnN2	\N	Separate Ways (Worlds Apart) [2023 Remaster]	Journey	1qzcdqlwqtm8lnthmvh2a70p9	2024-02-26 14:53:18+00	\N	aor, classic rock
3280	24	1pXrR5Y9OgcIV2JEAl2lCB	\N	I Kissed A Girl	Katy Perry	1qzcdqlwqtm8lnthmvh2a70p9	2025-08-18 03:39:11+00	\N	pop
3077	17	1qxDqObTMZ9Tu4WZvFxecE	\N	Divine Descent	Daeya	1qzcdqlwqtm8lnthmvh2a70p9	2025-11-12 19:48:17+00	\N	riddim, dubstep, deathstep, bass music, melodic bass
4381	63	1uAOCTevGnyKIDbgZdOCnE	\N	Voilà	Barbara Pravi	31pd6hnytykuevog22xwj5yn2qjy	2024-04-04 19:53:18+00	\N	chanson, french pop
2793	8	26zlKMewpn1ZrcwvyXxuf7	\N	I Know That's Not You	Kayou.	313neyxbfwxtbi2t52gjvliqxisa	2026-02-11 10:01:09+00	\N	lo-fi beats, lo-fi
3018	15	28285KFbyCq8sJofn58qlD	\N	Love Train	The O'Jays	1qzcdqlwqtm8lnthmvh2a70p9	2025-11-25 07:11:03+00	\N	philly soul, classic soul, motown, quiet storm, soul
4728	75	28HDdeeD8DVWPdzb4POb5r	\N	Chalice - Llord Remix	Donae'o, Belly, Llord	1qzcdqlwqtm8lnthmvh2a70p9	2024-01-09 14:58:52+00	\N	uk funky, funky house, azonto, grime, bassline, afroswing
5053	91	2BirbjcIsHDyoNTfzAfkyG	\N	Satisfied	Catching Flies	1qzcdqlwqtm8lnthmvh2a70p9	2023-06-25 18:57:48+00	\N	downtempo
4902	83	2CsmiVZVVtrHiPOBU0ZW0d	\N	Insatiable	ONEIL, Aize, Danna Max	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-04 19:02:34+00	\N	slap house, g-house
4197	55	2DlHlPMa4M17kufBvI2lEN	\N	Chop Suey!	System Of A Down	31pd6hnytykuevog22xwj5yn2qjy	2024-06-24 09:58:21+00	\N	nu metal, metal, alternative metal, rap metal, rock
3825	43	2EWYKoT4eF5HkzB6cxw1H1	\N	Rey's Theme (From "Star Wars: Episode VII - The Force Awakens")	John Williams, Robert Ziegler, Slovak National Symphony Orchestra, Members of the Slovak Philharmonic Choir	1qzcdqlwqtm8lnthmvh2a70p9	2025-01-12 08:47:09+00	\N	soundtrack, score
3289	24	2Foc5Q5nqNiosCNqttzHof	\N	Get Lucky (Radio Edit) [feat. Pharrell Williams and Nile Rodgers]	Daft Punk, Pharrell Williams, Nile Rodgers	31pd6hnytykuevog22xwj5yn2qjy	2025-08-20 10:33:25+00	\N	french house, electronic, electro
4190	55	2Foc5Q5nqNiosCNqttzHof	\N	Get Lucky (Radio Edit) [feat. Pharrell Williams and Nile Rodgers]	Daft Punk, Pharrell Williams, Nile Rodgers	31pd6hnytykuevog22xwj5yn2qjy	2024-06-24 11:56:01+00	\N	french house, electronic, electro
4933	84	1VKHnTaWuxQ46CsmNM7X39	\N	Золотая Лада - From "Лада Голд"	Noggano	313neyxbfwxtbi2t52gjvliqxisa	2023-09-26 23:42:05+00	\N	electronic
2949	13	1XcLpdgsBLMsJMaZkVvUri	\N	Pora Sotunda	The Mystery Of The Bulgarian Voices, Lisa Gerrard	31ghi62vkgnlb4wqr6muaisx7ldi	2025-12-07 05:42:40+00	\N	classical
3079	17	1YYOaYzlrtkBbDKaF6a1vL	\N	Спит моя любовь	polnalyubvi	1qzcdqlwqtm8lnthmvh2a70p9	2025-11-12 19:50:14+00	\N	pop
3690	39	1euDTbMNRPNfKd8zZz4zTT	\N	Give In to Me	Michael Jackson	31pd6hnytykuevog22xwj5yn2qjy	2025-02-11 10:34:30+00	\N	pop
4699	73	1jDJFeK9x3OZboIAHsY9k2	\N	I'm Still Standing	Elton John	1qzcdqlwqtm8lnthmvh2a70p9	2024-01-22 20:11:56+00	\N	pop
2902	11	1n3SuHjXopzqXFQmZtX34C	\N	Синий иней	Инна Маликова & Новые Самоцветы	31pd6hnytykuevog22xwj5yn2qjy	2025-12-24 08:48:24+00	\N	pop
4623	70	1nginMHZwOYjtYDndhCeY2	\N	Прощание	Три дня дождя, MONA	1qzcdqlwqtm8lnthmvh2a70p9	2024-02-13 13:51:37+00	\N	indie
2769	7	1pGdxOrtNjMfQJqpjOIP4L	\N	Circus	CR33PIA	31ghi62vkgnlb4wqr6muaisx7ldi	2026-02-17 17:04:15+00	\N	electronic
4861	81	1qDrWA6lyx8cLECdZE7TV7	\N	Somebody That I Used To Know	Gotye, Kimbra	313neyxbfwxtbi2t52gjvliqxisa	2023-10-17 16:32:40+00	\N	pop
3392	27	1s9i7W8zx7Nxx78MUIsvjV	\N	Outro	M83	31ghi62vkgnlb4wqr6muaisx7ldi	2025-07-03 12:18:57+00	\N	electronic
4780	78	1ssH8g0sRC9euIT32MEhxg	\N	The Way Out (feat. Bertie Scott)	Egzod, Bertie Scott	313neyxbfwxtbi2t52gjvliqxisa	2023-11-09 00:02:19+00	\N	future bass
2853	10	1vq1KgeHuDaS3qyhwfpF0P	\N	How Could I Ever (feat. Shungudzo)	KUU, Alex Metric, Riton, Shungudzo	31pd6hnytykuevog22xwj5yn2qjy	2026-01-07 10:46:19+00	\N	electronic
3510	32	1vshpIwqnDxM0NNtvWwymh	\N	Сон	polnalyubvi, TRITIA	313neyxbfwxtbi2t52gjvliqxisa	2025-04-18 12:44:42+00	\N	downtempo
3125	19	29fc1RinBg7npe9NtS4yDO	\N	Oxygen	Porch Light	1qzcdqlwqtm8lnthmvh2a70p9	2025-10-26 20:56:21+00	\N	indie
4684	72	2BOYIwkVduDJ1ZENq8jiy8	\N	Разная дрянь	CAPTOWN	31pd6hnytykuevog22xwj5yn2qjy	2024-01-31 12:03:26+00	\N	rock
3454	30	2G0g0aPbH53A0FNvmaNUEN	\N	CODEINE	ero808, NXSTY	1qzcdqlwqtm8lnthmvh2a70p9	2025-05-20 20:01:11+00	\N	bass house
4014	50	2JuasWPUodaUxf5nwNpciQ	\N	Nutshell	Alice In Chains	31pd6hnytykuevog22xwj5yn2qjy	2024-08-29 13:02:37+00	\N	grunge, post-grunge
3268	24	2MuWTIM3b0YEAskbeeFE1i	\N	Master Of Puppets	Metallica	313neyxbfwxtbi2t52gjvliqxisa	2025-08-01 08:02:36+00	\N	metal, thrash metal, rock, heavy metal, hard rock
3375	27	2MvsVQpUmRZo7WUr9aJzgR	\N	Not Giving Up	Kai Wachi, Point North	313neyxbfwxtbi2t52gjvliqxisa	2025-06-17 12:17:24+00	\N	dubstep, deathstep, riddim, melodic bass, edm, bass music
4972	87	2Q8CRg2ldlbhTL5NUp2vm5	\N	Takes All Night - Dance With The Dead Remix	LeBrock, Dance With the Dead	1qzcdqlwqtm8lnthmvh2a70p9	2023-07-31 09:51:50+00	\N	synthwave
2980	14	2SUpC3UgKwLVOS2FtZif9N	\N	Carry on Wayward Son	Kansas	313neyxbfwxtbi2t52gjvliqxisa	2025-12-04 13:24:23+00	\N	classic rock, progressive rock, aor
4865	81	2SpGXD7EbexndFmmThrnsy	\N	Deer Dance	System Of A Down	313neyxbfwxtbi2t52gjvliqxisa	2023-10-19 13:21:45+00	\N	nu metal, metal, alternative metal, rap metal, rock
3563	34	2SyDT5CfAldvmMQtPs8LzW	\N	Don't Need You	Bullet For My Valentine	313neyxbfwxtbi2t52gjvliqxisa	2025-03-28 01:29:55+00	\N	metalcore, metal
4419	64	2T4RSe7bYhPfznZAZyxowE	\N	Fly with me	ꉈꀧ꒒꒒ꁄꍈꍈꀧ꒦ꉈ ꉣꅔꎡꅔꁕꁄ	31ghi62vkgnlb4wqr6muaisx7ldi	2024-03-29 14:42:54+00	\N	anime, j-pop
4662	71	2ZWmmrWUgDBcPSLihBMvhg	\N	Baddadan (feat. IRAH, Flowdan, Trigga & Takura)	Chase & Status, Bou, Flowdan, IRAH, Trigga, Takura	1qzcdqlwqtm8lnthmvh2a70p9	2024-02-08 11:20:50+00	\N	drum and bass, jungle
3215	22	2Zk7BtZYIc2TrTEPC6WDy3	\N	Моя любовь	Глава II	31ghi62vkgnlb4wqr6muaisx7ldi	2025-09-25 14:17:19+00	\N	darkwave, southern gothic, cold wave
4329	61	2bXnmDlRL4bD9xJG2VWOvI	\N	I Against I - 2006 Digital Remaster	Massive Attack, Mos Def	1qzcdqlwqtm8lnthmvh2a70p9	2024-04-24 13:39:18+00	\N	trip hop, downtempo
2759	6	2ciYYljvXw3vJdWi6hkEfS	\N	Divide	The Plot In You	313neyxbfwxtbi2t52gjvliqxisa	2026-03-03 02:41:31+00	\N	metalcore
3869	45	2ekUq4YPZLifZOCQvCE0zq	\N	Тот самый день	тоскарабочегокласса	31ghi62vkgnlb4wqr6muaisx7ldi	2024-12-07 15:59:41+00	\N	post-punk
4499	67	2epld0M5QscJKscFIXXatP	\N	Stalker	Ship Wrek, Sondr	1qzcdqlwqtm8lnthmvh2a70p9	2024-03-03 19:05:45+00	\N	stutter house, bass house
4221	56	2fTu6v5JuGkv7MeoiiBtDb	\N	Узорами	CRASPORE, Chernoburkv	31ghi62vkgnlb4wqr6muaisx7ldi	2024-06-22 12:45:05+00	\N	witch house
4983	87	2hU9S9x1uciKpOS5BqWqeq	\N	Bullet Boy (Vox) - 2006 Digital Remaster	Massive Attack	1qzcdqlwqtm8lnthmvh2a70p9	2023-08-15 05:13:50+00	\N	trip hop, downtempo
3744	41	2ieoSK4rDjBZmbDSyaLUxh	\N	Eternal Vespers	Satellite Empire	313neyxbfwxtbi2t52gjvliqxisa	2025-01-30 23:47:29+00	\N	chillstep, melodic bass, future bass
5029	90	2nWTLLc9t2mLudvz9h0Ne5	\N	Phoenix Down - Zardonic Remix	The Unguided, Zardonic	313neyxbfwxtbi2t52gjvliqxisa	2023-07-02 14:38:22+00	\N	melodic death metal, metalcore, metal
3682	38	2qXyz9BCFlgKwO13wcsgnC	\N	Bandit	The Vaccines	31ghi62vkgnlb4wqr6muaisx7ldi	2025-02-28 08:23:59+00	\N	indie, indie rock
3082	17	2qdPYroaAHBxnk6VdO0yOk	\N	Sincerity (You Were Never There For Me)	Butcher Babies, Saliva, Harper, Lyric Noel, Judge & Jury	1qzcdqlwqtm8lnthmvh2a70p9	2025-11-12 19:53:51+00	\N	groove metal, metal
4880	82	2rbwykhMXDPAJQvyW3iHyz	\N	Always In My Head	Denis Kenzo, Whiteout	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-09 08:43:47+00	\N	trance, progressive trance
4496	66	2szSlDeK03Qjjkg4rDI8kC	\N	We're Not Alone - VIP	Virtual Riot	313neyxbfwxtbi2t52gjvliqxisa	2024-03-16 11:13:41+00	\N	dubstep, riddim, deathstep, bass music, future bass, edm, dub, drumstep
4632	70	2tK2zyeckIbbjNfUCpkcSV	\N	To the End (La Comedie) - 2012 Remaster	Blur, Françoise Hardy	31pd6hnytykuevog22xwj5yn2qjy	2024-02-14 20:29:29+00	\N	britpop, madchester, alternative rock
2888	11	2uFaJJtFpPDc5Pa95XzTvg	\N	Let It Snow! Let It Snow! Let It Snow!	Dean Martin	31433d6i5sfekboj5hr2fjtnwe7u	2025-12-23 13:03:06+00	\N	christmas, adult standards, big band, swing music
3517	32	2udGjDmpK1dH9VGyw7nrei	\N	Cocaine	Eric Clapton	31pd6hnytykuevog22xwj5yn2qjy	2025-04-24 08:41:24+00	\N	blues, blues rock, classic rock
3474	30	2vwDjFZGma27ITt4lOpSDD	\N	Baby - NXSTY & RYA Remix	Habstrakt, NXSTY, RYA	1qzcdqlwqtm8lnthmvh2a70p9	2025-05-23 11:12:50+00	\N	bass house, g-house, dubstep, bassline
3763	42	2xYhNQcBqh8OLdujEh5kPt	\N	King Size Snicka	Shawnna, Lstreetz, Lil Keisha	31pd6hnytykuevog22xwj5yn2qjy	2024-12-22 10:06:55+00	\N	southern hip hop
3613	36	2zYSX6VrJLcLhGKydo5asu	\N	Awen	Eluveitie	31ghi62vkgnlb4wqr6muaisx7ldi	2025-03-11 10:14:36+00	\N	folk metal, symphonic metal, melodic death metal, medieval metal, power metal, celtic, metal, celtic rock, medieval, folk
3107	18	2NuErDYiDV2LWUQcpBuU9d	\N	This Is My World	Esterly, Austin Jenckes	313neyxbfwxtbi2t52gjvliqxisa	2025-11-07 02:27:54+00	\N	pop
3144	19	2OBV9xYIRF1FsToNOBhwK6	\N	Пауза как судороги	Azar Strato, BATO	31ghi62vkgnlb4wqr6muaisx7ldi	2025-11-07 08:28:44+00	\N	electronic
3851	44	2OQmAU1rXizFeY3ageqplE	\N	Straight Up	THEY.	1qzcdqlwqtm8lnthmvh2a70p9	2024-12-15 07:29:34+00	\N	r&b
3603	35	2S4HEo4LCcIbU1AcEQ4RQZ	\N	4EVA	KAYTRAMINÉ, Aminé, KAYTRANADA, Pharrell Williams	31pd6hnytykuevog22xwj5yn2qjy	2025-03-21 10:08:29+00	\N	hip hop
4724	75	2U4Cvtx2hHiUzLUJLaA2UN	\N	Выходи играть в снежки	The Hatters	313neyxbfwxtbi2t52gjvliqxisa	2024-01-08 15:02:42+00	\N	folk
5010	88	2ciBUaOe7aNU9iitq6PiOH	\N	Одиночество, спи	Амели на Мели	1qzcdqlwqtm8lnthmvh2a70p9	2023-07-21 19:17:00+00	\N	pop
2855	10	2dOyXepBUuUHVZI3nVnwkU	\N	Cold - Live	Jonathan Roy, Kim Richardson	31pd6hnytykuevog22xwj5yn2qjy	2026-01-07 10:57:19+00	\N	r&b
4123	53	2enPRFda84VE2wtI8c86Uf	\N	Always Forever	Cults	31ghi62vkgnlb4wqr6muaisx7ldi	2024-08-01 10:13:01+00	\N	indie
2958	13	2gJjzxZ2r8T7dijZ0eDqcG	\N	Вороны	Нервы	313neyxbfwxtbi2t52gjvliqxisa	2025-12-11 12:12:34+00	\N	emo
3917	47	2gQYziDV5cSTRSqr6akzi5	\N	Take A Step Back	Ski Mask The Slump God, XXXTENTACION	31433d6i5sfekboj5hr2fjtnwe7u	2024-10-23 06:42:43+00	\N	rap
4349	62	2hUD7sLIXsLKJ0M1iSNOvg	\N	Ливин ла вида лока	БАЗАР	31ghi62vkgnlb4wqr6muaisx7ldi	2024-04-12 13:10:37+00	\N	latin
3041	16	2jQ1P0aGT4WkNyJCeoQnb9	\N	PUNK TACTICS	Joey Valence & Brae	31ghi62vkgnlb4wqr6muaisx7ldi	2025-11-19 08:51:33+00	\N	punk
4036	50	2vsLYLa6KiNGgba36bVQhF	\N	Миражи - hehehe cover	Кружок хора	31ghi62vkgnlb4wqr6muaisx7ldi	2024-09-21 08:09:30+00	\N	folk
3014	15	300YN8ebGB90nDuzgz0f3O	\N	Killer Queen	Queen	1qzcdqlwqtm8lnthmvh2a70p9	2025-11-22 18:15:47+00	\N	classic rock, rock, glam rock
4767	78	31Rwwh2kKCxExVeYRlGOWu	\N	Broccoli Fuck	GPF, Riot Shift	313neyxbfwxtbi2t52gjvliqxisa	2023-11-06 08:39:15+00	\N	frenchcore, hardcore, speedcore, hardstyle, hardcore techno, gabber
2782	7	36p4ZdYx0S12JdAdTJSCDP	\N	On and On	Repiet, Julia Kleijn	1qzcdqlwqtm8lnthmvh2a70p9	2026-02-25 07:57:20+00	\N	stutter house
4867	81	31mzt4ZV8C0f52pIz1NSwd	\N	Shut up My Moms Calling (Sped up)	Hotel Ugly	313neyxbfwxtbi2t52gjvliqxisa	2023-10-21 03:23:08+00	\N	pop
3265	24	32OlwWuMpZ6b0aN2RZOeMS	\N	Uptown Funk (feat. Bruno Mars)	Mark Ronson, Bruno Mars	313neyxbfwxtbi2t52gjvliqxisa	2025-07-19 12:58:21+00	\N	funk
4124	53	39MK3d3fonIP8Mz9oHCTBB	\N	Annihilate (Spider-Man: Across the Spider-Verse) (Metro Boomin & Swae Lee, Lil Wayne, Offset)	Metro Boomin, Swae Lee, Lil Wayne, Offset	31ghi62vkgnlb4wqr6muaisx7ldi	2024-08-01 10:15:22+00	\N	hip hop
2808	8	3CBoWhq9cd7WGQZ9EDQVnn	\N	Under and Over It	Five Finger Death Punch	313neyxbfwxtbi2t52gjvliqxisa	2026-02-11 10:53:49+00	\N	metal, groove metal, heavy metal, hard rock, rock
4874	82	3CXql9eVPsaNkGKSOfhme8	\N	Star Wars (Main Theme) [Arr. Johansson/Preisinger]	John Williams, The Philharmonic Brass, Alex Johansson	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-09 08:33:50+00	\N	soundtrack, score
3482	31	3FI0iAAAjmR31xpZEwbdys	\N	Circle With Me	Spiritbox	313neyxbfwxtbi2t52gjvliqxisa	2025-04-30 13:00:43+00	\N	metalcore, djent, metal
4441	65	3FQOmo61pO1ZnBT26d6WLQ	\N	VAMPIR (feat. Oli Sykes of Bring Me The Horizon)	IC3PEAK, Oli Sykes, Bring Me The Horizon	31ghi62vkgnlb4wqr6muaisx7ldi	2024-03-21 08:46:48+00	\N	witch house
5061	91	3G6f32IgEKsInHsy2J4r5J	\N	Fire Away (with Kid Harpoon)	Skrillex, Kid Harpoon	1qzcdqlwqtm8lnthmvh2a70p9	2023-06-25 19:59:56+00	\N	dubstep, edm, electro, electronic
3181	21	3GiJq4AQK7324mfIQbpiTf	\N	Custer	Slipknot	31pd6hnytykuevog22xwj5yn2qjy	2025-10-03 09:10:16+00	\N	nu metal, metal, alternative metal, rap metal, heavy metal
3006	14	3LDkLpuxQlEuEiZmkxpr8S	\N	Far From Any Road	The Handsome Family	1qzcdqlwqtm8lnthmvh2a70p9	2025-12-04 18:10:01+00	\N	southern gothic, alt country, americana
3247	23	3OXmhiea3f9ToNU5DcljSx	\N	deep blue - Holow Remix	Jadu Jadu, TAMBALA, Theodor Black, HOLOW	1qzcdqlwqtm8lnthmvh2a70p9	2025-09-04 21:01:04+00	\N	lo-fi house
2776	7	3QQCSu2OmDumj8Xi7Bm6p1	\N	ULTRARHYTHM	電音部, Hylen, 桜乃美々兎 (CV: 小坂井祐莉絵), 水上 雛 (CV: 大森日雅), 犬吠埼紫杏 (CV: 長谷川玲奈)	31ghi62vkgnlb4wqr6muaisx7ldi	2026-02-20 05:50:32+00	\N	future bass, j-dance
4167	55	3RptaQ5Xb8WvtpItZ2f9Hi	\N	Snuff	Slipknot	31pd6hnytykuevog22xwj5yn2qjy	2024-06-13 11:28:53+00	\N	nu metal, metal, alternative metal, rap metal, heavy metal
4319	60	3T1iTo0YKYh07qOex9a144	\N	i said it	almogfx, rivoices	1qzcdqlwqtm8lnthmvh2a70p9	2024-05-19 08:01:37+00	\N	witch house, electroclash, dark ambient
4635	70	3ThCPINLVGtNGFhxLC4slT	\N	I Only Have Eyes For You	Scott Bradlee's Postmodern Jukebox, Sunny Holiday	1qzcdqlwqtm8lnthmvh2a70p9	2024-02-15 09:18:24+00	\N	swing music, jazz pop, electro swing
2829	9	3U9gogDStAfWxSm91PJuxb	\N	South Of Heaven	Slayer	313neyxbfwxtbi2t52gjvliqxisa	2026-01-29 06:55:59+00	\N	thrash metal, metal, speed metal, heavy metal, groove metal, death metal
4887	82	3V2cgvvI483DKomiZBYsAA	\N	Bangarang (feat. Sirah)	Skrillex, Sirah	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-09 09:20:58+00	\N	dubstep, edm, electro, electronic
4076	52	3YLd8c9lOFNQox4n51F9Vf	\N	This Could Be Love (feat. Delaney Jane) - Radio Edit	Borgeous, Shaun Frank, Delaney Jane	1qzcdqlwqtm8lnthmvh2a70p9	2024-09-07 21:16:07+00	\N	big room, edm
4716	74	3ZmcHSwZo7trtIHYmJVjMF	\N	My Inner Island - Original Mix	The Blizzard, Omnia	1qzcdqlwqtm8lnthmvh2a70p9	2024-01-15 09:12:14+00	\N	trance, progressive trance
4966	86	3eIn815wa0Ry7M0nTk38Ce	\N	Без Тебя - Punchman Remix	Stim Axel, Punchman	313neyxbfwxtbi2t52gjvliqxisa	2023-09-01 05:45:55+00	\N	drum and bass
2920	12	3gnXGXCngLKAgDXEKPggSu	\N	Mayibuye - Giorgio Bassetti Remix	Enoo Napa, Kuhle, Giorgio Bassetti	313neyxbfwxtbi2t52gjvliqxisa	2025-12-16 12:53:19+00	\N	afro tech, afro house, tribal house, 3 step
3450	30	3iTgpxcDmPDMw0n9IJYG3S	\N	Apologies	Three Days Grace	313neyxbfwxtbi2t52gjvliqxisa	2025-05-13 00:14:22+00	\N	post-grunge, rock
2881	11	3nAp4IvdMPPWEH9uuXFFV5	\N	Underneath the Tree	Kelly Clarkson	31ghi62vkgnlb4wqr6muaisx7ldi	2025-12-23 12:21:14+00	\N	christmas
4842	80	3oy3m2ppYCBQEB6ZQrdigZ	\N	Jealous	MAXPVNK, Fatyzzz	313neyxbfwxtbi2t52gjvliqxisa	2023-10-23 23:08:51+00	\N	phonk, brazilian phonk
4341	61	3xVmdUM5hgmLYzndh8FMz7	\N	FEEL	Tonic Walter	31pd6hnytykuevog22xwj5yn2qjy	2024-05-02 13:14:35+00	\N	melodic house, deep house
3202	22	40ROAtBj7soL5rbqXQjU4k	\N	Drama	Jordan Adetunji	1qzcdqlwqtm8lnthmvh2a70p9	2025-09-19 18:22:29+00	\N	sexy drill
3270	24	40rvBMQizxkIqnjPdEWY1v	\N	Down with the Sickness	Disturbed	313neyxbfwxtbi2t52gjvliqxisa	2025-08-01 08:10:27+00	\N	metal, nu metal, alternative metal, rap metal, hard rock
2838	9	418UFQyQAk6qukmov5uHlr	\N	Temperatura	Andor Gabriel, Jerome Sydor	1qzcdqlwqtm8lnthmvh2a70p9	2026-02-04 09:08:08+00	\N	afro house, afro tech
3890	46	41J6fcsioFDdh410It3BUt	\N	MICHELIN CYPHER	Epik High	31ghi62vkgnlb4wqr6muaisx7ldi	2024-11-15 14:09:53+00	\N	k-rap, k-pop, k-ballad
4981	87	45PTrr4FJEnZjWVr280Sm5	\N	Эпизод VII: Разбуди меня	Ермак!, Affinage	313neyxbfwxtbi2t52gjvliqxisa	2023-08-09 02:05:12+00	\N	post-hardcore
4156	54	47FkzJm1bUaIc0OaGZvslL	\N	Great Adventures	Boldy James, The Alchemist	31ghi62vkgnlb4wqr6muaisx7ldi	2024-07-20 13:16:30+00	\N	jazz rap, boom bap, alternative hip hop, experimental hip hop
3295	24	3JvKfv6T31zO0ini8iNItO	\N	Another Love	Tom Odell	31ghi62vkgnlb4wqr6muaisx7ldi	2025-08-20 16:03:04+00	\N	indie
3552	33	3VUP6pr3ZnzbQZdnViVhIg	\N	Горький шоколад	Tutsi	313neyxbfwxtbi2t52gjvliqxisa	2025-04-16 23:43:03+00	\N	pop
3723	40	3XUjWdiSk2K1XdZnvhmFn5	\N	Бананылопалабомба	Горячие Головы	1qzcdqlwqtm8lnthmvh2a70p9	2025-02-07 11:16:25+00	\N	punk
3368	27	3ZrfBZASzUdMCEaG7osALe	\N	Я твой номер один	Dima Bilan	1qzcdqlwqtm8lnthmvh2a70p9	2025-06-10 20:24:17+00	\N	pop
3211	22	3a9In4yQrJJXwuphaloccU	\N	Ты живёшь на вулкане	Привет	31ghi62vkgnlb4wqr6muaisx7ldi	2025-09-25 14:03:00+00	\N	rock
3155	20	3d5Y1ihomIzuDN6opIhzHG	\N	Изоляция - OST «Мир кораблей»	TRITIA, polnalyubvi	313neyxbfwxtbi2t52gjvliqxisa	2025-10-17 05:25:38+00	\N	soundtrack
4358	62	3kozQ6hJ1QAQtvj6I8uhwK	\N	Дичь	Ivan Dorn	1qzcdqlwqtm8lnthmvh2a70p9	2024-04-15 09:16:45+00	\N	pop
3490	31	3pwcjjyy68yOd3YdfjxoDS	\N	Никаких Сумерек	Sula Fray	313neyxbfwxtbi2t52gjvliqxisa	2025-05-02 07:01:18+00	\N	emo
4567	69	3qlo1ADbzd7XtCGkjqVgOT	\N	PSYCHO	BYNX, Jade Elliott	313neyxbfwxtbi2t52gjvliqxisa	2024-02-19 13:56:51+00	\N	trap
4240	56	3qrB4YgsUHpmm3JVbp9aVL	\N	Маяк	Обстоятельства	31ghi62vkgnlb4wqr6muaisx7ldi	2024-06-22 12:45:43+00	\N	rock
4114	53	3qrENWg2HIYb1cdeSU8lva	\N	Тень (feat. Женя Мильковский)	Multiverse, Женя Мильковский	313neyxbfwxtbi2t52gjvliqxisa	2024-07-30 11:34:53+00	\N	electronic
4508	67	474uVhyGgK5MtY9gMcDgGl	\N	It's Called: Freefall	Rainbow Kitten Surprise	31ghi62vkgnlb4wqr6muaisx7ldi	2024-03-04 12:54:49+00	\N	indie
3384	27	484PtV8vBj0RucaNmwLow4	\N	Numb	ХИМИЯ	1qzcdqlwqtm8lnthmvh2a70p9	2025-06-18 09:34:29+00	\N	metal
3060	17	49vIvmsneQwxyFTdmCQzmV	\N	テレフォン・ナンバー	Junko Ohashi	1qzcdqlwqtm8lnthmvh2a70p9	2025-11-11 15:15:29+00	\N	city pop, kayōkyoku, j-pop
5041	90	4BsN2VLlvd3BBJCt7gpwkc	\N	Iris in the Dark	Just A Gent, McCall	313neyxbfwxtbi2t52gjvliqxisa	2023-07-05 23:12:00+00	\N	future bass
4670	72	4DEakFTIhXT6JFyCsQUffd	\N	The Party (This Is How We Do It)	Joe Stone, Montell Jordan	1qzcdqlwqtm8lnthmvh2a70p9	2024-01-26 11:35:30+00	\N	future house
4525	67	4FHSM9uehI2DtSWtzYORNV	\N	Heaven	Blanke, Rival, KC	313neyxbfwxtbi2t52gjvliqxisa	2024-03-09 11:14:05+00	\N	melodic bass, future bass, dubstep, edm
4704	73	4FYXh0MJf1aCu7RNadVuhK	\N	Kill The Lights	Curbi, Sarah de Warren	1qzcdqlwqtm8lnthmvh2a70p9	2024-01-22 20:35:54+00	\N	future house, bass house
3305	25	4ISgMfSWEuwVRj76YPVopn	\N	Give in to you	Rezz, Virtual Riot, One True God	313neyxbfwxtbi2t52gjvliqxisa	2025-07-16 07:12:59+00	\N	edm, dubstep
2950	13	4IydMf0i20TL6et0yBg29n	\N	The Unknowing	Jfarrari	31ghi62vkgnlb4wqr6muaisx7ldi	2025-12-07 05:46:42+00	\N	darkwave, post-punk, cold wave
3208	22	4JV3BjszeEUD1bTTcx9hdx	\N	ecdysis	Deftones	31pd6hnytykuevog22xwj5yn2qjy	2025-09-25 10:02:59+00	\N	nu metal, alternative metal, rap metal, shoegaze, rock
4786	78	3oByO94xgLnworeBgkCsGo	\N	Wish	Diplo, Trippie Redd	31433d6i5sfekboj5hr2fjtnwe7u	2023-11-14 14:05:03+00	\N	moombahton
3516	32	4K7jd5Wm09iF9xum3gfExb	\N	Cherry Wine	Nas, Amy Winehouse	31pd6hnytykuevog22xwj5yn2qjy	2025-04-24 08:33:19+00	\N	old school hip hop, east coast hip hop, hip hop
4286	59	4LO0iMEDBw0YeW4lP3NeLO	\N	I Will	Devault	313neyxbfwxtbi2t52gjvliqxisa	2024-05-23 00:20:12+00	\N	stutter house
4211	56	4LsDzfEbDV3oRUpeTEExjr	\N	Pink Nightmares	Infected Mushroom	31ghi62vkgnlb4wqr6muaisx7ldi	2024-06-22 12:44:43+00	\N	psytrance, trance
3927	47	4PaI8I6lpyzCf5WPzn0VeH	\N	The Light at the End of the Tunnel for $9.99 a Month	$uicideboy$	1qzcdqlwqtm8lnthmvh2a70p9	2024-11-03 07:28:17+00	\N	emo rap, horrorcore, cloud rap, trap metal, underground hip hop
3572	34	4R8Az4O82MrpdLLV4PNJeY	\N	Say It	Veela, Nomyn	1qzcdqlwqtm8lnthmvh2a70p9	2025-03-28 07:16:37+00	\N	chillstep, liquid funk, drum and bass
4421	64	4SkmZvciMZmMinCeEA7g5L	\N	4 to the Floor (feat. Nikol Apatini)	HUGEL, Stefy De Cicco, Hugo Cantarra, Nikol Apatini	1qzcdqlwqtm8lnthmvh2a70p9	2024-03-30 22:17:04+00	\N	latin house, afro house, techengue
3016	15	4T5SR1krNuVLOnxSjYb8nW	\N	Fun, Fun, Fun	The Beach Boys	1qzcdqlwqtm8lnthmvh2a70p9	2025-11-25 06:59:25+00	\N	baroque pop
2736	5	4VmiSWsMVZ25tbf2HErZtC	\N	Your Idol (KPop Demon Hunters)	Our Last Night	313neyxbfwxtbi2t52gjvliqxisa	2026-03-11 11:08:04+00	\N	post-hardcore, metalcore
3394	28	4WQrG3ke074wTes10aLPBT	\N	Primetime	JAŸ-Z, Kanye West	31pd6hnytykuevog22xwj5yn2qjy	2025-06-02 22:38:30+00	\N	hip hop, east coast hip hop, rap
3433	29	4aK4bJInGOV0Skp8uYrWuE	\N	Pale Blue Eyes	Lucy Rose	31ghi62vkgnlb4wqr6muaisx7ldi	2025-05-29 16:40:05+00	\N	ambient folk
2909	12	4bz7uB4edifWKJXSDxwHcs	\N	Galvanize	The Chemical Brothers	313neyxbfwxtbi2t52gjvliqxisa	2025-12-14 11:01:37+00	\N	big beat, alternative dance, electronic, breakbeat
3629	36	4cBwqUTlK8Limcu48qzGMC	\N	Silver Lining	Passenger 10	1qzcdqlwqtm8lnthmvh2a70p9	2025-03-13 12:11:22+00	\N	progressive house, melodic house, melodic techno
4373	62	4dmFo5VmijuePqQqgHvLHa	\N	Falling in Love	No Mana, vowl., Leyla Diamondi	1qzcdqlwqtm8lnthmvh2a70p9	2024-04-16 08:16:50+00	\N	electro house
4739	76	4dmNvD0IYQB64tJU8XlgvP	\N	Turn It Up	Dirty Palm	1qzcdqlwqtm8lnthmvh2a70p9	2023-12-18 16:45:24+00	\N	melbourne bounce, future house, bass house, bounce
3786	42	4dpyQS3snl4BsyEE3uSTwh	\N	Fate Of The Faithful	Greta Van Fleet	31ghi62vkgnlb4wqr6muaisx7ldi	2025-01-24 11:21:58+00	\N	rock
4020	50	4efIWmOTzLswZOCli4CHg1	\N	Венский конвертик	Б.А.У.	313neyxbfwxtbi2t52gjvliqxisa	2024-09-08 23:36:49+00	\N	melodic death metal
4895	82	4eh9RtXedraKvJzJSDUBhR	\N	MAGNETIZE	Ethan Ross, Free Flow Flava	313neyxbfwxtbi2t52gjvliqxisa	2023-10-10 00:07:27+00	\N	phonk, trap metal
3829	43	4gzcl0yqLPlXWvytu7O8Gp	\N	One Summer's Day (The Name of Life) - English Version / from 'Spirited Away'	Joe Hisaishi, Royal Philharmonic Orchestra, Grace Davidson	1qzcdqlwqtm8lnthmvh2a70p9	2025-01-12 08:47:09+00	\N	japanese classical, anime
3099	18	4hp4cs1fKConq0Cmr4luW9	\N	All The Things She Said (Culture Shock Version)	Culture Shock, Sarah de Warren	1qzcdqlwqtm8lnthmvh2a70p9	2025-11-04 09:28:08+00	\N	drum and bass, liquid funk
3004	14	4jwFFTbrgZhtSN7UEsQq8Q	\N	Put A Little Love In Your Heart	David Ruffin	1qzcdqlwqtm8lnthmvh2a70p9	2025-12-04 18:02:10+00	\N	motown, northern soul, classic soul, philly soul, soul
2804	8	4k7HTbpyFhYyaks0Kd2OoW	\N	When Legends Rise	Godsmack	1qzcdqlwqtm8lnthmvh2a70p9	2026-02-11 10:43:23+00	\N	alternative metal, nu metal, hard rock, rap metal, metal
3902	47	4lVYsUx4ZQVrIqj85zqXKE	\N	Only When (feat. Michael Blume)	Kero Uno, whatever mike	313neyxbfwxtbi2t52gjvliqxisa	2024-10-20 10:38:17+00	\N	retro soul
4301	60	4mdp26YsqfiqL6Fj9DJmaV	\N	Chaotic	Memphis May Fire	313neyxbfwxtbi2t52gjvliqxisa	2024-05-12 15:32:24+00	\N	metalcore, post-hardcore, screamo
3198	21	4nXkbcTj3nyww1cHkw5RAP	\N	Long Train Runnin'	The Doobie Brothers	1qzcdqlwqtm8lnthmvh2a70p9	2025-10-03 10:10:42+00	\N	yacht rock, classic rock, soft rock, southern rock
4270	58	4rrrn8OLrttq7r9RgNXalU	\N	Piano Concerto No. 2 in C Minor, Op. 18: 2. Adagio sostenuto	Sergei Rachmaninoff, Valentina Lisitsa, London Symphony Orchestra, Michael Francis	1qzcdqlwqtm8lnthmvh2a70p9	2024-05-30 10:32:00+00	\N	classical, classical piano, concerto
4015	50	4B7XAVfIiHPdgAHW3IZIFE	\N	Половина сердца	Leonid Agutin	31pd6hnytykuevog22xwj5yn2qjy	2024-08-29 19:55:40+00	\N	latin
4935	84	4JkKGMLKH6nOp88jQ4cdk8	\N	Когда тебя нет	Три Вторых	313neyxbfwxtbi2t52gjvliqxisa	2023-09-27 09:42:13+00	\N	rock
3643	37	4NeOWqHmlrGRuBvsLJC9rL	\N	My Love (feat. T.I.)	Justin Timberlake, T.I.	31pd6hnytykuevog22xwj5yn2qjy	2025-03-04 08:51:23+00	\N	pop
3724	40	4PUnrhN8MSCBKw4k1JBqJv	\N	это тоже пройдет (acoustic) [МУЗ.ЛИТ]	Mary Gu	1qzcdqlwqtm8lnthmvh2a70p9	2025-02-07 11:16:25+00	\N	folk
3808	43	4ZbPBXJNWdvW1iq3BlIyaj	\N	Turn Down For What	DJ Snake, Lil Jon	31433d6i5sfekboj5hr2fjtnwe7u	2025-01-11 08:26:54+00	\N	trap
4105	53	4gXRwMA2KqMkC9uW9Ra8Pe	\N	Синими, жёлтыми, красными	Ivan Dorn, Apollo Monkeys	31pd6hnytykuevog22xwj5yn2qjy	2024-07-27 09:15:44+00	\N	pop
4251	57	4iWln3t2SrVwLvhJlwnq4T	\N	CrazyMFLove	Basta	313neyxbfwxtbi2t52gjvliqxisa	2024-06-16 05:46:41+00	\N	pop
4878	82	4r0zC8FXAyB7ElkqrnMzF3	\N	Nightales	Redfield, Kelli-Leigh	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-09 08:41:37+00	\N	downtempo
3334	26	4sM97OPWWnm820cJ1SpvPI	\N	инструкция	iskrit	1qzcdqlwqtm8lnthmvh2a70p9	2025-06-21 11:08:45+00	\N	electronic
4336	61	4stnPEEAgaB6Lau8j9Hu1H	\N	Чёрными крыльями	Сова, Перемотка	31ghi62vkgnlb4wqr6muaisx7ldi	2024-05-01 08:51:09+00	\N	post-punk
4558	69	4t9ILPlcJkgk7tGnLNDsZE	\N	Northern Soul - Ben Böhmer Remix	Above & Beyond, Richard Bedford, Ben Böhmer	313neyxbfwxtbi2t52gjvliqxisa	2024-02-19 02:12:17+00	\N	trance, progressive trance, progressive house
2929	12	4xJgkImxUcPh3wuaKaHuxo	\N	Самолёт	Чугунный Скороход	1qzcdqlwqtm8lnthmvh2a70p9	2025-12-16 19:35:23+00	\N	jungle
4881	82	4zzk9QpZXsGby0TLrFGe0V	\N	Change Your Mind (feat. Stevie Appleton)	Ferreck Dawn, Millean., Stevie Appleton	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-09 08:49:01+00	\N	tech house, house
2910	12	53AafWSzYsiJKnAtJTUB5f	\N	La Tortura (feat. Alejandro Sanz)	Shakira, Alejandro Sanz	313neyxbfwxtbi2t52gjvliqxisa	2025-12-14 11:01:40+00	\N	latin pop
3632	36	55BUd2feeBMNek0NwXEYT7	\N	Fall Away	Zeds Dead	1qzcdqlwqtm8lnthmvh2a70p9	2025-03-13 12:11:22+00	\N	dubstep, edm
3520	32	51rXHuKN8Loc4sUlKPODgH	\N	King's Dead (with Kendrick Lamar, Future & James Blake)	Jay Rock, Kendrick Lamar, Future, James Blake	31ghi62vkgnlb4wqr6muaisx7ldi	2025-04-24 12:13:40+00	\N	hip hop
4039	51	56fiFTRrSiHHH3gBeaTg2P	\N	Nero Forte	Slipknot	313neyxbfwxtbi2t52gjvliqxisa	2024-08-11 10:28:38+00	\N	nu metal, metal, alternative metal, rap metal, heavy metal
2772	7	5I9vR24RZVrGJxIlYZwbkV	\N	The Burden	Code: Pandorum, Mirar	313neyxbfwxtbi2t52gjvliqxisa	2026-02-18 10:36:10+00	\N	deathstep, dubstep, riddim, bass music
4003	50	5Id6VF2BtRhG1DsMkKb41T	\N	Satisfaction - Netsky Extended Remix	Benny Benassi, The Biz, Netsky	1qzcdqlwqtm8lnthmvh2a70p9	2024-08-19 17:35:16+00	\N	electro house
4126	53	5In8B6Om5OKrhwBMB4tXSi	\N	Fuel	Eminem, JID	31pd6hnytykuevog22xwj5yn2qjy	2024-08-06 10:33:43+00	\N	rap, hip hop
4810	79	5KTZgG84bKFGm53lhLtTqc	\N	Mwaki	Zerb, Sofiya Nzau	313neyxbfwxtbi2t52gjvliqxisa	2023-11-03 00:35:59+00	\N	afro house
2924	12	5LusDHzggVu5HI1Gn8awRN	\N	hakuchumuha shiisainonai	chouchou merged syrups.	1qzcdqlwqtm8lnthmvh2a70p9	2025-12-16 18:12:48+00	\N	math rock, j-rock, japanese indie, shoegaze
2850	10	5NCnVxcLV3XriDtoygz3TK	\N	in your head	cloudyfield	31ghi62vkgnlb4wqr6muaisx7ldi	2026-01-04 10:59:06+00	\N	shoegaze
3046	16	5S8jc9sCle880PjbwnEzsY	\N	Aoi, Koi, Daidaiiro No Hi	MASS OF THE FERMENTING DREGS	1qzcdqlwqtm8lnthmvh2a70p9	2025-11-19 23:34:22+00	\N	j-rock, shoegaze, japanese indie, math rock, shibuya-kei
2709	4	5UCPOJs8VJARoIX6acKRuJ	\N	The Rhythm Of The Night	Corona	313neyxbfwxtbi2t52gjvliqxisa	2026-03-24 12:47:30+00	\N	eurodance
3128	19	5UZIVxzI4UyrSbg3ZLTGTH	\N	fuze	Skrillex, ISOxo	313neyxbfwxtbi2t52gjvliqxisa	2025-10-29 02:57:57+00	\N	dubstep, edm, electro, electronic
4152	54	5Vh4cFonbm0XdIyJIyrlPO	\N	Explosion	Kalwi & Remi	31pd6hnytykuevog22xwj5yn2qjy	2024-07-17 09:28:21+00	\N	disco polo
4857	81	5Vzs034G86rM3zLo80edmK	\N	Enjoy the Silence	Scott Bradlee's Postmodern Jukebox, Chloe Feoranzo	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-16 22:04:56+00	\N	swing music, jazz pop, electro swing
4561	69	5We7POZqcovcRs0A7JVJYt	\N	To You	Piece Wise, LissA	313neyxbfwxtbi2t52gjvliqxisa	2024-02-19 02:13:02+00	\N	deep house
3301	24	5XeFesFbtLpXzIVDNQP22n	\N	I Wanna Be Yours	Arctic Monkeys	31ghi62vkgnlb4wqr6muaisx7ldi	2025-08-20 16:05:09+00	\N	indie, garage rock
3453	30	5YaLFRpqpUzgLLDcukNn0H	\N	Lithium	Evanescence	313neyxbfwxtbi2t52gjvliqxisa	2025-05-13 00:14:42+00	\N	alternative metal
3955	48	5aYrqHtWy7UJljAVq3LFwv	\N	Napalm	Pendulum, Joey Valence & Brae	313neyxbfwxtbi2t52gjvliqxisa	2024-10-18 14:52:20+00	\N	drum and bass, dubstep
4314	60	5c3rym3xhKM4C3KvGCs9Tk	\N	Она совсем одна	Второй Ка	31ghi62vkgnlb4wqr6muaisx7ldi	2024-05-18 10:30:45+00	\N	post-punk
3390	27	5g3PPNIHL5yMci2pio9ZoI	\N	Now and at the Hour of Our Death (feat. BONES)	$uicideboy$, BONES	1qzcdqlwqtm8lnthmvh2a70p9	2025-06-19 22:00:24+00	\N	emo rap, horrorcore, cloud rap, trap metal, underground hip hop
5021	89	5lbpokETQEwTcoh9vt631Y	\N	Neiges	IMANU, The Caracal Project	1qzcdqlwqtm8lnthmvh2a70p9	2023-07-12 20:53:42+00	\N	drum and bass, drumstep
4108	53	5ofoB8PFmocBXFBEWVb6Vz	\N	Animals	Architects	313neyxbfwxtbi2t52gjvliqxisa	2024-07-30 11:31:54+00	\N	metalcore, djent, metal, mathcore, post-hardcore, deathcore
2712	4	5oxpT46KeiEuckYnChgFFT	\N	Open Your Eyes	Guano Apes	313neyxbfwxtbi2t52gjvliqxisa	2026-03-24 12:50:06+00	\N	nu metal
3743	41	5poFI1XOIPEOUKnuKEkeK2	\N	Там где нас нет	At The Ruins	313neyxbfwxtbi2t52gjvliqxisa	2025-01-30 23:45:11+00	\N	metalcore
4883	82	5rRO0glAM4AOwZny2WENEh	\N	Eternity (with Timmy Trumpet) [Club Mix]	KSHMR, Bassjackers, Timmy Trumpet	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-09 08:50:06+00	\N	big room, edm, slap house, electronica
3232	22	5sdqwzp1kSHHqTFsyfhrZW	\N	Destroy Me	PRESIDENT	313neyxbfwxtbi2t52gjvliqxisa	2025-09-26 10:32:00+00	\N	metalcore
4433	65	5tkmVEqglyP80CsQI8ggMT	\N	Man’s Not Hot	We Butter The Bread With Butter	313neyxbfwxtbi2t52gjvliqxisa	2024-03-21 07:21:20+00	\N	deathcore, metalcore, metal
3848	44	5ub6Cb5yKmgGGwjvqZM1gI	\N	Aqua Regia	Sleep Token	1qzcdqlwqtm8lnthmvh2a70p9	2024-12-15 07:28:17+00	\N	progressive metal, metalcore
4541	68	5yDJpu0xh0d1w13gXaE3lS	\N	The Heart from Your Hate	Trivium	31pd6hnytykuevog22xwj5yn2qjy	2024-02-28 13:30:08+00	\N	metalcore, metal, heavy metal
4321	61	62LubFpugeVGL19WpzPc4u	\N	今年こそギャル～初夏ver.～	花冷え。	313neyxbfwxtbi2t52gjvliqxisa	2024-04-23 15:45:40+00	\N	j-rock, visual kei
4344	61	63OQupATfueTdZMWTxW03A	\N	Karma Police	Radiohead	31pd6hnytykuevog22xwj5yn2qjy	2024-05-03 14:06:04+00	\N	art rock, alternative rock
3462	30	645zFwzeoDoEkkSLgup2oq	\N	NEVER ENOUGH	Turnstile	31pd6hnytykuevog22xwj5yn2qjy	2025-05-22 14:13:52+00	\N	hardcore punk, hardcore
3585	35	66PNMuMed95NQ4RDMP3hty	\N	Moonlight Runners	Dirtyphonics	313neyxbfwxtbi2t52gjvliqxisa	2025-03-20 23:26:33+00	\N	dubstep, deathstep, riddim, drumstep, drum and bass, bass music
4944	85	5As6bX4GsBqkCLzz7GgBLt	\N	Children of the Sun - R.I.O. Radio Edit	Yanou, R.I.O.	1qzcdqlwqtm8lnthmvh2a70p9	2023-09-20 17:59:48+00	\N	house
3668	38	5BKKy9fIJL5uM9fz1SnqyP	\N	Chicago	Michael Jackson	31pd6hnytykuevog22xwj5yn2qjy	2025-02-27 19:02:51+00	\N	pop
3447	29	5NVjKvrjuKpylrBgRdt0GT	\N	7 звонков - 2025 Version	Slot	313neyxbfwxtbi2t52gjvliqxisa	2025-05-30 09:51:25+00	\N	rock
4602	69	5SPJvbGUTBaxGGGSdZfK6M	\N	Eternity	John Pattern, Equanimous, Bliss Looper	31pd6hnytykuevog22xwj5yn2qjy	2024-02-23 23:26:00+00	\N	downtempo
2982	14	5SlKhhXtzd3Cj74HYmHZNz	\N	I'll Be There for You (Theme from Friends) - Single Version	The Rembrandts	313neyxbfwxtbi2t52gjvliqxisa	2025-12-04 13:28:42+00	\N	soundtrack
3659	37	5eAtbmtwthSXwo08rrxsrc	\N	Туда	Mikhey and Jumanji, Джуманджи	1qzcdqlwqtm8lnthmvh2a70p9	2025-03-07 13:12:11+00	\N	hip hop
4058	51	5eZklkEw43Kd5uAwbb0LsQ	\N	Возьми меня за руку	Глюк'oZa	1qzcdqlwqtm8lnthmvh2a70p9	2024-08-16 20:22:07+00	\N	pop
3554	33	5hkxGzLwuqN2QcwGBXUmL8	\N	Зажигай солнце	Кристиан Лейних	313neyxbfwxtbi2t52gjvliqxisa	2025-04-17 07:45:50+00	\N	pop
4659	71	5ttChN34ZQANCieimJ0ZEj	\N	Арендовано	The Hatters, Maksim Svoboda	313neyxbfwxtbi2t52gjvliqxisa	2024-02-08 02:27:47+00	\N	folk
2868	10	613J7Bs0MpAIcRwApteSzz	\N	Родители	Борис Грим	313neyxbfwxtbi2t52gjvliqxisa	2026-01-11 06:10:01+00	\N	indie
4218	56	61CPP50ppdH4ds3MbOSQ4h	\N	Dial D for Doctor	Warflower	31ghi62vkgnlb4wqr6muaisx7ldi	2024-06-22 12:44:59+00	\N	electronic
2740	6	65NiEZBNCIsOzlFMNTqIhA	\N	злой чел, негативный	STED.D	1qzcdqlwqtm8lnthmvh2a70p9	2026-02-28 05:49:35+00	\N	phonk
4454	65	67W0fSudyT3ApplXG8i4Xf	\N	Танцуй или умри	Lida	1qzcdqlwqtm8lnthmvh2a70p9	2024-03-23 14:45:05+00	\N	happy hardcore
5023	89	69XKVQPrzeR55H6INV9JBr	\N	Shadow - The Caracal Project Remix	Boombox Cartel, Moody Good, Calivania, The Caracal Project	1qzcdqlwqtm8lnthmvh2a70p9	2023-07-12 20:55:43+00	\N	future bass, edm trap, edm, dubstep
3698	39	6AI3ezQ4o3HUoP6Dhudph3	\N	Not Like Us	Kendrick Lamar	1qzcdqlwqtm8lnthmvh2a70p9	2025-02-14 08:53:31+00	\N	hip hop, west coast hip hop
3523	32	6C7Uv2qiKlG8i4BZjMqB4f	\N	Lyra	NO SIGNE	1qzcdqlwqtm8lnthmvh2a70p9	2025-04-24 17:53:45+00	\N	bass house, future house
3936	48	6CIctrvpDEs2GBP5j1VJPO	\N	Этажи	Wildways	313neyxbfwxtbi2t52gjvliqxisa	2024-09-22 11:05:03+00	\N	metalcore, post-hardcore
3342	26	6Df0RNShcnfIJmrRoJ6Gc9	\N	Unravelling	Muse	313neyxbfwxtbi2t52gjvliqxisa	2025-06-27 01:28:45+00	\N	alternative rock, rock
4065	52	6Dx7DEri2rapUBfYOxY9fB	\N	On And On - When the Lights Go Down	Akcent	1qzcdqlwqtm8lnthmvh2a70p9	2024-09-07 21:16:07+00	\N	europop
3258	23	6GQLX6Z28fYwDNCrhaKzYF	\N	Undercover Martyn	Two Door Cinema Club	31pd6hnytykuevog22xwj5yn2qjy	2025-09-07 05:20:27+00	\N	indie, indie rock
4226	56	6DRudNAC9MrUrZ2uZ87tOm	\N	It Really Happened	Paris Jones	31ghi62vkgnlb4wqr6muaisx7ldi	2024-06-22 12:45:16+00	\N	r&b
2814	8	6EOs3SX8Ck61F8T9AkufhK	\N	Это не мой вайб	СТИНТ	1qzcdqlwqtm8lnthmvh2a70p9	2026-02-11 11:00:01+00	\N	rap
3151	20	6I86RF3odBlcuZA9Vfjzeq	\N	Eres Mía	Romeo Santos	1qzcdqlwqtm8lnthmvh2a70p9	2025-10-15 20:49:26+00	\N	bachata, latin
3298	24	6IPwKM3fUUzlElbvKw2sKl	\N	we fell in love in october	girl in red	31ghi62vkgnlb4wqr6muaisx7ldi	2025-08-20 16:04:13+00	\N	bedroom pop
4348	62	6J0cfnZ3L77lJBT8pQD0Uj	\N	The Soup Is Poisoned	Howletowl	31ghi62vkgnlb4wqr6muaisx7ldi	2024-04-12 13:09:56+00	\N	japanese vgm
3029	16	6JAAgdb4zOjKjYuoqqJsib	\N	Losing My Color	Wind Walkers	313neyxbfwxtbi2t52gjvliqxisa	2025-11-14 16:59:38+00	\N	metalcore
2696	4	6Nm8h73ycDG2saCnZV8poF	\N	Dragula	Rob Zombie	31pd6hnytykuevog22xwj5yn2qjy	2026-03-24 09:27:03+00	\N	industrial metal, industrial rock, alternative metal, metal, nu metal
3438	29	6O7ac6gkkhUv4HTFYtf4Nk	\N	confuse urself	runThis, Electric Dad	1qzcdqlwqtm8lnthmvh2a70p9	2025-05-29 23:08:12+00	\N	bass house, uk garage
4175	55	6ORqU0bHbVCRjXm9AjyHyZ	\N	Good Riddance (Time of Your Life)	Green Day	31pd6hnytykuevog22xwj5yn2qjy	2024-06-22 10:30:22+00	\N	punk, pop punk
2932	12	6RZmhpvukfyeSURhf4kZ0d	\N	Is It True	Tame Impala	31pd6hnytykuevog22xwj5yn2qjy	2025-12-17 08:49:45+00	\N	neo-psychedelic, indie
4976	87	6RbwGr6dhNGGjgPb6vgDkd	\N	Bardo	GoGo Penguin	1qzcdqlwqtm8lnthmvh2a70p9	2023-08-03 10:54:43+00	\N	nu jazz, ambient jazz, experimental jazz, jazz, jazz fusion, indie jazz
2824	9	6RfxVckMaGO4KAGfjcn8u8	\N	I Only Always Think	Electrelane	31ghi62vkgnlb4wqr6muaisx7ldi	2026-01-27 13:28:53+00	\N	krautrock, post-rock
3356	26	6S7qPKFaHfotXNN52NixcN	\N	Rust	Black Label Society	31ghi62vkgnlb4wqr6muaisx7ldi	2025-07-03 12:30:15+00	\N	groove metal, metal, heavy metal
2977	14	6XDV5hAxl3WAu1MfGvFwUe	\N	Lately - From The HBO Series True Detective	Lera Lynn	31ghi62vkgnlb4wqr6muaisx7ldi	2025-12-04 13:19:10+00	\N	southern gothic, alt country, americana
4882	82	6Y9HjkMSYwxZWVKd12QeTi	\N	Destination Infinity (feat. Datura)	Gabry Ponte, Datura	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-09 08:49:45+00	\N	italo dance, slap house
2948	13	6ZQLvS6rqQSZGdq1Ve77p1	\N	All Mine	braev, ghosty, Afterfab	31ghi62vkgnlb4wqr6muaisx7ldi	2025-12-07 05:42:17+00	\N	melodic techno, melodic house
4562	69	6ZlvKdQSeQuqOaJObnp56f	\N	greedy	Our Last Night	313neyxbfwxtbi2t52gjvliqxisa	2024-02-19 02:13:06+00	\N	post-hardcore, metalcore
2865	10	6e0YUaVAfDxUabmybOjguy	\N	Awuke	Davido, YG Marley	1qzcdqlwqtm8lnthmvh2a70p9	2026-01-07 22:08:25+00	\N	afrobeats, afrobeat, afropop, afropiano, azonto, amapiano, hiplife, afroswing, afro r&b
3167	20	6ft9PAgNOjmZ2kFVP7LGqb	\N	Can't Take My Eyes off You	Frankie Valli	1qzcdqlwqtm8lnthmvh2a70p9	2025-10-23 23:59:09+00	\N	doo-wop
3769	42	6fyFiyoywfLYikFDQuabmH	\N	SleepMode	BONES	31433d6i5sfekboj5hr2fjtnwe7u	2024-12-30 05:04:40+00	\N	cloud rap, emo rap, horrorcore, trap metal, underground hip hop
3792	43	6g2BiiVQqY5v1S4HIrM54F	\N	Tuyo (Narcos Theme) [Extended Version] - A Netflix Original Series Soundtrack	Rodrigo Amarante	31pd6hnytykuevog22xwj5yn2qjy	2024-12-18 10:01:05+00	\N	new mpb
4250	57	6i4Qi1mJxXjqNIL9HfJhRs	\N	Civil War	Guns N' Roses	313neyxbfwxtbi2t52gjvliqxisa	2024-06-16 05:47:29+00	\N	rock, glam metal, hard rock, classic rock
5051	90	6izgNAWZno1CPMKjZWY5qn	\N	Dirty Vibe (with Diplo, G-Dragon, and CL) - Habstrakt Remix	Skrillex, CL, Diplo, Habstrakt	1qzcdqlwqtm8lnthmvh2a70p9	2023-07-09 12:33:58+00	\N	dubstep, edm, electro, electronic
4394	63	6j3PRPNWLutE3CutDzH4uI	\N	HUMO	Chencho Corleone, Peso Pluma	1qzcdqlwqtm8lnthmvh2a70p9	2024-04-07 09:10:11+00	\N	reggaeton
3912	47	6jgkEbmQ2F2onEqsEhiliL	\N	My Kind of Woman	Mac DeMarco	31433d6i5sfekboj5hr2fjtnwe7u	2024-10-21 04:00:10+00	\N	indie, lo-fi indie
3117	18	6ll0kSJDjC6Rh5toSENXUp	\N	Звёздная грязь	[AMATORY]	313neyxbfwxtbi2t52gjvliqxisa	2025-11-07 08:36:48+00	\N	metalcore
3290	24	6nTiIhLmQ3FWhvrGafw2zj	\N	American Idiot	Green Day	31pd6hnytykuevog22xwj5yn2qjy	2025-08-20 10:36:58+00	\N	punk, pop punk
3622	36	6p5duPGjAdVYLq2kOGXYUD	\N	Tonight (demo)	Amira Elfeky	313neyxbfwxtbi2t52gjvliqxisa	2025-03-13 05:44:45+00	\N	shoegaze
4756	77	6pEpkKjL4K0AhSLwDXNFRm	\N	Thrash	Unprocessed	313neyxbfwxtbi2t52gjvliqxisa	2023-11-23 23:15:00+00	\N	djent, progressive metal, metalcore, math rock
2730	5	6pkSEqfTFyoqaPXQ1d4nLp	\N	Bring Me To Life	Tiësto, FORS	1qzcdqlwqtm8lnthmvh2a70p9	2026-03-11 07:05:09+00	\N	edm, trance, big room, house
3267	24	6rUp7v3l8yC4TKxAAR5Bmx	\N	I Hate Everything About You	Three Days Grace	313neyxbfwxtbi2t52gjvliqxisa	2025-08-01 08:00:48+00	\N	post-grunge, rock
4682	72	6sIbv1oWOuma2qV907MUbk	\N	1x1 (feat. Nova Twins)	Bring Me The Horizon, Nova Twins	31pd6hnytykuevog22xwj5yn2qjy	2024-01-28 15:38:26+00	\N	metalcore, emo, rock, screamo, post-hardcore
3701	39	6t1pBY6VYjNM9SJEBieyJw	\N	last night i dreamt i fell in love	Alok, Kylie Minogue	1qzcdqlwqtm8lnthmvh2a70p9	2025-02-14 08:53:31+00	\N	brazilian bass, electronic, slap house, electro house
4765	77	6v34sp8RnuHwqn1ODtIzje	\N	Скорость	Wildways	313neyxbfwxtbi2t52gjvliqxisa	2023-12-10 15:22:23+00	\N	metalcore, post-hardcore
4205	56	6w8dBm5KlXxWejYrbGS1EJ	\N	I Wanna Be Somebody	W.A.S.P.	31ghi62vkgnlb4wqr6muaisx7ldi	2024-06-22 12:44:25+00	\N	glam metal, heavy metal, glam rock, hard rock, metal
4650	71	6L7sKxWItpyEiJm0uWcDcj	\N	Не бойся, я с тобой!	Ruki Vverh!	1qzcdqlwqtm8lnthmvh2a70p9	2024-02-05 13:19:32+00	\N	pop
3811	43	6UKrqWqzDTCYBCH2OXAMC3	\N	I've Never Been There	Yann Tiersen	31ghi62vkgnlb4wqr6muaisx7ldi	2025-01-11 17:19:01+00	\N	classical
4800	79	6Uu0Qi9GKUSOgkmCUaJ9Wp	\N	Мантикора	Аффинаж	313neyxbfwxtbi2t52gjvliqxisa	2023-10-31 05:16:25+00	\N	rock
3898	46	6Z4OIhzqpSdm7L5gxOG8Ub	\N	Чучука	КРОСЫ	1qzcdqlwqtm8lnthmvh2a70p9	2024-11-24 06:50:18+00	\N	pop
3549	33	6kUXV4X1VXqg5TfjZv6Vpj	\N	Солнце	Елена Терлеева	313neyxbfwxtbi2t52gjvliqxisa	2025-04-16 23:28:47+00	\N	pop
4112	53	6krmuuApbHM1tFhH8Cjhw8	\N	STUCK (feat. Sinizter)	NOTHING MORE, Sinizter	313neyxbfwxtbi2t52gjvliqxisa	2024-07-30 11:34:38+00	\N	metal
3502	31	6msfKhZomL7pMwRIlrOmgN	\N	Light Coming Out Of Your Eyes - Original Mix	Dabruck & Klein, Stella Attar	313neyxbfwxtbi2t52gjvliqxisa	2025-05-02 07:31:38+00	\N	house
3544	33	6vIfVadTREPaGEjpwEk9TR	\N	Чувства, которых нет	Kristina Kosheleva	1qzcdqlwqtm8lnthmvh2a70p9	2025-04-16 10:44:16+00	\N	pop
4452	65	6yc6eLttQC9pdhN6Xn4f9I	\N	Курильщикам трудно	Заур Магомадов	1qzcdqlwqtm8lnthmvh2a70p9	2024-03-23 12:46:40+00	\N	folk
4277	59	7221xIgOnuakPdLqT0F3nP	\N	I Had Some Help (Feat. Morgan Wallen)	Post Malone, Morgan Wallen	1qzcdqlwqtm8lnthmvh2a70p9	2024-05-20 15:47:37+00	\N	hip hop
3399	28	72s47svN0csVk41h0LdbSe	\N	Skin and Bones	David Kushner	313neyxbfwxtbi2t52gjvliqxisa	2025-06-03 00:17:20+00	\N	pop
3148	20	75Som71b3hqWNGHFS96guP	\N	Rally of Retribution (Official Dominator 2019 Anthem) - Radio Edit	Angerfist, Nolz	1qzcdqlwqtm8lnthmvh2a70p9	2025-10-13 17:54:41+00	\N	hardcore, frenchcore, hardstyle, gabber, hardcore techno, speedcore, tekno
2810	8	75hIYCHHwBSkO3rU03zEqt	\N	Undo (Your Body)	Leon Vynehall	1qzcdqlwqtm8lnthmvh2a70p9	2026-02-11 10:55:42+00	\N	lo-fi house, deep house
3638	37	78bSLVXuSmeYS6RxMRZihy	\N	Golden Skans	Klaxons	31ghi62vkgnlb4wqr6muaisx7ldi	2025-03-01 04:10:22+00	\N	new rave, alternative dance, indie
4169	55	78lgmZwycJ3nzsdgmPPGNx	\N	Immigrant Song - Remaster	Led Zeppelin	31pd6hnytykuevog22xwj5yn2qjy	2024-06-16 10:04:15+00	\N	classic rock, rock, hard rock, rock and roll
4371	62	7CiZj5S4E5FVboR0yLVLzc	\N	Original Nuttah 25 (feat. IRAH) - Chase & Status Remix	Uk Apache, SHY FX, IRAH, Chase & Status	1qzcdqlwqtm8lnthmvh2a70p9	2024-04-16 08:12:43+00	\N	jungle, drum and bass
4748	76	7I8t01aMxvROxDbeQpTEzI	\N	Me & April - slowed + reverb	almogfx, Sickheart	1qzcdqlwqtm8lnthmvh2a70p9	2023-12-21 09:09:02+00	\N	witch house, electroclash, dark ambient
2959	13	73zL6lWQJONAEzNaL4o9SV	\N	ДРОП	Diza	31ghi62vkgnlb4wqr6muaisx7ldi	2025-12-11 12:13:32+00	\N	electronic
3076	17	75AOHT6wkAr1XzaXTZiK6o	\N	Ties That Bind (feat. Courtney LaPlante of Spiritbox)	2XKO, Spiritbox, Courtney LaPlante, Joe Ford	1qzcdqlwqtm8lnthmvh2a70p9	2025-11-12 19:48:00+00	\N	metalcore
3918	47	7BC7w39Zt8CNwcrNz6LWgu	\N	Midnight Island	Harrison Brome	31pd6hnytykuevog22xwj5yn2qjy	2024-10-24 10:43:12+00	\N	downtempo
3788	42	7C2fomAaMbfRwAmeWKrwg0	\N	One Day	sir Was	31ghi62vkgnlb4wqr6muaisx7ldi	2025-01-24 11:25:40+00	\N	indie
4457	65	7CHi4DtfK4heMlQaudCuHK	\N	Lose Control	MEDUZA, Becky Hill, Goodboys	1qzcdqlwqtm8lnthmvh2a70p9	2024-03-23 19:22:55+00	\N	house
3816	43	7GmiJVBAzWNikX5VkNQg85	\N	Hawaiian Roller Coaster Ride	Mark Keali'i Ho'omalu, Kamehameha Schools Children's Chorus	31ghi62vkgnlb4wqr6muaisx7ldi	2025-01-11 17:19:13+00	\N	soundtrack
4826	79	7MIhUdNJtaOnDmC5nBC1fb	\N	Deep Down (feat. Never Dull)	Alok, Ella Eyre, Kenny Dope, Never Dull	1qzcdqlwqtm8lnthmvh2a70p9	2023-11-05 22:03:56+00	\N	brazilian bass, electronic, slap house, electro house
3321	25	7a7Sb9JRZzAabOotJ1e5Ww	\N	gore of being	ERRA	1qzcdqlwqtm8lnthmvh2a70p9	2025-07-18 00:01:53+00	\N	djent, metalcore, progressive metal, metal, deathcore, post-hardcore
2705	4	7bp5DfkdK1OAvNJ1U4HfDA	\N	Shadowboxin'	GZA, Method Man	31pd6hnytykuevog22xwj5yn2qjy	2026-03-24 09:41:43+00	\N	east coast hip hop, old school hip hop, hip hop, boom bap
3443	29	7eDUTBIo76AMC5UYqkkzDL	\N	Song 3	BABYMETAL, Slaughter to Prevail	313neyxbfwxtbi2t52gjvliqxisa	2025-05-30 09:49:34+00	\N	j-rock
4498	67	7fFYgJaOt9A8QnN5ExmfKF	\N	You're Free (feat. JEX)	LU2VYK, Jex	1qzcdqlwqtm8lnthmvh2a70p9	2024-03-03 15:55:28+00	\N	tropical house
4608	70	7gCuKTyBb5nurNalzs0Hvp	\N	Supersonic (My Existence) [with Noisia, josh pan & Dylan Brady]	Skrillex, Noisia, josh pan, Dylan Brady	313neyxbfwxtbi2t52gjvliqxisa	2024-02-11 14:38:33+00	\N	dubstep, edm, electro, electronic
3881	46	7hr0WyhqQxrK3SQ9ZQxjTu	\N	Awaken	Breaking Benjamin	313neyxbfwxtbi2t52gjvliqxisa	2024-11-03 15:14:07+00	\N	alternative metal, post-grunge, rock
3191	21	7hw9fHpl79i897B0wOmor8	\N	Mon idole	Janie	1qzcdqlwqtm8lnthmvh2a70p9	2025-10-03 09:19:42+00	\N	french pop, variété française, french indie pop
4565	69	7jURkEKDVEm9sHueqUX0ko	\N	Gimme That Bounce	Mau P	313neyxbfwxtbi2t52gjvliqxisa	2024-02-19 02:14:14+00	\N	tech house, house
3402	28	7jm63qwHLmemNcMzORjwfi	\N	Choke	I Prevail	31pd6hnytykuevog22xwj5yn2qjy	2025-06-04 08:25:35+00	\N	metalcore, metal
4970	86	7kE5SGVpogBX5VXiTgYiRg	\N	Chase The Sun	Koven	313neyxbfwxtbi2t52gjvliqxisa	2023-09-15 17:58:21+00	\N	drum and bass, liquid funk, drumstep, chillstep
3736	41	7nH4UnffKuEHlbjCnSRYRG	\N	WhereTheTreesMeetTheFreeway	BONES	31433d6i5sfekboj5hr2fjtnwe7u	2025-01-24 15:26:52+00	\N	cloud rap, emo rap, horrorcore, trap metal, underground hip hop
4280	59	7nh1Y833eqUM25QXmNsxxI	\N	Брат-ураган (Трибьют Объект насмешек, Рикошет, Выход дракона), Часть 2	Ермак!	313neyxbfwxtbi2t52gjvliqxisa	2024-05-22 11:36:42+00	\N	post-hardcore
4072	52	7njd3ZcEjEkvYwJso4gpaO	\N	Happy Violence - Vocal Radio Edit	Dada Life	1qzcdqlwqtm8lnthmvh2a70p9	2024-09-07 21:16:07+00	\N	big room, edm, electro house
2926	12	7oFDeK5yp5iM4YQvOLpknd	\N	Not Alone	Hardwell, Dyro	1qzcdqlwqtm8lnthmvh2a70p9	2025-12-16 18:34:21+00	\N	big room, edm, progressive house, electronica
4171	55	7pYfyrMNPn3wtoCyqcTVoI	\N	Moves Like Jagger - Studio Recording From "The Voice" Performance	Maroon 5, Christina Aguilera	31pd6hnytykuevog22xwj5yn2qjy	2024-06-24 10:42:39+00	\N	pop
2816	8	7pqgMEKsDMOHUdFQ7n0N9K	\N	Dangerous (feat. Sam Martin)	David Guetta, Sam Martin	313neyxbfwxtbi2t52gjvliqxisa	2026-02-11 11:03:14+00	\N	edm
4423	65	7uEvezzgCoYmqRDloOXUSR	\N	Something On My Mind	Purple Disco Machine, Duke Dumont, Nothing But Thieves	31pd6hnytykuevog22xwj5yn2qjy	2024-03-17 13:56:05+00	\N	disco house, nu disco, funky house, house
3850	44	7ups0PLQ1oiRnkneh3SQSD	\N	Problems Over Peace	AP Dhillon, Stormzy	1qzcdqlwqtm8lnthmvh2a70p9	2024-12-15 07:29:34+00	\N	punjabi hip hop, punjabi pop, desi, bhangra, desi hip hop
2997	14	7wg5h9uqPvRngy5WUQKlAs	\N	Echoes	The Rapture	1qzcdqlwqtm8lnthmvh2a70p9	2025-12-04 17:55:35+00	\N	new rave, indie dance, electroclash
3480	31	7y8B5xo2qC9rrRyovjpccI	\N	Russian Grizzly In America	Slaughter to Prevail	313neyxbfwxtbi2t52gjvliqxisa	2025-04-25 13:40:16+00	\N	deathcore, metal, death metal, metalcore
3281	24	7ycWLEP1GsNjVvcjawXz3z	\N	Praise The Lord (Da Shine) (feat. Skepta)	A$AP Rocky, Skepta	1qzcdqlwqtm8lnthmvh2a70p9	2025-08-18 03:44:35+00	\N	rap
4795	79	7zBUaZcW8vjTXFeLszFLwT	\N	We Are Kids (ABGT550)	Krasa Rosa, M.O.S.	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-30 21:31:47+00	\N	organic house, melodic house, progressive house
3123	19	7zLGHdfJ3JRPxvc96mEPEi	\N	Out of Touch	Daryl Hall & John Oates	1qzcdqlwqtm8lnthmvh2a70p9	2025-10-25 02:05:14+00	\N	yacht rock, soft rock
4087	52	7aGPJyIuEMxFUVapegZWJP	\N	Полнолуние	Artem Pivovarov	1qzcdqlwqtm8lnthmvh2a70p9	2024-09-07 07:14:58+00	\N	pop
3630	36	7jyjk4BFhhENbQeLPwG5zX	\N	В лучшем случае	Суп Харчо	1qzcdqlwqtm8lnthmvh2a70p9	2025-03-13 12:11:22+00	\N	pop
3718	40	7kgq3ZdX63WVDahd2thHQB	\N	Sippin	One True God, St. Mary	31ghi62vkgnlb4wqr6muaisx7ldi	2025-02-07 11:01:27+00	\N	trap
4267	58	7snaldtErdI9ypsSMKrIHj	\N	Kosil Jas’ Konjushinu (Mujuice Acid Rework)	Mujuice, Pesniary, Atomic Heart	1qzcdqlwqtm8lnthmvh2a70p9	2024-05-30 10:10:01+00	\N	electronic
3575	34	7uj4D4qofLKUzBYChuzKnb	\N	Барыбер	Дышать	31pd6hnytykuevog22xwj5yn2qjy	2025-03-28 08:39:34+00	\N	pop
3937	48	086THPnabbu1zfDjRsxpoN	\N	MONEY ON THE DASH - SPED UP	Elley Duhé, Whethan	31pd6hnytykuevog22xwj5yn2qjy	2024-09-22 11:06:18+00	\N	future bass
3413	28	0Gsrj2s6x2KdhsNaFnJamL	\N	Night Mother	Daedric	313neyxbfwxtbi2t52gjvliqxisa	2025-06-06 00:00:23+00	\N	electronic
4507	67	0I1eFRytp4XRhLCjT6tZm7	\N	I Can't Handle Change	Roar	31ghi62vkgnlb4wqr6muaisx7ldi	2024-03-04 12:53:09+00	\N	emo
3553	33	0MWHzwppXmhLRBI8QcNfZd	\N	Булки	Михаил Гребенщиков	313neyxbfwxtbi2t52gjvliqxisa	2025-04-16 23:44:13+00	\N	pop
4955	85	0MyfdGptOUnUnGzJmiyCOG	\N	VIRUS - Odd Mob Remix	GEN.KLOUD, Odd Mob	313neyxbfwxtbi2t52gjvliqxisa	2023-09-23 13:26:30+00	\N	electronic
3752	41	0gdjdIrcFYwcsvtz0ucCo1	\N	Sonnentanz - KABA & dela sur Remix	Klangkarussell, KABA, dela sur, Will Heard	1qzcdqlwqtm8lnthmvh2a70p9	2025-01-31 08:33:06+00	\N	electronic
2752	6	0jXDq4Cc07fy1EaohSYLJt	\N	Силуэт (из к/ф «Алиса в Стране Чудес»)	Ваня Дмитриенко, Аня Пересильд	313neyxbfwxtbi2t52gjvliqxisa	2026-03-03 02:39:47+00	\N	soundtrack
3694	39	163LFPs0EjyjeCo6a3frCa	\N	Понимаешь	Ирина Тонева, Павел Артемьев	31pd6hnytykuevog22xwj5yn2qjy	2025-02-12 20:32:29+00	\N	pop
3318	25	1AApldBkudH6jZAE9ucdUF	\N	White Wine & Adderall	The Chainsmokers, Beau Nox	1qzcdqlwqtm8lnthmvh2a70p9	2025-07-17 23:59:28+00	\N	electronic
4752	77	1IN6zJZPwB3MoRYGVixEI1	\N	Зачем	Антон Токарев, Vladimir Presnyakov	1qzcdqlwqtm8lnthmvh2a70p9	2023-11-23 11:47:44+00	\N	pop
3590	35	1L8hVXQ9JNMQFeHI8sohCZ	\N	Totem	Lamomali, -M-, Yamê, Fatoumata Diawara, Toumani Diabaté, Balla Diabaté	1qzcdqlwqtm8lnthmvh2a70p9	2025-03-20 23:29:14+00	\N	latin
5030	90	1NdpAqJDq8lqzyxRNeMZGM	\N	Þokan	Gísli Gunnarsson, Will Hunter	313neyxbfwxtbi2t52gjvliqxisa	2023-07-03 11:43:26+00	\N	downtempo
4855	81	1rO9U4fh5b7jNlzUqv3u4w	\N	А по тёмным улицам - Rxlzq Remix	Босиком по солнцу, RXLZQ	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-16 20:49:27+00	\N	electronic
2895	11	28JCMPpMunNUAoJ27pNyrO	\N	Новогодний поцелуй	Chay Vdvoyom, Stas Kostyushkin, Denis Klyaver	1qzcdqlwqtm8lnthmvh2a70p9	2025-12-23 21:22:06+00	\N	pop
3542	33	2BjrGZuz7cI9WhwBnjxLFr	\N	Ya sluzhu Rossii (Я служу России)	Aleksey Hvorostyan (Алексей Хворостян)	1qzcdqlwqtm8lnthmvh2a70p9	2025-04-16 10:37:19+00	\N	classical
4134	54	2BzKk0GMWtW5dfkOb62mJc	\N	Температура	Три дня дождя, polnalyubvi	1qzcdqlwqtm8lnthmvh2a70p9	2024-06-25 10:18:30+00	\N	rock
4993	87	2G5nn7dbdNkqNVk1NUV1zm	\N	Heartburn	Tenseoh	1qzcdqlwqtm8lnthmvh2a70p9	2023-08-23 19:15:17+00	\N	electronic
3605	35	2pw9RZWZibttZzoFhwjuy6	\N	Every Planet We Reach Is Dead	Gorillaz	313neyxbfwxtbi2t52gjvliqxisa	2025-03-21 11:15:41+00	\N	alternative rock
3398	28	3HNsNUj2jZgZjHISQ2xhbj	\N	WTFU	Bruvvy	313neyxbfwxtbi2t52gjvliqxisa	2025-06-03 00:14:57+00	\N	rap
4592	69	3RDcUlLGp3SLp2AmUbUbls	\N	Cookie Jar (feat. The-Dream)	Gym Class Heroes, The-Dream	1qzcdqlwqtm8lnthmvh2a70p9	2024-02-22 18:23:25+00	\N	hip hop
3470	30	3TZFIFDsTPmuyGAo5p7kVq	\N	Пиридай	Кисло-Сладкий, martoven, Bonah	31ghi62vkgnlb4wqr6muaisx7ldi	2025-05-23 10:56:00+00	\N	electronic
4644	71	3cVFTZ38ZrSd6iVuMeB0dA	\N	Сельдь с картошкой	Шыша, Fruit Machine 777	31pd6hnytykuevog22xwj5yn2qjy	2024-02-04 00:47:40+00	\N	pop
4701	73	3ok6hyir4LCOTgM4rbNsJz	\N	Destination	DJ Leonid Rudenko feat. Nicco, Leonid Rudenko, Nicco	1qzcdqlwqtm8lnthmvh2a70p9	2024-01-22 20:17:12+00	\N	house
3452	30	4APjkF4JTBysaCuazIMyCP	\N	Сломано	TROFIM GRANN	313neyxbfwxtbi2t52gjvliqxisa	2025-05-13 00:14:34+00	\N	pop
3734	41	5APFSQBzVNc2E8ZczN06bi	\N	escape	IVOXYGEN	31433d6i5sfekboj5hr2fjtnwe7u	2025-01-24 15:26:17+00	\N	downtempo
3197	21	5Lbd0n9P5EtPKen6uQ5UTF	\N	Лучший город на земле	Сироткин	1qzcdqlwqtm8lnthmvh2a70p9	2025-10-03 10:03:08+00	\N	rock
4630	70	629TRAVD61y1ZVNl9EOfEE	\N	THE BROWN STAINS OF DARKEESE LATIFAH PART 6-12 (REMIX) (feat. ScHoolboy Q)	Tyler, The Creator, ScHoolboy Q	31pd6hnytykuevog22xwj5yn2qjy	2024-02-14 16:05:39+00	\N	rap
3056	16	6JXAzCUM0Drgc4FgVA6mGC	\N	Fallen Angel feat. Aimee B	Mitsunori Ikeda, Aimee B	1qzcdqlwqtm8lnthmvh2a70p9	2025-11-19 23:57:54+00	\N	electronic
2748	6	6VflG4mpZSlpKnqNRL3NO9	\N	The Moon Cave (feat. Asha Puthli, Bobby Womack, Dave Jolicoeur, Jalen Ngonda and Black Thought)	Gorillaz, Asha Puthli, Bobby Womack, Dave Jolicoeur, Jalen Ngonda, Black Thought	31ghi62vkgnlb4wqr6muaisx7ldi	2026-03-02 09:17:30+00	\N	hip hop
2966	13	7GbqE3MlkKosIaCvf50JRK	\N	Lady Marmalade - From "Moulin Rouge" Soundtrack	Christina Aguilera, Lil' Kim, Mýa, P!nk	313neyxbfwxtbi2t52gjvliqxisa	2025-12-11 12:38:02+00	\N	soundtrack
3958	48	7uZMiMZdwCS547sZ4nY4oN	\N	Земля - OST "Амура"	Три дня дождя, Тося Чайкина	1qzcdqlwqtm8lnthmvh2a70p9	2024-10-19 23:25:43+00	\N	soundtrack
2699	4	0I1DJdLt9BKOb7GWmWxCjo	\N	Fields Of Gold	Sting	31pd6hnytykuevog22xwj5yn2qjy	2026-03-24 09:30:38+00	\N	soft rock
2719	4	0SuYcbenEg2MdkZunyqtwN	\N	Whoomp! There It Is	Tag Team	31ghi62vkgnlb4wqr6muaisx7ldi	2026-03-24 14:20:38+00	\N	miami bass
2691	4	0gsl92EMIScPGV1AU35nuD	\N	All By Myself	Céline Dion	1qzcdqlwqtm8lnthmvh2a70p9	2026-03-23 22:07:45+00	\N	variété française
2718	4	15tHagkk8z306XkyOHqiip	\N	I'll Be There for You - Theme From "Friends"	The Rembrandts	31ghi62vkgnlb4wqr6muaisx7ldi	2026-03-24 14:20:17+00	\N	rock
2687	4	1IsvXZXAV9EBC4hBKW6yDN	\N	Missing - Todd Terry Remix / Radio Edit	Everything But The Girl	1qzcdqlwqtm8lnthmvh2a70p9	2026-03-23 22:03:30+00	\N	house
2729	5	17WM8SkzLoAH0VBtjiHdjt	\N	6 Million	PEEKABOO, Skrillex, Flowdan, Fireboy DML	1qzcdqlwqtm8lnthmvh2a70p9	2026-03-11 07:05:09+00	\N	dubstep, bass music, riddim
2735	5	1EQgXWPkU96b4tw3pJtTp1	\N	AmEN! (feat. Lil Uzi Vert and Daryl Palumbo of Glassjaw)	Bring Me The Horizon, Lil Uzi Vert, Daryl Palumbo, Glassjaw	313neyxbfwxtbi2t52gjvliqxisa	2026-03-11 11:07:54+00	\N	metalcore, emo, rock, screamo, post-hardcore
2697	4	1G391cbiT3v3Cywg8T7DM1	\N	Scar Tissue	Red Hot Chili Peppers	31pd6hnytykuevog22xwj5yn2qjy	2026-03-24 09:29:11+00	\N	funk rock, alternative rock, rock
2720	4	1Je1IMUlBXcx1Fz0WE7oPT	\N	Wannabe	Spice Girls	31ghi62vkgnlb4wqr6muaisx7ldi	2026-03-24 14:22:05+00	\N	pop
2737	5	22XCH32bQnjDyK1lihtMZ1	\N	Годзилла	КРИМИ КРАЙ	313neyxbfwxtbi2t52gjvliqxisa	2026-03-11 11:08:22+00	\N	rap
2727	5	1k0JAiH11gHL9dc5dfQjQr	\N	NOT CUTE ANYMORE	ILLIT	1qzcdqlwqtm8lnthmvh2a70p9	2026-03-07 18:28:52+00	\N	k-pop
2714	4	225xvV8r1yKMHErSWivnow	\N	I Don't Want to Miss a Thing - From "Armageddon" Soundtrack	Aerosmith	313neyxbfwxtbi2t52gjvliqxisa	2026-03-24 12:52:27+00	\N	classic rock, rock
2707	4	2FK7fxjzQEXD7Z32HSF0Hl	\N	Men In Black - From "Men In Black" Soundtrack	Will Smith	313neyxbfwxtbi2t52gjvliqxisa	2026-03-24 12:47:21+00	\N	soundtrack
2688	4	2goLsvvODILDzeeiT4dAoR	\N	Believe	Cher	1qzcdqlwqtm8lnthmvh2a70p9	2026-03-23 22:03:45+00	\N	pop
2703	4	2g8HN35AnVGIk7B8yMucww	\N	Big Poppa - 2005 Remaster	The Notorious B.I.G.	31pd6hnytykuevog22xwj5yn2qjy	2026-03-24 09:38:39+00	\N	old school hip hop, gangster rap, east coast hip hop, hip hop
2728	5	2r4W42Jw5qvAKQVIrihLf8	\N	Три кота..	саундклауд ребёнок	1qzcdqlwqtm8lnthmvh2a70p9	2026-03-07 18:51:13+00	\N	soundtrack
2689	4	3AoeaZs8dFemFJr3JdzOL0	\N	You Are Not Alone	Michael Jackson	1qzcdqlwqtm8lnthmvh2a70p9	2026-03-23 22:05:49+00	\N	r&b
2708	4	2vlgOAH3M8Fmo19wOjeRyw	\N	Freestyler	Bomfunk MC's	313neyxbfwxtbi2t52gjvliqxisa	2026-03-24 12:47:25+00	\N	eurodance
2704	4	39QBkWKnap8wRSW4WB9OK0	\N	Gin and Juice	Snoop Dogg	31pd6hnytykuevog22xwj5yn2qjy	2026-03-24 09:39:35+00	\N	g-funk, west coast hip hop, gangster rap, old school hip hop, hip hop, rap
2734	5	3RVM7Sf8NAht6nfQWQFgGy	\N	Город влюблённых	Anna German, Инструментальный ансамбль п/у Вадима Гамалии	313neyxbfwxtbi2t52gjvliqxisa	2026-03-11 11:07:47+00	\N	classical
2716	4	3GfOAdcoc3X5GPiiXmpBjK	\N	Song 2	Blur	31ghi62vkgnlb4wqr6muaisx7ldi	2026-03-24 14:19:09+00	\N	britpop, madchester, alternative rock
2732	5	3ODXRUPL44f04cCacwiCLC	\N	i	Kendrick Lamar	31ghi62vkgnlb4wqr6muaisx7ldi	2026-03-11 11:02:38+00	\N	hip hop, west coast hip hop
2686	4	3PGRdlUoWnj8NHmbA5xTYS	\N	Dangerous	Depeche Mode	1qzcdqlwqtm8lnthmvh2a70p9	2026-03-23 22:02:33+00	\N	new wave, synthpop, darkwave
2726	5	3QbT2vQ2StZDNuX4HUditP	\N	Отпусти	ismie	1qzcdqlwqtm8lnthmvh2a70p9	2026-03-06 19:17:41+00	\N	shoegaze
2690	4	3RSpK5Y0y5tl25qvssrwJ6	\N	My All	Mariah Carey	1qzcdqlwqtm8lnthmvh2a70p9	2026-03-23 22:06:11+00	\N	christmas
2717	4	3UBItNVbFQiVC5hBQlBvnr	\N	Your Woman	White Town	31ghi62vkgnlb4wqr6muaisx7ldi	2026-03-24 14:19:53+00	\N	alternative rock
2698	4	3SFXsFpeGmBTtQvKiwYMDA	\N	Pretty Fly (For A White Guy)	The Offspring	31pd6hnytykuevog22xwj5yn2qjy	2026-03-24 09:36:01+00	\N	punk, skate punk
2692	4	67J4s8WkmY22lfLoA6kIrl	\N	Milk - 2015 Remaster	Garbage	1qzcdqlwqtm8lnthmvh2a70p9	2026-03-23 22:09:52+00	\N	rock
2710	4	3ovjw5HZZv43SxTwApooCM	\N	Wind Of Change	Scorpions	313neyxbfwxtbi2t52gjvliqxisa	2026-03-24 12:47:34+00	\N	hard rock, glam metal, rock
2731	5	499VJYm4KVBfw5bnHkeNZO	\N	Cheat Death	Blanke, Cyclops	1qzcdqlwqtm8lnthmvh2a70p9	2026-03-11 07:05:09+00	\N	melodic bass, future bass, dubstep, edm
2722	4	4QTO9eLRONw0rzOVWU4uB4	\N	Are You That Somebody?	Aaliyah	31ghi62vkgnlb4wqr6muaisx7ldi	2026-03-24 14:24:00+00	\N	r&b, contemporary r&b
2695	4	4vSbZNwBpZHYAyokxVme7J	\N	De Ushuaia a La Quiaca - 2024 Remaster	Gustavo Santaolalla	1qzcdqlwqtm8lnthmvh2a70p9	2026-03-23 22:46:20+00	\N	soundtrack
2693	4	4wtR6HB3XekEengMX17cpc	\N	Children	Robert Miles	1qzcdqlwqtm8lnthmvh2a70p9	2026-03-23 22:11:04+00	\N	trance, eurodance
2713	4	4yUcHLkHUwAPpKN0Uvdo8I	\N	Du riechst so gut	Rammstein	313neyxbfwxtbi2t52gjvliqxisa	2026-03-24 12:51:33+00	\N	industrial metal, metal, industrial rock, industrial
2711	4	5cZqsjVs6MevCnAkasbEOX	\N	Break Stuff	Limp Bizkit	313neyxbfwxtbi2t52gjvliqxisa	2026-03-24 12:47:40+00	\N	nu metal, rap metal, alternative metal, rap rock
2715	4	5ltXoDLlI0rFZAmOXbAp5T	\N	Sad But True - Remastered 2021	Metallica	313neyxbfwxtbi2t52gjvliqxisa	2026-03-24 12:59:08+00	\N	metal, thrash metal, rock, heavy metal, hard rock
2725	4	64BbK9SFKH2jk86U3dGj2P	\N	Otherside	Red Hot Chili Peppers	31ghi62vkgnlb4wqr6muaisx7ldi	2026-03-24 14:27:27+00	\N	funk rock, alternative rock, rock
2700	4	6VnpKLtfNH4Dk09YSGPSyR	\N	It Ain't Over 'Til It's Over	Lenny Kravitz	31pd6hnytykuevog22xwj5yn2qjy	2026-03-24 09:35:20+00	\N	rock
2706	4	6HdM7gzXVgcpepv276raog	\N	It's My Life	Dr. Alban	313neyxbfwxtbi2t52gjvliqxisa	2026-03-24 12:46:42+00	\N	eurodance
2723	4	6Tsu3OsuMz4KEGKbOYd6A0	\N	Hypnotize - 2007 Remaster	The Notorious B.I.G.	31ghi62vkgnlb4wqr6muaisx7ldi	2026-03-24 14:26:37+00	\N	old school hip hop, gangster rap, east coast hip hop, hip hop
2694	4	6urCAbunOQI4bLhmGpX7iS	\N	Don't Speak	No Doubt	1qzcdqlwqtm8lnthmvh2a70p9	2026-03-23 22:12:33+00	\N	rock
2702	4	6ZYXL7jKpA5vAuvA56G435	\N	Call Me Mañana	Scooter	31pd6hnytykuevog22xwj5yn2qjy	2026-03-24 09:43:04+00	\N	happy hardcore, eurodance
2724	4	6mz1fBdKATx6qP4oP1I65G	\N	Pony	Ginuwine	31ghi62vkgnlb4wqr6muaisx7ldi	2026-03-24 14:27:01+00	\N	r&b
2733	5	7rMWda6lXyeCtWuukOCOqV	\N	EBSH	TMNV	313neyxbfwxtbi2t52gjvliqxisa	2026-03-11 11:07:42+00	\N	electronic
2701	4	79CUrU5o2KAVDTNm4x3eGU	\N	Firestarter	The Prodigy	31pd6hnytykuevog22xwj5yn2qjy	2026-03-24 09:33:59+00	\N	big beat, breakbeat
2721	4	0jWgAnTrNZmOGmqgvHhZEm	\N	What's Up?	4 Non Blondes	31ghi62vkgnlb4wqr6muaisx7ldi	2026-03-24 14:23:16+00	\N	rock
2751	6	0TzeTV6yKerLoOxiiZ3qBD	\N	Меньше, чем вечность	Leanje	313neyxbfwxtbi2t52gjvliqxisa	2026-03-03 02:39:41+00	\N	pop
2791	8	06k2o42kmwDpyDK6ISkdpw	\N	Diamond Veins	French 79, Sarah Rebecca	31ghi62vkgnlb4wqr6muaisx7ldi	2026-02-07 16:23:38+00	\N	french house
2755	6	0LsyxswGj664Z5du9iNLxF	\N	Say No More	Volbeat	313neyxbfwxtbi2t52gjvliqxisa	2026-03-03 02:40:05+00	\N	rock, metal
2766	7	0Q7KGor0cF0vO2x2Gs0xyp	\N	The End Aesthetic	Wind Walkers	313neyxbfwxtbi2t52gjvliqxisa	2026-02-17 08:20:14+00	\N	metalcore
2789	8	14nEH8o7toND24LZLiKPM3	\N	VIEWS	Noga Erez, Reo Cragun, ROUSSO	31ghi62vkgnlb4wqr6muaisx7ldi	2026-02-07 16:23:35+00	\N	pop
2760	6	0uNETuut0gtfipHyJqPzeg	\N	WHERE IS MY HUSBAND!	Our Last Night	313neyxbfwxtbi2t52gjvliqxisa	2026-03-03 03:28:57+00	\N	post-hardcore, metalcore
2746	6	19OHDib8Jrqi3o2nm5lzdA	\N	My Nigga	YG, Jeezy, Rich Homie Quan	1qzcdqlwqtm8lnthmvh2a70p9	2026-02-26 20:33:19+00	\N	rap
2756	6	156gjKaMoJgvTRhhD2w5qp	\N	Angel Wings	PRESIDENT	313neyxbfwxtbi2t52gjvliqxisa	2026-03-03 02:40:10+00	\N	metalcore
2745	6	1BPKYZmrA0Wa10hdtPfaWl	\N	BIRD VIEW (из сериала «Майор Гром: Игра против правил»)	SALUKI, Sabu	1qzcdqlwqtm8lnthmvh2a70p9	2026-02-26 20:30:30+00	\N	soundtrack
2750	6	19RybK6XDbAVpcdxSbZL1o	\N	Apple	Charli xcx	31ghi62vkgnlb4wqr6muaisx7ldi	2026-03-02 15:17:27+00	\N	hyperpop, art pop
2794	8	1J4FEk8oaHyn57lK3CYpTD	\N	Don't Give a Fuck	The Hatters, Garry Topor, Tony Raut	313neyxbfwxtbi2t52gjvliqxisa	2026-02-11 10:01:16+00	\N	punk
2777	7	1cVwolOWhbafEpfiZbJZUp	\N	Quanto Costa	Propaganda	1qzcdqlwqtm8lnthmvh2a70p9	2026-02-25 07:57:20+00	\N	folk
2790	8	21kNAdpiP9oE1UIWzZw82s	\N	Rocknroll	Tony Tonite	31ghi62vkgnlb4wqr6muaisx7ldi	2026-02-07 16:23:36+00	\N	rock
2762	6	1isb97SB43Ri3Cjex9OM3G	\N	Know It's True	Trevor Omoto	1qzcdqlwqtm8lnthmvh2a70p9	2026-03-04 10:26:13+00	\N	future house
2778	7	1jboF0zn6czT1SaQbn2n3K	\N	Hear Me Say - KREAM Remix	Jonas Blue, LÉON, KREAM	1qzcdqlwqtm8lnthmvh2a70p9	2026-02-25 07:57:20+00	\N	tropical house
2764	6	1mGhg29DKBFTdmPcOASDhC	\N	DEAD 2 ME	Point North	1qzcdqlwqtm8lnthmvh2a70p9	2026-03-04 10:33:50+00	\N	pop punk
2758	6	1rEsbzLpzEM1yaC8OMuJmG	\N	Ghetto Funk	Matroda	313neyxbfwxtbi2t52gjvliqxisa	2026-03-03 02:40:27+00	\N	bass house, tech house, g-house, house, electro house
2743	6	35wTSN7Mw6knm4xsN41hKm	\N	Вишнёвый	Ваня Дмитриенко	1qzcdqlwqtm8lnthmvh2a70p9	2026-02-26 20:28:12+00	\N	pop
2753	6	2BZY8Q6HAhRkNBe2yXpUiv	\N	All That I Remember	The Amity Affliction	313neyxbfwxtbi2t52gjvliqxisa	2026-03-03 02:39:53+00	\N	metalcore, post-hardcore, screamo
2763	6	2VYtAJuuOr6RyOOggzSTIB	\N	Over & Over	Dark Heart, NJOMZA	1qzcdqlwqtm8lnthmvh2a70p9	2026-03-04 10:27:53+00	\N	deep house
2787	8	2cTOee6bTauDFK1QuDS1BD	\N	What Else Is There?	Röyksopp	31ghi62vkgnlb4wqr6muaisx7ldi	2026-02-07 16:23:32+00	\N	downtempo, electronica, trip hop
2738	5	2hs76oH0fJ5Hbqc2LhoRFY	\N	Onsra	Oceans Ate Alaska	313neyxbfwxtbi2t52gjvliqxisa	2026-03-11 11:08:53+00	\N	djent, metalcore, deathcore, post-hardcore, progressive metal
2774	7	3WzTUJKWd9pEYDepJpWJK1	\N	Nightmare Tripping (Feat. Nickelback)	DON BROCO, Nickelback	313neyxbfwxtbi2t52gjvliqxisa	2026-02-18 12:14:21+00	\N	metalcore
2754	6	36bFWadZkJhTnz5B8QT7PQ	\N	Evolve	Elwood Stray	313neyxbfwxtbi2t52gjvliqxisa	2026-03-03 02:39:58+00	\N	metalcore
2788	8	3dxOjnX03UHPUYW7bBikVu	\N	Тону	HOLLYFLAME	31ghi62vkgnlb4wqr6muaisx7ldi	2026-02-07 16:23:33+00	\N	electronic
2749	6	3Xhj7ZZAfQwPUxKZHQdw3y	\N	Peng Black Girls (feat. Amia Brave)	ENNY, Amia Brave	31ghi62vkgnlb4wqr6muaisx7ldi	2026-03-02 12:15:11+00	\N	uk r&b, alternative r&b
2739	5	3ZaXQi994D1GaMMd7m8xHa	\N	The Fall	Her Last Sight	313neyxbfwxtbi2t52gjvliqxisa	2026-03-11 11:08:59+00	\N	metalcore
2744	6	3rpi29kD9YUDwXz1yhjS7Q	\N	Люди	Дайте танк (!)	1qzcdqlwqtm8lnthmvh2a70p9	2026-02-26 20:29:01+00	\N	punk
2775	7	5D21HsFQ6Sb0GOLRrUqnr6	\N	SUMMER 2011	SOUTHSIDE CLUB	313neyxbfwxtbi2t52gjvliqxisa	2026-02-20 01:51:15+00	\N	house
2786	7	4BJ5k8vAGaHHW5KFksavW2	\N	Kora	Skrillex, Varg²™, Eurohead, SIIICKBRAIN, swedm®	1qzcdqlwqtm8lnthmvh2a70p9	2026-02-25 08:02:52+00	\N	dubstep, edm, electro, electronic
2747	6	4WFgvKVfEhb3IUAFGrutTR	\N	Love Me Not	Ravyn Lenae	31ghi62vkgnlb4wqr6muaisx7ldi	2026-03-02 09:12:03+00	\N	alternative r&b, indie soul
2771	7	4nZzqjNQoKD3c6afgxLNdg	\N	Circuit	Rezz, Limbo Slice	313neyxbfwxtbi2t52gjvliqxisa	2026-02-18 10:30:29+00	\N	edm, dubstep
2792	8	4zXZ5Mq2L6jnsOsTssgRh8	\N	Hush	The Marías	31ghi62vkgnlb4wqr6muaisx7ldi	2026-02-09 14:06:31+00	\N	bedroom pop
2784	7	51I5TnEKANW1F8I5MiTc83	\N	Surround Me	Camden Cox, Punctual, Shift K3Y	1qzcdqlwqtm8lnthmvh2a70p9	2026-02-25 07:57:20+00	\N	stutter house, house
2742	6	5GoC9yZ1KAqzV9V3Oxornv	\N	цветы	тёмный принц	1qzcdqlwqtm8lnthmvh2a70p9	2026-02-26 20:25:14+00	\N	rap
2757	6	5TpwKMNdnfI6uTO9OGTSxr	\N	нефоР	КРИМИ КРАЙ	313neyxbfwxtbi2t52gjvliqxisa	2026-03-03 02:40:17+00	\N	rap
2780	7	5KyhlyyCgQoL7eP7v1TehN	\N	満ちていく体温	Blu-Swing	1qzcdqlwqtm8lnthmvh2a70p9	2026-02-25 07:57:20+00	\N	city pop, shibuya-kei, japanese indie, j-r&b
2741	6	6XgporRQqjGRwjpiZwYty3	\N	ЧЗБ	GENSYXA	1qzcdqlwqtm8lnthmvh2a70p9	2026-02-26 20:23:57+00	\N	rap
2773	7	5pbqq53RAmAifpkkD5Q401	\N	House Of Cards	The Amity Affliction	313neyxbfwxtbi2t52gjvliqxisa	2026-02-18 11:08:59+00	\N	metalcore, post-hardcore, screamo
2765	6	6IxybHcuHhLyZFKbe3EXJK	\N	Colder	KUN	31ghi62vkgnlb4wqr6muaisx7ldi	2026-03-05 13:38:39+00	\N	chinese r&b, c-pop, mandopop, chinese hip hop
2761	6	6PtXaQhZvH4JFU5xe1aqRx	\N	I Will Be Here - Wolfgang Gartner Remix	Tiësto, Sneaky Sound System	1qzcdqlwqtm8lnthmvh2a70p9	2026-03-04 10:24:49+00	\N	edm, trance, big room, house
2779	7	6XPerlWQMvOUvLtWrpVsqJ	\N	Tunnel Party	Chestnut Bakery	1qzcdqlwqtm8lnthmvh2a70p9	2026-02-25 07:57:20+00	\N	shoegaze, chinese indie, dream pop
2783	7	6nwJbTWGcUUB7QqeI6eiQd	\N	SuperHuman	BlackGummy, Colleen D'agostino	1qzcdqlwqtm8lnthmvh2a70p9	2026-02-25 07:57:20+00	\N	electronic
2781	7	6ZCcskdnMq3jTuGB9z4vZf	\N	Pallet	mikanzil, PSYQUI	1qzcdqlwqtm8lnthmvh2a70p9	2026-02-25 07:57:20+00	\N	j-rock, future bass
2795	8	6oyjVwdaKB9FsAYR6FybmS	\N	Cyanide	Normandie	313neyxbfwxtbi2t52gjvliqxisa	2026-02-11 10:01:43+00	\N	rock
2785	7	7AVfa7iahDUVU34bpJXXTP	\N	Would You Love Me Better if I Go?	Neon One	1qzcdqlwqtm8lnthmvh2a70p9	2026-02-25 07:57:20+00	\N	alternative rock
2768	7	7jm63qwHLmemNcMzORjwfi	\N	Choke	I Prevail	313neyxbfwxtbi2t52gjvliqxisa	2026-02-17 08:20:30+00	\N	metalcore, metal
2767	7	06Yqd18RurF0JGMBIQnXBK	\N	Соседская	МЭЙКС	313neyxbfwxtbi2t52gjvliqxisa	2026-02-17 08:20:25+00	\N	indie
2856	10	0NGp0uHiKPWjnd5EKR9K58	\N	pool party	Two Another	31pd6hnytykuevog22xwj5yn2qjy	2026-01-07 11:02:27+00	\N	indie soul
2845	10	0a7BloCiNzLDD9qSQHh5m7	\N	Dance, Dance	Fall Out Boy	1qzcdqlwqtm8lnthmvh2a70p9	2026-01-03 03:34:11+00	\N	emo, pop punk
2818	9	0zroL15iMnkr1qiXi571lH	\N	Parasite	Jutes	313neyxbfwxtbi2t52gjvliqxisa	2026-01-23 01:52:04+00	\N	emo
2822	9	1ne2DLVXtxOPKLpZUqVG9G	\N	New Life	J Rongson	31ghi62vkgnlb4wqr6muaisx7ldi	2026-01-27 13:17:31+00	\N	electronic
2839	9	192KH2aINQ0q3cdHvd7CSG	\N	Hundo	JBEE	1qzcdqlwqtm8lnthmvh2a70p9	2026-02-04 09:08:08+00	\N	uk drill, drill
2851	10	1JCoJpklgGmwkRlshGaHzL	\N	Something Good	S. Fidelity	31ghi62vkgnlb4wqr6muaisx7ldi	2026-01-04 18:07:40+00	\N	jazz house, nu jazz
2806	8	1YxifpuwgU6IcGt7NKUVpb	\N	ghosted	Saint Harison	1qzcdqlwqtm8lnthmvh2a70p9	2026-02-11 10:45:21+00	\N	uk r&b
2819	9	2CASGo9Wmd6Dxrq3ygnRjf	\N	Jenny	NOTHING MORE	313neyxbfwxtbi2t52gjvliqxisa	2026-01-23 01:52:12+00	\N	rock
2852	10	21tQ61tNj6qbXbDwmSIPt9	\N	Multiply (feat. Juicy J)	A$AP Rocky, Juicy J	31pd6hnytykuevog22xwj5yn2qjy	2026-01-07 10:41:14+00	\N	rap
2844	9	2GHKo6nrSjruvBEQbzD7Fw	\N	Tiramisu	Don Toliver	31pd6hnytykuevog22xwj5yn2qjy	2026-02-04 09:54:08+00	\N	rap
2826	9	2CvqA0HXoBk46epUacjLaB	\N	Bats in the Belfry	Jon Kennedy	31ghi62vkgnlb4wqr6muaisx7ldi	2026-01-27 13:29:26+00	\N	trip hop, downtempo, nu jazz
2823	9	2FDdVUPDAeJ94kOlVW7L8n	\N	Makes You Fly	Nice Guys, Dumbo Gets Mad	31ghi62vkgnlb4wqr6muaisx7ldi	2026-01-27 13:25:08+00	\N	surf rock
2846	10	2Ozc0me9PV5vlt8cokwdvI	\N	Lean Back	Terror Squad, Fat Joe, Remy Ma, remy	1qzcdqlwqtm8lnthmvh2a70p9	2026-01-03 04:06:45+00	\N	hip hop
2803	8	2iPdcPHbVRzLfDZQv49mq7	\N	So Far So Fake	DarkLux, Xizt	1qzcdqlwqtm8lnthmvh2a70p9	2026-02-11 10:42:13+00	\N	electronic
2828	9	2SgbR6ttzoNlCRGQOKjrop	\N	Cowboys from Hell	Pantera	313neyxbfwxtbi2t52gjvliqxisa	2026-01-29 01:21:30+00	\N	groove metal, metal, thrash metal, heavy metal
2832	9	2ydXPwCSYwinIPb0cUqMd2	\N	Уходи	Sveta	1qzcdqlwqtm8lnthmvh2a70p9	2026-01-31 08:45:29+00	\N	pop
2854	10	3JGvqlIZr8pvabWHmZwPsU	\N	In the Moment - Adriatique Remix	RÜFÜS DU SOL, Adriatique	31pd6hnytykuevog22xwj5yn2qjy	2026-01-07 10:49:07+00	\N	house
2825	9	33iMJKVzhZQTieO3HrSdKr	\N	Crayfish Caper	Surprise Chef	31ghi62vkgnlb4wqr6muaisx7ldi	2026-01-27 13:29:13+00	\N	jazz funk, indie jazz, jazz house
2848	10	398fdoFGhYPMKnWJwCkR0X	\N	Nikotini - original	Giorgos Mazonakis	1qzcdqlwqtm8lnthmvh2a70p9	2026-01-03 05:17:21+00	\N	laïko, entehno
2820	9	3CIOopLwvyMvXk97ZEksKO	\N	Ace of Spades	Motörhead	313neyxbfwxtbi2t52gjvliqxisa	2026-01-29 02:18:57+00	\N	heavy metal, metal, speed metal, hard rock, rock
2815	8	3HKV2TCxpAAlHQphu4cJD0	\N	Liar Liar - Avicii By Avicii	Avicii, Tim Bergling	313neyxbfwxtbi2t52gjvliqxisa	2026-02-11 11:01:54+00	\N	edm
2805	8	405OCJABhpnTrDSnwarHuR	\N	Pereday	Ivan Dorn	1qzcdqlwqtm8lnthmvh2a70p9	2026-02-11 10:44:24+00	\N	pop
2802	8	3MAYfvKNoq5KDreKoxuyyJ	\N	Vibes of Spaces	Manapart	1qzcdqlwqtm8lnthmvh2a70p9	2026-02-11 10:39:26+00	\N	nu metal
2837	9	3m1vAbsdQCFDbzmPpAad5a	\N	Laissez-nous vivre	Corneille	1qzcdqlwqtm8lnthmvh2a70p9	2026-02-04 09:08:08+00	\N	french r&b, french pop, variété française, chanson québécoise, chanson
2834	9	41f8Bpr5u2Jk5SmOkRCVDT	\N	На своём вайбе (feat. Гуф)	Jah Khalib, GUF	1qzcdqlwqtm8lnthmvh2a70p9	2026-02-04 09:08:08+00	\N	hip hop
2831	9	4ws8TbqNIoSA7Ti8N0vFQX	\N	ye yo	The OM	313neyxbfwxtbi2t52gjvliqxisa	2026-01-30 00:54:30+00	\N	electronic
2798	8	46odPfzMypgxCBMUPmdKxr	\N	Afraid Of The Dark	Motionless In White	313neyxbfwxtbi2t52gjvliqxisa	2026-02-11 10:06:00+00	\N	metalcore, metal
2841	9	4CCOpQPov1W4JGiKX7O8EP	\N	My Favourite Game	Fake Idols	1qzcdqlwqtm8lnthmvh2a70p9	2026-02-04 09:12:25+00	\N	post-grunge
2799	8	4UEo1b0wWrtHMC8bVqPiH8	\N	Nightmare	Avenged Sevenfold	313neyxbfwxtbi2t52gjvliqxisa	2026-02-11 10:16:14+00	\N	metal, alternative metal
2849	10	6Y26cFvFKVBm8rKZCyT3gu	\N	Booksmart Hunny	Milo Korbenski	31ghi62vkgnlb4wqr6muaisx7ldi	2026-01-04 10:58:05+00	\N	indie
2817	9	51c94ac31swyDQj9B3Lzs3	\N	Change (In the House of Flies)	Deftones	313neyxbfwxtbi2t52gjvliqxisa	2026-01-22 23:36:06+00	\N	nu metal, alternative metal, rap metal, shoegaze, rock
2830	9	52s05aBQd2LVc6EWIQCQI1	\N	Are You Dead Yet?	Children Of Bodom	313neyxbfwxtbi2t52gjvliqxisa	2026-01-30 00:47:42+00	\N	melodic death metal, metal, death metal
2847	10	5BeBfnubllFy69omQHNavT	\N	Step Up	Darin	1qzcdqlwqtm8lnthmvh2a70p9	2026-01-03 05:02:59+00	\N	swedish pop
2835	9	5kwAIpUBwhmiBpsJlcMgO1	\N	Fade Into Darkness - Vocal Radio Mix	Avicii	1qzcdqlwqtm8lnthmvh2a70p9	2026-02-04 09:08:08+00	\N	edm
2827	9	5mR858YsHYG761aUqZoGkD	\N	Symphony Of Destruction - Remastered 2012	Megadeth	313neyxbfwxtbi2t52gjvliqxisa	2026-01-29 00:39:40+00	\N	thrash metal, metal, heavy metal, speed metal
2836	9	6GnXFmdI2jEFnBLnEjvqx9	\N	Making of (Génériq) - BOF Taxi 3	Dadoo	1qzcdqlwqtm8lnthmvh2a70p9	2026-02-04 09:08:08+00	\N	french rap, french r&b
2833	9	6ODZEW7gTfbMQgoQq1oLgS	\N	Lil Cease (feat. Armani Caesar)	Westside Gunn, Armani Caesar	1qzcdqlwqtm8lnthmvh2a70p9	2026-02-02 22:52:14+00	\N	boom bap, alternative hip hop, jazz rap, experimental hip hop
2812	8	6zAG9yzulsgx0fTsA59DQi	\N	Чернила	Baby19!, Thomas Mraz	1qzcdqlwqtm8lnthmvh2a70p9	2026-02-11 10:59:06+00	\N	pop
2807	8	6fpwtsLQwN6CcJIyaSYosE	\N	Light You Up ft. CREG	GRiZ, Tape B, CREG	1qzcdqlwqtm8lnthmvh2a70p9	2026-02-11 10:46:43+00	\N	dubstep, edm
2809	8	6q3fpXnEh0bMUGvwyOBEXZ	\N	SOS (VIP)	PhaseOne, Make Them Suffer	1qzcdqlwqtm8lnthmvh2a70p9	2026-02-11 10:55:13+00	\N	dubstep, deathstep, riddim, bass music
2800	8	75WwT99SXNn0boaMxXXfqk	\N	Флиртуй - Palagin Remix	The Limba, Palagin	1qzcdqlwqtm8lnthmvh2a70p9	2026-02-11 10:32:13+00	\N	house
2857	10	7DZIyQPhsNAg8AGL21PpQ9	\N	Не Глубокослав	токсичный ансамбль лягухо	1qzcdqlwqtm8lnthmvh2a70p9	2026-01-07 21:20:11+00	\N	punk
2842	9	769cLRTw2y6KRdkFWFkxtu	\N	Domination	Pantera	31pd6hnytykuevog22xwj5yn2qjy	2026-02-04 09:34:20+00	\N	groove metal, metal, thrash metal, heavy metal
2811	8	7ieSNET9yuS7u9zinIGwVs	\N	Намисто	ROXOLANA	1qzcdqlwqtm8lnthmvh2a70p9	2026-02-11 10:57:25+00	\N	pop
2843	9	7eEnuNVAHQXEwg18zZnmdL	\N	NO TRESPASSING	A$AP Rocky	31pd6hnytykuevog22xwj5yn2qjy	2026-02-04 09:38:24+00	\N	rap
2813	8	7qtYhz86imaot3OEJaHtMX	\N	Я хочу безумно жить ft. А. Блок	Slava KPSS, blago white	1qzcdqlwqtm8lnthmvh2a70p9	2026-02-11 10:59:23+00	\N	rap
2801	8	000FiixurIe7Gj7rscl20W	\N	Mic Check	Hadouken!	1qzcdqlwqtm8lnthmvh2a70p9	2026-02-11 10:38:05+00	\N	electronic
2840	9	0bEkX6EtL8bXgZTb94V7OQ	\N	KILLING ME	TSS	1qzcdqlwqtm8lnthmvh2a70p9	2026-02-04 09:12:25+00	\N	pop
2911	12	0CnD7Hiw6pae6rLsZw5q5W	\N	Incomplete	Backstreet Boys	313neyxbfwxtbi2t52gjvliqxisa	2025-12-14 11:01:43+00	\N	pop
2900	11	0yHWbo5Zwz0MPKKP5mgsqM	\N	Не подходи	Akula	1qzcdqlwqtm8lnthmvh2a70p9	2025-12-24 01:12:41+00	\N	pop
2894	11	0jDCOHIM4LRRZNbdkvphhi	\N	Mary's Boy Child	Jose Mari Chan	31433d6i5sfekboj5hr2fjtnwe7u	2025-12-23 15:42:21+00	\N	opm, christmas
2885	11	0rHToGels2lt8Y0mCYoF90	\N	Deck The Hall	Nat King Cole	31ghi62vkgnlb4wqr6muaisx7ldi	2025-12-23 12:23:13+00	\N	christmas, adult standards, vocal jazz
2913	12	1AEuq3M34uZQflOK68Dmhl	\N	Trauma Olympics	James the Seventh	31ghi62vkgnlb4wqr6muaisx7ldi	2025-12-15 16:09:55+00	\N	emo
2892	11	11Hq1xTlR8Bgm3Pgv9EqGs	\N	O Holy Night (From "Home Alone" Soundtrack)	John Williams	31433d6i5sfekboj5hr2fjtnwe7u	2025-12-23 15:00:31+00	\N	soundtrack, score
2912	12	1iOJQhxKSJ7dg3Dk03yPnl	\N	U + Ur Hand	P!nk	313neyxbfwxtbi2t52gjvliqxisa	2025-12-14 11:01:51+00	\N	pop
2890	11	1IcR6RlgvDczfvoWJSSY2A	\N	It's the Most Wonderful Time of the Year	Andy Williams	31433d6i5sfekboj5hr2fjtnwe7u	2025-12-23 14:42:02+00	\N	christmas, adult standards
2907	11	23NhbKNp91IZTc5K8i8Ice	\N	Звенит январская вьюга	Nina Brodskaya	313neyxbfwxtbi2t52gjvliqxisa	2025-12-24 10:33:55+00	\N	classical
2908	12	1o2QXBJvkXTgDDM6EvjU9I	\N	Groovejet (If This Ain't Love)	Spiller, Sophie Ellis-Bextor	313neyxbfwxtbi2t52gjvliqxisa	2025-12-14 11:01:28+00	\N	disco house
2878	11	2CZPJLTtQ8fNps1iOw4xfb	\N	Новогодняя	Diskoteka Avariya	313neyxbfwxtbi2t52gjvliqxisa	2025-12-18 00:13:04+00	\N	pop
2905	11	2DmFi57h33k7Lj59kyXyXg	\N	Это новый год!	REFLEX	313neyxbfwxtbi2t52gjvliqxisa	2025-12-24 10:32:16+00	\N	pop
2871	10	2ZoTtMBkUgsMX0DIs6j91w	\N	Mom	Exiles of Eden	313neyxbfwxtbi2t52gjvliqxisa	2026-01-11 06:22:34+00	\N	metalcore
2901	11	2bXj24ecJDqD0NaJo6M36B	\N	Снег идёт	Глюк'oZa	31pd6hnytykuevog22xwj5yn2qjy	2025-12-24 08:39:00+00	\N	pop
2879	11	2EjXfH91m7f8HiJN1yQg97	\N	Rockin' Around The Christmas Tree	Brenda Lee	313neyxbfwxtbi2t52gjvliqxisa	2025-12-18 04:53:11+00	\N	christmas
2880	11	2kFbOlJktIZXx6jxFN3yAK	\N	Под Новый Год	Betsy, Ded M	313neyxbfwxtbi2t52gjvliqxisa	2025-12-18 15:33:16+00	\N	pop
2874	10	31T2dxAa2TSUtymgF7L7Oi	\N	Come Fight Me For It	ALT BLK ERA	313neyxbfwxtbi2t52gjvliqxisa	2026-01-11 07:50:57+00	\N	metalcore
2899	11	3ILTi7BoMZkYpSIiwUSVFy	\N	Новый Год	Krapiva Jazz	313neyxbfwxtbi2t52gjvliqxisa	2025-12-23 23:57:22+00	\N	jazz
2873	10	3Uz0JAkgsVPcJHttEkQMUb	\N	社畜	megumin2.0	313neyxbfwxtbi2t52gjvliqxisa	2026-01-11 07:43:57+00	\N	electronic
2891	11	3CMtSyoSbL8R8VsdXgnt9A	\N	Sleigh Ride	The Disney Holiday Chorus	31433d6i5sfekboj5hr2fjtnwe7u	2025-12-23 14:56:45+00	\N	christmas, villancicos
2872	10	3EAeH1G0BoxQIX8SmgjqAy	\N	Cross Off	Mark Morton, Chester Bennington	313neyxbfwxtbi2t52gjvliqxisa	2026-01-11 07:36:33+00	\N	groove metal
2903	11	3a4QnAsEeOwjdNHSxogHY5	\N	Зима	Eduard Khil	31pd6hnytykuevog22xwj5yn2qjy	2025-12-24 08:48:48+00	\N	folk
2861	10	3a5RwGwrE14wFyvBur55Rn	\N	солёное счастье	ульяна мамушкина	1qzcdqlwqtm8lnthmvh2a70p9	2026-01-07 22:00:47+00	\N	pop
2867	10	3cU0nO8u9S6INZPnwQAsy7	\N	ромашки	Zemfira	31pd6hnytykuevog22xwj5yn2qjy	2026-01-08 10:36:43+00	\N	rock
2897	11	46BwFT6iAy5nAeyqYFir8Q	\N	Первый снег	Freestyle	1qzcdqlwqtm8lnthmvh2a70p9	2025-12-23 22:57:06+00	\N	rap
2859	10	4lQXlqgD09JrGdphtODwpB	\N	Старый отель	Bravo	1qzcdqlwqtm8lnthmvh2a70p9	2026-01-07 21:26:23+00	\N	rock
2882	11	3oVC4Mx4Y3Uh3M4dCyIJIW	\N	Can You Hear the Bells	Anne-Kathrin Dern	31ghi62vkgnlb4wqr6muaisx7ldi	2025-12-23 12:21:44+00	\N	christmas
2893	11	3w0RchcsELYZEdFGr5Fqwz	\N	Captain Santa Claus (And His Reindeer Space Patrol)	Bobby Helms	31433d6i5sfekboj5hr2fjtnwe7u	2025-12-23 15:40:56+00	\N	christmas
2877	11	5109fSa97riNDcPcXnOXEa	\N	Ангел дня 2000	Русский размер	1qzcdqlwqtm8lnthmvh2a70p9	2025-12-15 18:35:04+00	\N	pop
2884	11	4GezIsOi5WtYW9CF3kFoI9	\N	Carol of the Bells	Anne Chmelewsky	31ghi62vkgnlb4wqr6muaisx7ldi	2025-12-23 12:22:11+00	\N	christmas
2862	10	4bHsxqR3GMrXTxEPLuK5ue	\N	Don't Stop Believin'	Journey	1qzcdqlwqtm8lnthmvh2a70p9	2026-01-07 22:06:20+00	\N	aor, classic rock
2866	10	4l9hml2UCnxoNI3yCdL1BW	\N	My Funny Valentine	Chet Baker	1qzcdqlwqtm8lnthmvh2a70p9	2026-01-07 22:08:25+00	\N	jazz, cool jazz, vocal jazz, jazz ballads
2863	10	55lCPsTxQbJrQfuIQlu7LJ	\N	Believe	Adam Lambert	1qzcdqlwqtm8lnthmvh2a70p9	2026-01-07 22:07:08+00	\N	pop
2904	11	59kTEpQK7SuDqEKhtMaCrb	\N	Зима-холода	Andrey Gubin	31pd6hnytykuevog22xwj5yn2qjy	2025-12-24 08:49:18+00	\N	pop
2898	11	5Ne6yWmQZ8qrCnOJ2Fc7Tb	\N	Новый год	Стекловата	313neyxbfwxtbi2t52gjvliqxisa	2025-12-23 23:39:21+00	\N	pop
2876	10	5VjAbcHnovUqhadhMeKrG7	\N	Afterlife	Monomythic, Christian Grey	313neyxbfwxtbi2t52gjvliqxisa	2026-01-11 07:55:21+00	\N	electronic
2906	11	5ndI7xtuu5IAxixD0rNB0f	\N	Зимний сон	Alsou	313neyxbfwxtbi2t52gjvliqxisa	2025-12-24 10:32:54+00	\N	pop
2886	11	5xQskDSiHQeoebxoprn3HL	\N	You're A Mean One, Mr. Grinch	Tyler, The Creator	31ghi62vkgnlb4wqr6muaisx7ldi	2025-12-23 12:23:24+00	\N	hip hop
2875	10	6YbDzTWROe5Jqs75sQZjUO	\N	SPIRITS	NOTHING MORE	313neyxbfwxtbi2t52gjvliqxisa	2026-01-11 07:53:39+00	\N	rock
2864	10	5utINKwnXh1drV2vI9cnze	\N	Bombalaya - Blooom Remix	DNMO, Wolfy Lights, Blooom	1qzcdqlwqtm8lnthmvh2a70p9	2026-01-07 22:07:52+00	\N	drum and bass
2914	12	6gyGIFIU270niilIMHS8zi	\N	Гроза	tAISh	31ghi62vkgnlb4wqr6muaisx7ldi	2025-12-15 16:10:06+00	\N	electronic
2889	11	6IeK3Ap5m3HabwJxgI6eSE	\N	It's Beginning to Look a Lot Like Christmas (with Mitchell Ayres & His Orchestra)	Perry Como, The Fontane Sisters, Mitchell Ayres & His Orchestra	31433d6i5sfekboj5hr2fjtnwe7u	2025-12-23 13:11:11+00	\N	christmas, adult standards
2858	10	7nlksZmn6mj3xkIpHBI55R	\N	ПИВО	Turbosh	1qzcdqlwqtm8lnthmvh2a70p9	2026-01-07 21:23:42+00	\N	electronic
2915	12	6d35qhGJnNgfIG6PCBVylb	\N	Whole Lotta Ice	GOTOU寄生獣, vodvor	31ghi62vkgnlb4wqr6muaisx7ldi	2025-12-15 16:11:50+00	\N	trap metal
2860	10	7bhUBBJjWXxp3SV9zJztcm	\N	TRAPSTA	Rops1	1qzcdqlwqtm8lnthmvh2a70p9	2026-01-07 21:29:55+00	\N	aussie drill, drill
2883	11	7p1ZHcEoUlqvFouSOeWyRr	\N	Please Santa	David Kater	31ghi62vkgnlb4wqr6muaisx7ldi	2025-12-23 12:21:56+00	\N	christmas
2887	11	7vQbuQcyTflfCIOu3Uzzya	\N	Jingle Bell Rock	Bobby Helms	31433d6i5sfekboj5hr2fjtnwe7u	2025-12-23 13:02:56+00	\N	christmas
2916	12	0456Mg7xWCGHOaMpTbBLMH	\N	мы в клуб	Karna.val	1qzcdqlwqtm8lnthmvh2a70p9	2025-12-15 18:34:11+00	\N	house
2967	13	0ZeKQudydO2uQJpfr6gNC8	\N	Tainted Love	Marilyn Manson	313neyxbfwxtbi2t52gjvliqxisa	2025-12-11 12:40:01+00	\N	industrial metal, industrial rock, industrial, metal, nu metal
2938	12	0jyNWv3M0TGvVS4QD77uO7	\N	Flamethrower	Circadian, Cody Frost	31pd6hnytykuevog22xwj5yn2qjy	2025-12-17 08:58:07+00	\N	drum and bass
2946	13	1HFfMOxCAT4GAwaPfCdmUs	\N	Waves - Robin Schulz Radio Edit	Mr. Probz, Robin Schulz	1qzcdqlwqtm8lnthmvh2a70p9	2025-12-04 18:29:51+00	\N	house
2939	12	1DcBU8x5d7BrCIcgTfIRzk	\N	Full Circle	HÆLOS	31pd6hnytykuevog22xwj5yn2qjy	2025-12-17 09:00:15+00	\N	alternative dance
2963	13	1di1BEgJYzPvXUuinsYJGP	\N	Everybody (Backstreet's Back) - Radio Edit	Backstreet Boys	313neyxbfwxtbi2t52gjvliqxisa	2025-12-11 12:29:06+00	\N	pop
2917	12	1LpH5yxahJqkjx8fScOErX	\N	My Shy (feat. Loco)	MIRANI, Loco	1qzcdqlwqtm8lnthmvh2a70p9	2025-12-16 07:05:47+00	\N	k-rap
2956	13	1MJjw68l1Djgbq04BRggsn	\N	In the Heat of a Disco Night	Arabesque	313neyxbfwxtbi2t52gjvliqxisa	2025-12-10 14:02:40+00	\N	disco, europop
2927	12	2DimMk00BsDm19bbxTzY03	\N	Ride	Klangkarussell	1qzcdqlwqtm8lnthmvh2a70p9	2025-12-16 18:37:39+00	\N	electronic
2955	13	1pIOXT3xVnhzLZPEdFqAbo	\N	Horizons	Abyss, Watching Me	313neyxbfwxtbi2t52gjvliqxisa	2025-12-10 14:02:37+00	\N	post-hardcore, metalcore, melodic hardcore
2964	13	2HWWNoWEEEECwZhAiLg7ib	\N	Beautiful Liar	Beyoncé, Shakira	313neyxbfwxtbi2t52gjvliqxisa	2025-12-11 12:30:27+00	\N	r&b
2933	12	3IKQE65L4pPqfRMA0tYOfY	\N	Running Through You	Foreign Air	31pd6hnytykuevog22xwj5yn2qjy	2025-12-17 08:50:40+00	\N	indie
2954	13	2U1ezHUURWjfgokoVXd5BM	\N	Бей или Беги	BURIAL FOR ALIVE, BLACK SCUM, At The Ruins	313neyxbfwxtbi2t52gjvliqxisa	2025-12-10 14:02:34+00	\N	metalcore
2957	13	2blfyjIMMhX4rZNVPoYmgF	\N	Crazy	W.A.S.P.	313neyxbfwxtbi2t52gjvliqxisa	2025-12-10 14:02:43+00	\N	glam metal, heavy metal, glam rock, hard rock, metal
2974	14	3HmiQQZ7CiXolIf8odAP8p	\N	Вижу тебя	Alena Vysotskaya	1qzcdqlwqtm8lnthmvh2a70p9	2025-12-04 13:14:09+00	\N	dance pop
2960	13	3iX71cc5aPQtEflMD61gUl	\N	Розалия	osiwoy	31ghi62vkgnlb4wqr6muaisx7ldi	2025-12-11 12:13:41+00	\N	pop
2942	13	3ZrWmt3DGH75hItHp6uWLz	\N	Imagination	Gorgon City, Katy Menditta	1qzcdqlwqtm8lnthmvh2a70p9	2025-12-04 18:28:31+00	\N	house
2944	13	412luShbmlgqqgYFStIB1s	\N	Wish You Were Mine - Radio Edit	Philip George	1qzcdqlwqtm8lnthmvh2a70p9	2025-12-04 18:29:03+00	\N	house
2970	14	46jMfS29Fnbl2ylgNcIl1t	\N	О тебе	Ранетки	1qzcdqlwqtm8lnthmvh2a70p9	2025-12-04 13:06:04+00	\N	pop
2934	12	43niiTshfUdTN32wHykv7h	\N	Cajun Moon	J.J. Cale	31pd6hnytykuevog22xwj5yn2qjy	2025-12-17 08:51:17+00	\N	blues, blues rock, roots rock
2919	12	459NVRkYEftpuwkmSH1U1H	\N	Drag Me	From Ashes to New	313neyxbfwxtbi2t52gjvliqxisa	2025-12-16 12:52:12+00	\N	rap rock, rap metal, metalcore
2975	14	5AF94d85xnq2fCWsiU6jpA	\N	Забавы (Cover) [Из сериала "Чёрная весна"]	Глеб Калюжный	31ghi62vkgnlb4wqr6muaisx7ldi	2025-12-04 13:15:33+00	\N	soundtrack
2945	13	483XiZ5o13Cc1zoWV7jGml	\N	Gecko (Overdrive) - Radio Edit	Oliver Heldens, Becky Hill	1qzcdqlwqtm8lnthmvh2a70p9	2025-12-04 18:29:11+00	\N	future house, house
2943	13	4J7CKHCF3mdL4diUsmW8lq	\N	Under Control (feat. Hurts)	Calvin Harris, Alesso, Hurts	1qzcdqlwqtm8lnthmvh2a70p9	2025-12-04 18:28:52+00	\N	edm
2941	13	4PTPZeJlK1rYlYr6bf11hk	\N	You're On (feat. Kyan)	Madeon, Kyan	1qzcdqlwqtm8lnthmvh2a70p9	2025-12-04 18:30:43+00	\N	edm, french house
2925	12	4SupI9OXg3hwrymR85hkhL	\N	Signal	TK from Ling tosite sigure	1qzcdqlwqtm8lnthmvh2a70p9	2025-12-16 18:17:14+00	\N	anime, j-rock, j-pop
2930	12	4etHuFADJ1ZxYYLj40nEiu	\N	On & On	Chris Lake, Yael Watchman	1qzcdqlwqtm8lnthmvh2a70p9	2025-12-17 03:28:14+00	\N	tech house, house, bass house
2931	12	4xiyq1iRdsxuU1BPUJ490Z	\N	Close To Me	The Cure	31pd6hnytykuevog22xwj5yn2qjy	2025-12-17 08:49:13+00	\N	new wave, post-punk, gothic rock, darkwave
2952	13	5YIhyQTdOcuwn0VMeVwvAp	\N	No Audience	Absolutely	31ghi62vkgnlb4wqr6muaisx7ldi	2025-12-07 05:49:31+00	\N	indie
2936	12	5P13mfqn9o3ToFPTxowEgO	\N	This Is The New Shit	Marilyn Manson	31pd6hnytykuevog22xwj5yn2qjy	2025-12-17 08:54:31+00	\N	industrial metal, industrial rock, industrial, metal, nu metal
2961	13	5rVmXAUzcqwFavYxkGmCfU	\N	Облако	ТАйМСКВЕР, TRITIA	313neyxbfwxtbi2t52gjvliqxisa	2025-12-11 12:25:17+00	\N	electronic
2928	12	5Z2VHBaoe8F0btMfHDGmoB	\N	More Than Friends (VIP)	KAYA!	1qzcdqlwqtm8lnthmvh2a70p9	2025-12-16 18:47:09+00	\N	bass house
2951	13	64dLd6rVqDLtkXFYrEUHIU	\N	New Gold (feat. Tame Impala and Bootie Brown)	Gorillaz, Tame Impala, Bootie Brown	31ghi62vkgnlb4wqr6muaisx7ldi	2025-12-07 05:47:56+00	\N	alternative rock
2940	12	6JnM93vUP3T2ZHJH5P35JY	\N	Mystery (The Power Within)	Plazma	31pd6hnytykuevog22xwj5yn2qjy	2025-12-17 09:00:52+00	\N	electronic
2935	12	6J3HNhDBIwEX11bX8hzx5u	\N	Colors	Black Pumas	31pd6hnytykuevog22xwj5yn2qjy	2025-12-17 08:52:26+00	\N	retro soul
2953	13	6SHHOGkdLpRu20CVUY0qg2	\N	Will	Blacklit Canopy Official	313neyxbfwxtbi2t52gjvliqxisa	2025-12-10 14:02:28+00	\N	indie
2918	12	6ipw1z69D9e5QZqx6zeKlz	\N	Bittersweet Dreams	David Kushner	313neyxbfwxtbi2t52gjvliqxisa	2025-12-16 12:45:36+00	\N	pop
2971	14	6Tsu3OsuMz4KEGKbOYd6A0	\N	Hypnotize - 2007 Remaster	The Notorious B.I.G.	31ghi62vkgnlb4wqr6muaisx7ldi	2025-12-04 13:06:30+00	\N	old school hip hop, gangster rap, east coast hip hop, hip hop
2968	13	6e0LjNPkRqxIAlmmdjWSV8	\N	Moi... Lolita	Alizée	313neyxbfwxtbi2t52gjvliqxisa	2025-12-11 12:40:43+00	\N	french pop
2962	13	6r8k1vznHrzlEKYxL4dZEe	\N	La Isla Bonita	Madonna	313neyxbfwxtbi2t52gjvliqxisa	2025-12-11 12:27:14+00	\N	pop
2947	13	6r7FXNO57mlZCBY6PXcZZT	\N	Five Hours	Deorro	1qzcdqlwqtm8lnthmvh2a70p9	2025-12-04 18:28:29+00	\N	melbourne bounce, electro house
2969	14	6vUsbsF8mYV6LeEDioHNib	\N	На нашей стороне	AIGEL	31ghi62vkgnlb4wqr6muaisx7ldi	2025-12-04 13:05:39+00	\N	rap
2922	12	7apywiCuMzvSZIa0SKeH99	\N	Turn The Lights Off - Radio Edit	Kato, Jon	313neyxbfwxtbi2t52gjvliqxisa	2025-12-16 13:02:23+00	\N	house
2937	12	73vKkEdcnomvHrsVv0Aqvs	\N	Power	Kove	31pd6hnytykuevog22xwj5yn2qjy	2025-12-17 08:56:38+00	\N	drum and bass, liquid funk
2973	14	7nxyz1pIprjv7vWPtywyVW	\N	Если в сердце живёт любовь	Yulia Savicheva	1qzcdqlwqtm8lnthmvh2a70p9	2025-12-04 13:13:48+00	\N	pop
2972	14	7vidktgNZFQylTgH1GEnMs	\N	Cold as Ice	Foreigner	31ghi62vkgnlb4wqr6muaisx7ldi	2025-12-04 13:09:10+00	\N	aor, classic rock
2923	12	0ntQJM78wzOLVeCUAW7Y45	\N	Sex on Fire	Kings of Leon	313neyxbfwxtbi2t52gjvliqxisa	2025-12-16 14:09:00+00	\N	rock
3035	16	0rE2IY6L1qLxAEQxxZkQOG	\N	Lost Woods	VGR	1qzcdqlwqtm8lnthmvh2a70p9	2025-11-19 07:22:28+00	\N	electronic
3002	14	0bGJ14HHArD8n3FKqElIik	\N	Swoon - Boys Noize Summer Remix	The Chemical Brothers, Boys Noize	1qzcdqlwqtm8lnthmvh2a70p9	2025-12-04 18:00:43+00	\N	big beat, alternative dance, electronic, breakbeat
3039	16	0hDQV9X1Da5JrwhK8gu86p	\N	Maps	Yeah Yeah Yeahs	31ghi62vkgnlb4wqr6muaisx7ldi	2025-11-19 08:50:38+00	\N	indie rock
3000	14	0vg4WnUWvze6pBOJDTq99k	\N	You're Beautiful	James Blunt	1qzcdqlwqtm8lnthmvh2a70p9	2025-12-04 17:58:34+00	\N	pop
2999	14	1BmVQ5RGqqtF5cnsv6cQYu	\N	Girl, You'll Be A Woman Soon	Neil Diamond	1qzcdqlwqtm8lnthmvh2a70p9	2025-12-04 17:57:11+00	\N	rock
3015	15	1Hv1VTm8zeOeybub15mA2R	\N	Smooth Operator - Single Version	Sade	1qzcdqlwqtm8lnthmvh2a70p9	2025-11-25 06:50:58+00	\N	r&b
2998	14	1D6e4MY1rGEAD4jZI9akEJ	\N	Atlantis To Interzone	Klaxons	1qzcdqlwqtm8lnthmvh2a70p9	2025-12-04 17:56:50+00	\N	new rave, alternative dance, indie
3027	15	1nb7rblnhiEa4gnBZTNaAf	\N	Белый кролик	СЕКУШАРЮ	31ghi62vkgnlb4wqr6muaisx7ldi	2025-11-28 10:40:59+00	\N	pop
3001	14	1TXBYUD9hRWkuVb3uLw5Yx	\N	Smack My Bitch Up	The Prodigy	1qzcdqlwqtm8lnthmvh2a70p9	2025-12-04 17:59:48+00	\N	big beat, breakbeat
3010	15	24HX6DFk6zw3rT6uGwzelj	\N	Обречён	ГРАНЖ	313neyxbfwxtbi2t52gjvliqxisa	2025-11-22 08:22:34+00	\N	metalcore
2993	14	1udKn1oNKYQSQ9OmiIWCMu	\N	Do You Believe in Magic?	The Lovin' Spoonful	1qzcdqlwqtm8lnthmvh2a70p9	2025-12-04 17:49:31+00	\N	folk rock
3024	15	24UTdotuXBQcdrW0f7ydmj	\N	A Kiss From A Mother	Marmozets	31ghi62vkgnlb4wqr6muaisx7ldi	2025-11-28 10:35:59+00	\N	alternative rock
3023	15	2D8Oc2zqXLEjgO8SqehGHG	\N	I Never Felt so Right - Radio Mix	Ben Delay	313neyxbfwxtbi2t52gjvliqxisa	2025-11-26 12:23:45+00	\N	house
3003	14	2An6N9gMUuhRln1smrPsjP	\N	Restless	UNKLE	1qzcdqlwqtm8lnthmvh2a70p9	2025-12-04 18:01:22+00	\N	trip hop, downtempo
2979	14	2HU7kCffSyqeDU4XGjotj5	\N	Ангелы здесь больше не живут	Ульяна Karakoz	313neyxbfwxtbi2t52gjvliqxisa	2025-12-04 13:23:23+00	\N	pop
3013	15	2u2udGmop1z67EPpr91km7	\N	Man in the Mirror	Michael Jackson	1qzcdqlwqtm8lnthmvh2a70p9	2025-11-22 18:15:30+00	\N	pop
3017	15	2PpruBYCo4H7WOBJ7Q2EwM	\N	Hey Ya!	Outkast	1qzcdqlwqtm8lnthmvh2a70p9	2025-11-25 07:08:11+00	\N	southern hip hop, hip hop
3038	16	2YuySJd7C2aoBarBP8OvzR	\N	drifting	Night Tapes	31ghi62vkgnlb4wqr6muaisx7ldi	2025-11-19 08:49:58+00	\N	dream pop, lo-fi indie
2988	14	3Fzlg5r1IjhLk2qRw667od	\N	Dancing in the Moonlight	Toploader	1qzcdqlwqtm8lnthmvh2a70p9	2025-12-04 17:45:04+00	\N	rock
3021	15	2wNEcJHnFxoKZIrxjxF5jL	\N	Changes - 2009 Remaster	Black Sabbath	313neyxbfwxtbi2t52gjvliqxisa	2025-11-26 02:20:04+00	\N	metal, heavy metal, rock, stoner rock, doom metal, hard rock
3012	15	30XU4suKzCeoCK9YFzdufg	\N	Born This Way	Lady Gaga	1qzcdqlwqtm8lnthmvh2a70p9	2025-11-22 18:14:26+00	\N	art pop, pop
2978	14	3CkOtZkhSnHbgfZfZ7j0cW	\N	The Gift	Storefront Church	31ghi62vkgnlb4wqr6muaisx7ldi	2025-12-04 13:20:12+00	\N	baroque pop
3033	16	3Xf7Njd3lTqZbNkeLPGoFH	\N	Bruised Sky	Poppy	313neyxbfwxtbi2t52gjvliqxisa	2025-11-14 17:08:29+00	\N	pop
3031	16	3tCUsGxelMu2RPwsavVkcn	\N	She	Exiles of Eden	313neyxbfwxtbi2t52gjvliqxisa	2025-11-14 16:59:54+00	\N	metalcore
2995	14	3spdoTYpuCpmq19tuD0bOe	\N	My Way	Frank Sinatra	1qzcdqlwqtm8lnthmvh2a70p9	2025-12-04 17:51:28+00	\N	christmas, big band, adult standards, swing music, jazz, vocal jazz
2990	14	4XjXXK9GhDdMVR8xMKZLih	\N	All Die Young	Smith Westerns	1qzcdqlwqtm8lnthmvh2a70p9	2025-12-04 17:45:54+00	\N	indie
2991	14	4KfSdst7rW39C0sfhArdrz	\N	Barracuda	Heart	1qzcdqlwqtm8lnthmvh2a70p9	2025-12-04 17:46:05+00	\N	classic rock, aor, rock
3034	16	4Wivm22R3D8WxExv39k25M	\N	Les Champs-Élysées	Joe Dassin	1qzcdqlwqtm8lnthmvh2a70p9	2025-11-17 16:23:33+00	\N	chanson, variété française, french pop
2986	14	4mC1JWF1nws66asz3pY39U	\N	7 Этаж	Лера Массква	1qzcdqlwqtm8lnthmvh2a70p9	2025-12-04 17:07:37+00	\N	pop
3007	14	4hC7fmtx9LmjruoIieWT0m	\N	Tuyo	Rodrigo Amarante	1qzcdqlwqtm8lnthmvh2a70p9	2025-12-04 18:11:29+00	\N	new mpb
3028	15	5B4KCvxyTOLq5ge4k2SJ9g	\N	Пляска Дурака	Рубеж Веков	313neyxbfwxtbi2t52gjvliqxisa	2025-11-28 11:03:05+00	\N	rock
2994	14	4mn2kNTqiGLwaUR8JdhJ1l	\N	House of the Rising Sun	The Animals	1qzcdqlwqtm8lnthmvh2a70p9	2025-12-04 17:49:49+00	\N	classic rock
2992	14	59hKzj0h6ElhQv8rBqvpUz	\N	Santa Baby	Eartha Kitt	1qzcdqlwqtm8lnthmvh2a70p9	2025-12-04 17:48:07+00	\N	christmas
2981	14	5FCPN8g30PRH7lLgxDh9LQ	\N	Big Bang Theory Theme	Barenaked Ladies	313neyxbfwxtbi2t52gjvliqxisa	2025-12-04 13:25:50+00	\N	rock
3008	14	5KYlShe7JJ6WkixcptTHfR	\N	Идем на восток!	Nogu Svelo!	1qzcdqlwqtm8lnthmvh2a70p9	2025-12-04 18:20:40+00	\N	rock
3025	15	68ikyrqKSYIgijyLDd3VxL	\N	Bloodshot	TENDER, Blood Moon Commune	31ghi62vkgnlb4wqr6muaisx7ldi	2025-11-28 10:39:27+00	\N	indie
2984	14	5dcwiQFqn0mTcWewYIv7MV	\N	Personal Jesus	Johnny Cash	313neyxbfwxtbi2t52gjvliqxisa	2025-12-04 13:48:04+00	\N	classic country, outlaw country, country
2989	14	5drK2kTE2mrUdV33iHWyrx	\N	Mad About You	Hooverphonic	1qzcdqlwqtm8lnthmvh2a70p9	2025-12-04 17:45:39+00	\N	trip hop, downtempo
2983	14	67Hna13dNDkZvBpTXRIaOJ	\N	Teardrop	Massive Attack, Elizabeth Fraser	313neyxbfwxtbi2t52gjvliqxisa	2025-12-04 13:31:22+00	\N	trip hop, downtempo
3036	16	6Bv7bmLr2hsqWrv7wQie5j	\N	Kushani	Ganki Ro	31ghi62vkgnlb4wqr6muaisx7ldi	2025-11-19 08:46:45+00	\N	electronic
3020	15	6Ad0B1y1T0FLCAxCIQ4UFO	\N	Cat Size	Suzi Quatro	1qzcdqlwqtm8lnthmvh2a70p9	2025-11-25 07:21:46+00	\N	glam rock
3026	15	6O1Kor0zSUKC4nUmmAjJKd	\N	POUND CAKE	THOT SQUAD	31ghi62vkgnlb4wqr6muaisx7ldi	2025-11-28 10:40:07+00	\N	rap
3022	15	7mDpSCc7Q79Vajmly9mF8o	\N	It's Me Again	Jutes	313neyxbfwxtbi2t52gjvliqxisa	2025-11-26 11:47:49+00	\N	indie
3032	16	6P0W0azMoFa2GchGcRlQdA	\N	O Come, O Come Emmanuel	Skillet	313neyxbfwxtbi2t52gjvliqxisa	2025-11-14 17:06:14+00	\N	christian rock, christian alternative rock, christian
2996	14	6UaxyaWcV9Os9BcZet6Dem	\N	The Nightingale	Julee Cruise	1qzcdqlwqtm8lnthmvh2a70p9	2025-12-04 17:53:28+00	\N	dream pop
2987	14	7bsPIUEEOuL5WlOPcYUrYx	\N	Blood Like Lemonade	Morcheeba	1qzcdqlwqtm8lnthmvh2a70p9	2025-12-04 17:43:46+00	\N	trip hop, downtempo
3005	14	7nVrcnXTkx8qyluCUjvpxE	\N	Sabotage	Beastie Boys	1qzcdqlwqtm8lnthmvh2a70p9	2025-12-04 18:03:47+00	\N	rap rock, old school hip hop, east coast hip hop, hip hop
3037	16	7v9Ne4758aGFfFc5avh89h	\N	Let's Dance to Joy Division	The Wombats	31ghi62vkgnlb4wqr6muaisx7ldi	2025-11-19 08:49:14+00	\N	indie
3030	16	0PgJorhYB2t6RzzKFPoVy2	\N	Shatter Me	Broken Altar	313neyxbfwxtbi2t52gjvliqxisa	2025-11-14 16:59:48+00	\N	metal
3088	17	0Hidjc4ndTpk8sTWOb7OWK	\N	Coral Crown	Rocketbull	31ghi62vkgnlb4wqr6muaisx7ldi	2025-11-13 07:14:38+00	\N	indie
3061	17	162z2RVFkctC9SzRSOn1rC	\N	Still Here (Even When I'm Not) - Acoustic	Exiles of Eden	313neyxbfwxtbi2t52gjvliqxisa	2025-11-12 00:12:42+00	\N	indie
3087	17	0WRX3taWc0jMkL6ZYZqMCj	\N	OKAY!	Internet Girl	31ghi62vkgnlb4wqr6muaisx7ldi	2025-11-13 07:11:16+00	\N	hyperpop
3042	16	0WngwdBLS8hFbq1C45DiMJ	\N	The Unknowing	Jfarrari	31ghi62vkgnlb4wqr6muaisx7ldi	2025-11-19 08:52:34+00	\N	darkwave, post-punk, cold wave
3054	16	0bqOf2AaPI7Sqpc39q8Y2b	\N	Encore une fois	Orelsan, Yamê	1qzcdqlwqtm8lnthmvh2a70p9	2025-11-19 23:55:26+00	\N	french rap
3078	17	1b2hYZX5ha6fUd9Hh9KTVf	\N	Сгущенные облака	blago white	1qzcdqlwqtm8lnthmvh2a70p9	2025-11-12 19:50:04+00	\N	pop
3045	16	1CedH7KCdaEN322k8zWPU4	\N	(AND) NOW I SEE THE LIGHT	toe, Jonah Yano	1qzcdqlwqtm8lnthmvh2a70p9	2025-11-19 23:31:21+00	\N	math rock, post-rock, midwest emo, japanese indie
3059	17	1EvYAo0qfXX8ug2tnzsRmO	\N	Bruised	SAVE US	313neyxbfwxtbi2t52gjvliqxisa	2025-11-10 00:40:35+00	\N	metalcore
3084	17	1Gi1l9BcXucxB4SoHligBR	\N	NEW ROCK	Lida	1qzcdqlwqtm8lnthmvh2a70p9	2025-11-12 19:55:07+00	\N	happy hardcore
3095	17	1eKfKq48ISKXlXqrEAtPgc	\N	То, что я есть	UBEL	1qzcdqlwqtm8lnthmvh2a70p9	2025-11-13 20:21:33+00	\N	pop
3093	17	2MvMYKohOQ48vutYClFn16	\N	До мурашек	Амура, The Narcissus	1qzcdqlwqtm8lnthmvh2a70p9	2025-11-13 20:18:53+00	\N	pop
3047	16	1lJ7NGMWQYSxy49zj6wvdQ	\N	Beautiful	AnnenMayKantereit	1qzcdqlwqtm8lnthmvh2a70p9	2025-11-19 23:37:59+00	\N	german indie, german pop, german indie pop
3051	16	2BK4Z800UYNDAAerwSXnzr	\N	Compass	Uchu Conbini	1qzcdqlwqtm8lnthmvh2a70p9	2025-11-19 23:47:12+00	\N	math rock, japanese indie, midwest emo, j-rock, post-rock
3062	17	2OZVskV28xxJjjhQqKTLSg	\N	PIXELATED KISSES	Joji	1qzcdqlwqtm8lnthmvh2a70p9	2025-11-12 19:19:44+00	\N	alternative rock
3089	17	2cQNM4HWpgdxJbuefUSpwy	\N	The Night	Oslo Parks	31ghi62vkgnlb4wqr6muaisx7ldi	2025-11-13 07:19:40+00	\N	indie
3058	16	2nGY8MpZwT9bYuZWFbW3ve	\N	Братишка	Bogdan Kiyashko	31ghi62vkgnlb4wqr6muaisx7ldi	2025-11-21 04:53:20+00	\N	pop
3096	17	3B3eOgLJSqPEA0RfboIQVM	\N	Skinny Love	Bon Iver	1qzcdqlwqtm8lnthmvh2a70p9	2025-11-13 21:37:36+00	\N	indie
3052	16	2q2Bp2OnN8HF0grI6HIJQG	\N	dance and	chouchou merged syrups.	1qzcdqlwqtm8lnthmvh2a70p9	2025-11-19 23:49:35+00	\N	math rock, j-rock, japanese indie, shoegaze
3083	17	46i6oWlLNJVhUPaRnWX6v0	\N	Upside	Porch Light	1qzcdqlwqtm8lnthmvh2a70p9	2025-11-12 19:54:49+00	\N	indie
3100	18	3ElEx0U0P8tR4LXtCqkqyy	\N	Slow Devotion	Leon Vynehall	1qzcdqlwqtm8lnthmvh2a70p9	2025-11-04 10:36:16+00	\N	lo-fi house, deep house
3074	17	3ZdhzuJ1ar90QR5SUWXVAy	\N	Dat Boi	Polar Youth	1qzcdqlwqtm8lnthmvh2a70p9	2025-11-12 19:41:44+00	\N	drum and bass
3066	17	3kKkotHkHnTjXlL4N8Aqv3	\N	Turn The Lights Off	Dead Eyes	1qzcdqlwqtm8lnthmvh2a70p9	2025-11-12 19:31:43+00	\N	metalcore
3053	16	3pT5vtG177l2jrxpPy76jB	\N	Dramatic	MASS OF THE FERMENTING DREGS	1qzcdqlwqtm8lnthmvh2a70p9	2025-11-19 23:53:57+00	\N	j-rock, shoegaze, japanese indie, math rock, shibuya-kei
3101	18	4F6W3AAyTG40BSKawcmjBq	\N	The Storm Will Fade	Last Ashes	313neyxbfwxtbi2t52gjvliqxisa	2025-11-06 06:53:48+00	\N	post-hardcore
3072	17	4JZQUZhqxhK6L5BPfIS4jK	\N	Forever Young	Zivert, LYRIQ	1qzcdqlwqtm8lnthmvh2a70p9	2025-11-12 19:37:17+00	\N	pop
3070	17	4K49GNARzyKM5WuZVLB6Jy	\N	Giving Up Air	The Temper Trap	1qzcdqlwqtm8lnthmvh2a70p9	2025-11-12 19:35:24+00	\N	indie
3098	17	4aN6JbV22sigJuPRqU8Kz0	\N	Trauma Bonds	Fall To Pieces	313neyxbfwxtbi2t52gjvliqxisa	2025-11-14 00:45:38+00	\N	emo
3064	17	4UDguq9kRecAxXZZl2kH1P	\N	Body Go (with Tyla)	MOLIY, Tyla	1qzcdqlwqtm8lnthmvh2a70p9	2025-11-12 19:23:26+00	\N	alté
3071	17	4WIxKjPg1bJoRyun7xQsAO	\N	omni shambles	bar italia	1qzcdqlwqtm8lnthmvh2a70p9	2025-11-12 19:35:31+00	\N	lo-fi indie
3044	16	5JbxiG90IN2anqHToMdlGT	\N	Бесполезно	Valentin Strykalo	1qzcdqlwqtm8lnthmvh2a70p9	2025-11-19 19:51:24+00	\N	pop
3040	16	4fewUk0x2mSkelKYpFxE1u	\N	Rare	Ralph Castelli	31ghi62vkgnlb4wqr6muaisx7ldi	2025-11-19 08:50:50+00	\N	bedroom pop
3057	16	4pjSe7n2609YnMWnrJ3OVJ	\N	Left For Good	Bad Omens	313neyxbfwxtbi2t52gjvliqxisa	2025-11-20 22:25:12+00	\N	metalcore
3049	16	54Yr0BPkVQ378IeCWnG91Q	\N	Burning (feat. Camden Cox)	Eli & Fur, Camden Cox	1qzcdqlwqtm8lnthmvh2a70p9	2025-11-19 23:43:16+00	\N	melodic house, deep house, melodic techno, progressive house
3068	17	5lzUEsc8znqAzlBVewkony	\N	From the Bottom of My Heart	Cyan Kicks	1qzcdqlwqtm8lnthmvh2a70p9	2025-11-12 19:32:39+00	\N	indie
3094	17	5Jxm5J3EtAUfOSKdi0Vqg6	\N	Ярче (2020)	Biicla, Polovinka	1qzcdqlwqtm8lnthmvh2a70p9	2025-11-13 20:19:15+00	\N	stutter house, uk garage
3069	17	5qy96tWV5WWgJLiXuinD7e	\N	Drive Myself Home	South Arcade	1qzcdqlwqtm8lnthmvh2a70p9	2025-11-12 19:34:10+00	\N	indie
3043	16	5q2CLyzCePYCmQ6wCweFTl	\N	△	downy	1qzcdqlwqtm8lnthmvh2a70p9	2025-11-19 23:25:30+00	\N	math rock, post-rock, j-rock, shoegaze, japanese indie
3080	17	676fXA0Z4DhqXCrz5Bm4ho	\N	AGAIN	EDDIE, Nikademis	1qzcdqlwqtm8lnthmvh2a70p9	2025-11-12 19:50:57+00	\N	pop
3063	17	6sj5SvhYykiM1yWBWYB3Oc	\N	out of body	Khalid	1qzcdqlwqtm8lnthmvh2a70p9	2025-11-12 19:20:41+00	\N	r&b
3050	16	6IEvkHKKxpb3AibvUeF9Vm	\N	come to me	Eternal Rin	1qzcdqlwqtm8lnthmvh2a70p9	2025-11-19 23:47:00+00	\N	shoegaze
3081	17	6V4ntlX6608rd3Ec5SpVhj	\N	Berghain	ROSALÍA, Björk, Yves Tumor	1qzcdqlwqtm8lnthmvh2a70p9	2025-11-12 19:51:29+00	\N	latin
3055	16	6aH1WkRWWu9GDKIUSOwaJt	\N	The End (feat. BABYMETAL) - 2025 VERSION	Five Finger Death Punch, BABYMETAL	1qzcdqlwqtm8lnthmvh2a70p9	2025-11-19 23:55:50+00	\N	metal, groove metal, heavy metal, hard rock, rock
3086	17	6w5atIsxVNKPERC9UYuiaD	\N	На берегу неба	Dima Bilan	313neyxbfwxtbi2t52gjvliqxisa	2025-11-13 06:14:57+00	\N	pop
3075	17	76YCfHAXDAcalBv3DpBlgo	\N	Medusa	Edda Hayes, 2WEI	1qzcdqlwqtm8lnthmvh2a70p9	2025-11-12 19:45:05+00	\N	soundtrack
3090	17	7eoCVTfJZtXiCLRxj9P5Al	\N	Из алого	Nizkiz	31ghi62vkgnlb4wqr6muaisx7ldi	2025-11-13 07:32:28+00	\N	folk
3065	17	7bNyAYmLg7HPLqi4YUysTA	\N	DNCR	Kaskade	1qzcdqlwqtm8lnthmvh2a70p9	2025-11-12 19:23:56+00	\N	edm
3092	17	7fDote2ATRnorv2SCoGKCO	\N	Души	LAVBLAST, Рудольф Страусов, SP4K	31ghi62vkgnlb4wqr6muaisx7ldi	2025-11-13 07:34:47+00	\N	hip hop
3091	17	7gKFpRLqRsIu0s5Y7lbguY	\N	Let Me Come To Life	Klangkarussell	1qzcdqlwqtm8lnthmvh2a70p9	2025-11-13 07:33:14+00	\N	house
3073	17	7vtaK5RulcaAk5qxFMzOkC	\N	На реальных событиях	U-TOPIA, RAM	1qzcdqlwqtm8lnthmvh2a70p9	2025-11-12 19:39:47+00	\N	electronic
3067	17	0GcX7hGiXATzis6ViSderK	\N	Burnout	Girl Tones	1qzcdqlwqtm8lnthmvh2a70p9	2025-11-12 19:32:07+00	\N	indie
3138	19	0REDIottLxGZporOoJnwik	\N	Ghost Vibrations	Taken By Tides	1qzcdqlwqtm8lnthmvh2a70p9	2025-10-31 02:17:08+00	\N	metalcore
3133	19	0bNvoSFTXDKLO7fGSgry5D	\N	Tenía Razón	Daniela Lalita	31ghi62vkgnlb4wqr6muaisx7ldi	2025-10-30 14:01:30+00	\N	latin
3129	19	0Sfle7MdEtJOE6bt6uhNtY	\N	Freestyle - PhaseOne Remix	PhaseOne, Fox Lake	313neyxbfwxtbi2t52gjvliqxisa	2025-10-29 07:25:26+00	\N	dubstep, deathstep, riddim, bass music
3226	22	0W9Xvd4Qx1aZPxEi94vgRY	\N	Sound of Madness	Shinedown	313neyxbfwxtbi2t52gjvliqxisa	2025-09-26 10:30:06+00	\N	post-grunge, alternative metal, rock
3105	18	0yENhJtiAOrDv8UBg0lZBO	\N	Мало попотела	Опия	1qzcdqlwqtm8lnthmvh2a70p9	2025-11-06 12:08:43+00	\N	pop
3126	19	13QI6bq0U8HMK7gUpAwFBK	\N	Trip Switch	Nothing But Thieves	313neyxbfwxtbi2t52gjvliqxisa	2025-10-27 12:57:22+00	\N	alternative rock
3143	19	2GIWu6BrK8Bu5mSYlvSQYN	\N	Ashes & Echoes	Hollow Ember	313neyxbfwxtbi2t52gjvliqxisa	2025-11-01 02:16:36+00	\N	metal
3149	20	13ZoE8VJxZX2CPuEelnNun	\N	Denmark	Fevermind	1qzcdqlwqtm8lnthmvh2a70p9	2025-10-15 06:01:25+00	\N	melodic hardcore
3106	18	16HjVFz4qEWEvEqGav00X3	\N	苒	downy	1qzcdqlwqtm8lnthmvh2a70p9	2025-11-06 17:29:29+00	\N	math rock, post-rock, j-rock, shoegaze, japanese indie
3161	20	1E13xo4T9lS4S6bLOSyf3k	\N	Russian Summer	Past Day	31ghi62vkgnlb4wqr6muaisx7ldi	2025-10-22 10:55:08+00	\N	post-punk
3119	18	1HHYSGgVFEe5XlnzM3FARW	\N	Silent Night	SennaRin	1qzcdqlwqtm8lnthmvh2a70p9	2025-11-07 09:01:30+00	\N	anime
3131	19	1cel0wCtqwRH0hRWSA2ani	\N	Jamais	Tessa B. 	31ghi62vkgnlb4wqr6muaisx7ldi	2025-10-30 14:00:13+00	\N	french pop
3140	19	1mK4v6sSCbKR2mMAWG2zMy	\N	Obsession	Thornhill	313neyxbfwxtbi2t52gjvliqxisa	2025-10-31 07:34:22+00	\N	metalcore, djent, shoegaze
3142	19	1pUsdir2xhSxP0RyBe9lLH	\N	Icarus	Madeon	313neyxbfwxtbi2t52gjvliqxisa	2025-10-31 23:18:26+00	\N	edm, french house
3160	20	2B2r9ZYdlvntDcwmYydnsx	\N	The Laugh Track	Ice Nine Kills	313neyxbfwxtbi2t52gjvliqxisa	2025-10-17 07:30:20+00	\N	metalcore, metal
3112	18	2OBV9xYIRF1FsToNOBhwK6	\N	Пауза как судороги	Azar Strato, BATO	31ghi62vkgnlb4wqr6muaisx7ldi	2025-11-07 08:29:03+00	\N	electronic
3109	18	2HjkMGuV0oim3m8vZpfjFw	\N	Starscream Forever	Savant, Qwentalis	313neyxbfwxtbi2t52gjvliqxisa	2025-11-07 02:45:50+00	\N	dubstep, drumstep
3162	20	2gGCt2yXxDxDITx19sxwJJ	\N	We Bad, We Know	ZOI, Byfox	31ghi62vkgnlb4wqr6muaisx7ldi	2025-10-22 10:55:56+00	\N	trap
3108	18	2OiCjRiQksvfYyLW3kLxb0	\N	Dragonborn - Original Mix	Headhunterz	313neyxbfwxtbi2t52gjvliqxisa	2025-11-07 02:38:33+00	\N	hardstyle, frenchcore, melbourne bounce, big room, hardcore
3136	19	3EI5hCVItB6s7v6APkYJUW	\N	Breadwinner	Everything Everything	31ghi62vkgnlb4wqr6muaisx7ldi	2025-10-30 14:03:06+00	\N	alternative rock
3114	18	2iLXob2hgJHqsqPdU8dRdt	\N	Nod-Krai	HOYO-MiX, AURORA	31ghi62vkgnlb4wqr6muaisx7ldi	2025-11-07 08:29:25+00	\N	soundtrack
3130	19	3Hrdh8vuUbeCK6bFkd4HZX	\N	Throne Of Want	Cenobia	313neyxbfwxtbi2t52gjvliqxisa	2025-10-29 23:11:11+00	\N	metal
3154	20	3ODhhllXt3MVuSxZCYPrdE	\N	Heroine	Satellite Stories	31pd6hnytykuevog22xwj5yn2qjy	2025-10-16 13:36:34+00	\N	indie
3153	20	3T4NFCEeCZ4djrs8pBzJgg	\N	Дарите женщинам цветы	Jazzdauren	1qzcdqlwqtm8lnthmvh2a70p9	2025-10-16 11:30:02+00	\N	jazz
3116	18	3XXsFfSWeKX9Gy1YeXgmaa	\N	Сидр	Бонд с кнопкой	31ghi62vkgnlb4wqr6muaisx7ldi	2025-11-07 08:29:45+00	\N	indie
3113	18	3XjomrNmJM2JoBvo4vGIBP	\N	Скинь котиков	Mirèle	31ghi62vkgnlb4wqr6muaisx7ldi	2025-11-07 08:29:18+00	\N	electronic
3127	19	4PmlV5JtsfJNyahWXKZWRj	\N	Шторм	KOMMO, RAM	313neyxbfwxtbi2t52gjvliqxisa	2025-10-27 23:27:44+00	\N	electronic
3150	20	3czTBcZWn9VP9sKrnLXi8D	\N	Omae Wa Mou	deadman 死人	1qzcdqlwqtm8lnthmvh2a70p9	2025-10-15 19:41:44+00	\N	anime
3134	19	4SNtyKNyYJ8ERT7YLlnFBr	\N	So Young	Portugal. The Man	31ghi62vkgnlb4wqr6muaisx7ldi	2025-10-30 14:01:51+00	\N	indie
3102	18	4klTvY6eWq4uxheoaudBPK	\N	Bring the Wow	Kali J, Nathan Fields	313neyxbfwxtbi2t52gjvliqxisa	2025-11-06 06:53:55+00	\N	pop
3146	20	5DOadSIDaKFwUPcbcbDv5J	\N	Loud(y)	Lewis Del Mar	31pd6hnytykuevog22xwj5yn2qjy	2025-10-12 16:21:31+00	\N	indie
3124	19	4lmvq47DBxvlIgq4BykkhN	\N	You'll never know	笠井 紀美子	1qzcdqlwqtm8lnthmvh2a70p9	2025-10-26 20:53:50+00	\N	city pop, j-r&b
3132	19	4xeW5ZakgtFMjIp6SvpFIC	\N	A War Is Coming	Jeanne Added	31ghi62vkgnlb4wqr6muaisx7ldi	2025-10-30 14:01:02+00	\N	french indie pop
3115	18	5HaalaXE9SzmQpkrqoG1Rc	\N	КАРНАВАЛА	ХАУСПАРТИЗАН	31ghi62vkgnlb4wqr6muaisx7ldi	2025-11-07 08:29:39+00	\N	electronic
3152	20	5Sd1DBxXibBVhdujtOzU4H	\N	Камнем	Абрикоса	1qzcdqlwqtm8lnthmvh2a70p9	2025-10-16 09:08:00+00	\N	rock
3159	20	5uuJruktM9fMdN9Va0DUMl	\N	Play That Funky Music	Wild Cherry	313neyxbfwxtbi2t52gjvliqxisa	2025-10-17 05:26:06+00	\N	funk
3145	20	5X89UuCSWTnAYjsUfrTEl7	\N	Hoax	Wavy Jone$	31pd6hnytykuevog22xwj5yn2qjy	2025-10-12 15:57:38+00	\N	horrorcore
3111	18	7h4vSrMumaCgh2awgYF3yD	\N	люблю	ульяна мамушкина	1qzcdqlwqtm8lnthmvh2a70p9	2025-11-07 07:10:31+00	\N	pop
3156	20	65Ga5ZT9oE2zZVC1nCHxW7	\N	Disaster	NEOTEK, Bella Renee	313neyxbfwxtbi2t52gjvliqxisa	2025-10-17 05:25:43+00	\N	dubstep, riddim
3103	18	69kZsoRrSf7GBTSdJ4BjqA	\N	Another Day	Dream Theater	1qzcdqlwqtm8lnthmvh2a70p9	2025-11-06 08:22:15+00	\N	progressive metal, progressive rock, metal
3122	19	6IxQ0PdozaZKch1m8tGCwb	\N	All That I've Got	The Used	1qzcdqlwqtm8lnthmvh2a70p9	2025-10-25 02:01:41+00	\N	emo, screamo, post-hardcore, pop punk
3139	19	6gIOw1fQeFVptzL1OVZEJN	\N	The Worst Kind Of Panic	Second Harbour	1qzcdqlwqtm8lnthmvh2a70p9	2025-10-31 02:18:34+00	\N	pop punk, post-hardcore
3110	18	75R95k0ICuZBFVEjBauOtt	\N	Doomsday	Architects	313neyxbfwxtbi2t52gjvliqxisa	2025-11-07 02:51:20+00	\N	metalcore, djent, metal, mathcore, post-hardcore, deathcore
3158	20	7AYk5ydK4Z5gzBuaBU0fTd	\N	Dreamin'	Jill Scott	313neyxbfwxtbi2t52gjvliqxisa	2025-10-17 05:26:03+00	\N	neo soul, quiet storm
3121	19	7MkX07TjBPtPZHnBqJkCuY	\N	Fandango	DJ Quik	1qzcdqlwqtm8lnthmvh2a70p9	2025-10-25 01:57:39+00	\N	g-funk, west coast hip hop, old school hip hop, gangster rap
3104	18	7vXYRLM5UxGt9s06NOQDlo	\N	WAVES	BLK ODYSSY	1qzcdqlwqtm8lnthmvh2a70p9	2025-11-06 12:01:52+00	\N	hip hop
3137	19	7pCPYB7Bkxtm4hYc4PbDlu	\N	If Only You (feat. Therese)	Danny Saucedo, Therese	1qzcdqlwqtm8lnthmvh2a70p9	2025-10-30 22:03:29+00	\N	swedish pop
3157	20	7yAveiMuIeNddavHGc5BWc	\N	Королева пустоты	Wildways	313neyxbfwxtbi2t52gjvliqxisa	2025-10-17 05:25:57+00	\N	metalcore, post-hardcore
3141	19	0RT48ypt6rC10KVNRjEnEd	\N	Флиртуй	The Limba	1qzcdqlwqtm8lnthmvh2a70p9	2025-10-31 18:24:03+00	\N	pop
3217	22	0BHyc5cgSYKHGIce4gTkMn	\N	Gold Long Gone	Rise Against	31pd6hnytykuevog22xwj5yn2qjy	2025-09-25 14:20:30+00	\N	punk, hardcore punk
3164	20	0LwwQLNOCvQF9xqD9rJ0Un	\N	Bleue	Wale the Sage	31ghi62vkgnlb4wqr6muaisx7ldi	2025-10-22 11:00:14+00	\N	hip hop
3174	21	1Isk7VRqWBpCvPyGNDZUmI	\N	Into The Bay	Goodwood Atoms	31ghi62vkgnlb4wqr6muaisx7ldi	2025-10-02 13:52:20+00	\N	indie
3216	22	0ZSrgc4WfYloT4p0oL1CRG	\N	Thin Distance	Noisecream	31ghi62vkgnlb4wqr6muaisx7ldi	2025-09-25 14:18:01+00	\N	synthwave
3173	21	0rN2JLEdCo3CwRTBgTwkKz	\N	Убегай	osaili	31ghi62vkgnlb4wqr6muaisx7ldi	2025-10-02 13:52:04+00	\N	drum and bass
3200	22	0sjOX1TrYGzbieHCizRiN2	\N	Wild Child (with Tom Morello)	The Struts, Tom Morello	1qzcdqlwqtm8lnthmvh2a70p9	2025-09-14 17:40:58+00	\N	glam rock
3192	21	0zXHdFLJlSrj1d6dRcoUua	\N	Livin' in a World Without You	The Rasmus	1qzcdqlwqtm8lnthmvh2a70p9	2025-10-03 09:26:32+00	\N	finnish rock
3179	21	1Jf7SJ0LZgDdI38JSFhcsi	\N	Trap Reaper Parody	Azizi Gibson	31pd6hnytykuevog22xwj5yn2qjy	2025-10-03 09:05:24+00	\N	rap
3222	22	1TAgKYwyFF7uyBum0ESDlU	\N	Change For You	Friday Pilots Club	31pd6hnytykuevog22xwj5yn2qjy	2025-09-26 08:19:51+00	\N	emo
3201	22	1TTOWdihS9artUmjI2xdJD	\N	It's a Fine Day - Zerosix Radio Edit	Aeronautics, Zerosix	1qzcdqlwqtm8lnthmvh2a70p9	2025-09-18 18:29:52+00	\N	electronic
3205	22	1kuX7xrm7I7EUT78ItkjfR	\N	Малый повзрослел - Apashe Remix	Apashe, Max Korzh	1qzcdqlwqtm8lnthmvh2a70p9	2025-09-19 19:07:19+00	\N	electronic
3177	21	1X5AZIOW33aaZvhgL90EVN	\N	The Boy Is Mine	Pascal Junior, Afgo	1qzcdqlwqtm8lnthmvh2a70p9	2025-10-03 09:00:51+00	\N	deep house
3204	22	24Ap2v8In40hHIJ8fJu0FB	\N	Сто из ста	Myqeed, KEER	1qzcdqlwqtm8lnthmvh2a70p9	2025-09-19 18:57:24+00	\N	hip hop
3220	22	1qqbzYjbflz9oo0nwqrKSz	\N	awake	Taku Iwasaki	1qzcdqlwqtm8lnthmvh2a70p9	2025-09-25 20:47:42+00	\N	anime
3188	21	1yXfz9FQCLcqG3mndVSpTG	\N	Sonic	Bloody Boy	1qzcdqlwqtm8lnthmvh2a70p9	2025-10-03 09:12:15+00	\N	bass house, g-house
3189	21	26C0U0VX21AmqL1ENsRgnp	\N	сamellia	bullish	1qzcdqlwqtm8lnthmvh2a70p9	2025-10-03 09:16:37+00	\N	electronic
3206	22	2JQp8MlKEXzIXnUsr8RkNo	\N	Белые Цветы	Рубеж Веков	1qzcdqlwqtm8lnthmvh2a70p9	2025-09-19 19:08:32+00	\N	classical
3203	22	2V1pcaaDRdizrk4GQKwmAs	\N	Diamonds On My Teeth	Claudia Valentina	1qzcdqlwqtm8lnthmvh2a70p9	2025-09-19 18:50:27+00	\N	pop
3190	21	2bcC9Xyi40wnI7Od5uch31	\N	Iron Sky	Paolo Nutini	1qzcdqlwqtm8lnthmvh2a70p9	2025-10-03 09:16:57+00	\N	rock
3195	21	2kdggifpQn5jx8QitofOJs	\N	Where's Your Friends / Wild	Kanadia	1qzcdqlwqtm8lnthmvh2a70p9	2025-10-03 09:56:12+00	\N	indie
3180	21	2cAJVMHRt6uWMJ4UMyZC1C	\N	Everything Everything	The Mary Onettes	31pd6hnytykuevog22xwj5yn2qjy	2025-10-03 09:06:47+00	\N	dream pop
3170	21	2wQ0P3FxJwy10ZMp9egzUD	\N	Just The Same	KVDE	313neyxbfwxtbi2t52gjvliqxisa	2025-10-01 23:30:29+00	\N	electronic
3183	21	3WFjXiAAabAQDkiOWazk9w	\N	Empty Orchestra	Hayes & Y	31pd6hnytykuevog22xwj5yn2qjy	2025-10-03 09:26:20+00	\N	downtempo
3187	21	3RgDvs9Jpvn3kUuaTek1R5	\N	I-E-A-I-A-I-O	System Of A Down	31pd6hnytykuevog22xwj5yn2qjy	2025-10-03 09:38:39+00	\N	nu metal, metal, alternative metal, rap metal, rock
3213	22	3RmFPuTTAjSQ2pbEd2j9oA	\N	Loser	Tame Impala	31ghi62vkgnlb4wqr6muaisx7ldi	2025-09-25 14:13:13+00	\N	neo-psychedelic, indie
3166	20	3chb0SAouU1FtBPR5NPHWX	\N	Шёлк	Ваня Дмитриенко	1qzcdqlwqtm8lnthmvh2a70p9	2025-10-23 22:30:29+00	\N	pop
3194	21	3bvMys7iRlveVGnsKs2niv	\N	It Will All Make Sense in the Morning	Halou	1qzcdqlwqtm8lnthmvh2a70p9	2025-10-03 09:38:25+00	\N	trip hop, downtempo
3165	20	3luskJHELaUhP5xaZC5Li6	\N	Пули	HANNA	1qzcdqlwqtm8lnthmvh2a70p9	2025-10-22 11:49:39+00	\N	pop
3221	22	3fsQsL36PH1G8mn68lsFRK	\N	Walk In The Sky	Bonobo, Bajka	31pd6hnytykuevog22xwj5yn2qjy	2025-09-26 08:18:07+00	\N	trip hop, downtempo, nu jazz, electronic
3172	21	4LhsxcQGyDNEwincOJw8B3	\N	переживём.	vestfalin	31ghi62vkgnlb4wqr6muaisx7ldi	2025-10-02 13:51:57+00	\N	emo
3171	21	3zfM1xD4wnRzk8sgrJEj4z	\N	We the People	Inüit	31ghi62vkgnlb4wqr6muaisx7ldi	2025-10-02 13:51:49+00	\N	french indie pop
3219	22	43sNw9nvGYGLYnNiwI8oMZ	\N	Freek'n You	Jodeci	1qzcdqlwqtm8lnthmvh2a70p9	2025-09-25 20:46:46+00	\N	new jack swing, quiet storm, r&b
3224	22	4FKuIlfFCIcvpg7M2HJhwx	\N	You & I	Dabeull, HolyBrune	31pd6hnytykuevog22xwj5yn2qjy	2025-09-26 08:21:40+00	\N	funk, nu disco
3176	21	4JWRos6zAz0GyBfCRoeC0C	\N	Lost Highway	NightCrawl	31ghi62vkgnlb4wqr6muaisx7ldi	2025-10-02 13:52:33+00	\N	darkwave
3209	22	4WNaefp3sGsnTBzHEQb97g	\N	Hello Heaven, Hello	YUNGBLUD	31pd6hnytykuevog22xwj5yn2qjy	2025-09-25 11:21:45+00	\N	alternative rock
3185	21	4N90LxX3kWhJucPQ484Qy9	\N	I Can Talk	Two Door Cinema Club	31pd6hnytykuevog22xwj5yn2qjy	2025-10-03 09:36:53+00	\N	indie, indie rock
3184	21	4ZEvO7TZQTbUGJzqjcPFDD	\N	Impossible	Nothing But Thieves	31pd6hnytykuevog22xwj5yn2qjy	2025-10-03 09:27:36+00	\N	alternative rock
3196	21	5O0CfpM0kYfc5knv5V1xlH	\N	Two Cents	Alumni Cloud	1qzcdqlwqtm8lnthmvh2a70p9	2025-10-03 10:00:55+00	\N	indie
3193	21	5Sw7WKmkFJiFTDBR4d1Efn	\N	Everything We Gave	Beyond Disdain, Selene Calder	1qzcdqlwqtm8lnthmvh2a70p9	2025-10-03 09:32:20+00	\N	indie
3199	21	6Mzjn1OLv7siyDPuGnjVzz	\N	Sweat	Marbez	1qzcdqlwqtm8lnthmvh2a70p9	2025-10-03 10:18:21+00	\N	electronic
3214	22	6oofvZ4K8vBHnCT1oKERcd	\N	i walk this earth all by myself	EKKSTACY	31ghi62vkgnlb4wqr6muaisx7ldi	2025-09-25 14:15:39+00	\N	emo
3182	21	5mIemH3MAuvMetPDBxUfqr	\N	Solo	Ultimo	31pd6hnytykuevog22xwj5yn2qjy	2025-10-03 09:13:12+00	\N	concerto
3218	22	5ycVJufpq4ad1mqA5JfNQS	\N	Fighting Gold	Coda	1qzcdqlwqtm8lnthmvh2a70p9	2025-09-25 20:44:30+00	\N	anime
3186	21	7BVXEajkoOr9yiOMCrSPN8	\N	Move	Pretty Vicious	31pd6hnytykuevog22xwj5yn2qjy	2025-10-03 09:37:50+00	\N	rock
3178	21	6fEiVtKzQvgzrsFZX2YBO3	\N	You & I	DI-RECT	31pd6hnytykuevog22xwj5yn2qjy	2025-10-03 09:04:49+00	\N	nederpop
3175	21	7GcW6BIxfv8JHxFxslJghx	\N	Compromise	Joywave	31ghi62vkgnlb4wqr6muaisx7ldi	2025-10-02 13:52:26+00	\N	indie
3168	20	6qQuqzRY4782iFHkunTqkx	\N	Johnny Joestar Theme (Steel Ball Run Unofficial Theme) - Original	Samuel Kim	313neyxbfwxtbi2t52gjvliqxisa	2025-10-24 01:32:08+00	\N	anime
3212	22	7j6PWLaubVavCLE4peea8S	\N	Backseat	Balu Brigada	31ghi62vkgnlb4wqr6muaisx7ldi	2025-09-25 14:12:41+00	\N	indie
3207	22	7qCIXsE6x7Q3NuLnYdJGp6	\N	Save Me	Morandi, Helen	1qzcdqlwqtm8lnthmvh2a70p9	2025-09-24 19:40:54+00	\N	europop
3210	22	0L5gfUQuxrbSepbAUkN6u0	\N	НАЛЕГКЕ	Smoky Mo, Basta	31pd6hnytykuevog22xwj5yn2qjy	2025-09-25 12:32:24+00	\N	rap
3285	24	0COqiPhxzoWICwFCS4eZcp	\N	Bring Me To Life	Evanescence	31pd6hnytykuevog22xwj5yn2qjy	2025-08-20 10:22:14+00	\N	alternative metal
3256	23	0a0pxVrtUnhJ4YPOKyQX8o	\N	La vida es un cuadro	Leo Rizzi	31pd6hnytykuevog22xwj5yn2qjy	2025-09-07 05:14:58+00	\N	latin
3250	23	0quU9n8FB3ib7u9lU74P4R	\N	Наплевать на всех	PIZZA, Leonid Agutin	1qzcdqlwqtm8lnthmvh2a70p9	2025-09-04 22:43:59+00	\N	pop
3274	24	0u2P5u6lvoDfwTYjAADbn4	\N	lovely (with Khalid)	Billie Eilish, Khalid	1qzcdqlwqtm8lnthmvh2a70p9	2025-08-15 19:57:25+00	\N	pop
3245	23	0r9VDnfH7A8paz4qnH4Jyk	\N	HUGs	Paledusk	1qzcdqlwqtm8lnthmvh2a70p9	2025-09-04 18:31:59+00	\N	j-rock, mathcore, anime
3257	23	0rdWkO7ncrh1lrJGDmLq9L	\N	Gamesofluck	Parcels	31pd6hnytykuevog22xwj5yn2qjy	2025-09-07 05:17:00+00	\N	indie soul
3259	23	1Mb0sZWI4g0FaoLxGrq6eq	\N	The Way We Love	ISLAND	31ghi62vkgnlb4wqr6muaisx7ldi	2025-09-07 05:26:36+00	\N	alternative rock
3251	23	151rMxSRR29UZMAgcIxeRI	\N	Don't Let Me Down	Habstrakt, Julienne By	1qzcdqlwqtm8lnthmvh2a70p9	2025-09-04 22:57:30+00	\N	bass house, g-house, dubstep, bassline
3264	23	1UR2SbloSbXl8ULAwCD3Q1	\N	Shine	The Cool Quest	31pd6hnytykuevog22xwj5yn2qjy	2025-09-07 06:33:32+00	\N	funk
3235	23	1hQWjvHy5eEpTeZWV1PBcG	\N	Пепел-слова	RadioLIFE	313neyxbfwxtbi2t52gjvliqxisa	2025-08-29 11:35:01+00	\N	indie
3279	24	1dzQoRqT5ucxXVaAhTcT0J	\N	Just Dance	Lady Gaga, Colby O'Donis	1qzcdqlwqtm8lnthmvh2a70p9	2025-08-18 03:37:57+00	\N	art pop, pop
3283	24	21RzyxY3EFaxVy6K4RqaU9	\N	Body	Loud Luxury, Brando	31pd6hnytykuevog22xwj5yn2qjy	2025-08-20 10:15:21+00	\N	house
3248	23	1v5CZL1bBD68R2a00IfPqW	\N	House of the Rising Sun	Scott Bradlee's Postmodern Jukebox, Lavance Colley	1qzcdqlwqtm8lnthmvh2a70p9	2025-09-04 21:38:49+00	\N	swing music, jazz pop, electro swing
3242	23	2KH16WveTQWT6KOG9Rg6e2	\N	Eye of the Tiger	Survivor	1qzcdqlwqtm8lnthmvh2a70p9	2025-09-01 18:24:10+00	\N	rock
3263	23	2SFjZJOwgMGmsLtqHdZbVY	\N	Lost Horse	Asaf Avidan	31pd6hnytykuevog22xwj5yn2qjy	2025-09-07 05:40:36+00	\N	indie
3240	23	2fcBNCqVthAeoAN5extCC1	\N	Ages	Incredible Polo	31ghi62vkgnlb4wqr6muaisx7ldi	2025-08-31 05:58:54+00	\N	electronic
3237	23	2e9HC16cEYxDnj4QAmsYi4	\N	Death	LANDMVRKS, DR€W ¥ORK	313neyxbfwxtbi2t52gjvliqxisa	2025-08-29 11:35:20+00	\N	metalcore, deathcore, metal
3278	24	2kQuhkFX7uSVepCD3h29g5	\N	Smack That	Akon, Eminem	1qzcdqlwqtm8lnthmvh2a70p9	2025-08-18 03:37:30+00	\N	hip hop
3288	24	2iuZJX9X9P0GKaE93xcPjk	\N	Sugar	Maroon 5	31pd6hnytykuevog22xwj5yn2qjy	2025-08-20 10:31:39+00	\N	pop
3234	23	3GSC9EXY0Csb8C6xccHv2V	\N	Live Like Animals	Nothing But Thieves	1qzcdqlwqtm8lnthmvh2a70p9	2025-08-22 19:20:23+00	\N	alternative rock
3266	24	37ZJ0p5Jm13JPevGcx4SkF	\N	Livin' On A Prayer	Bon Jovi	313neyxbfwxtbi2t52gjvliqxisa	2025-08-01 07:47:22+00	\N	glam metal
3253	23	3SKH53SPQbEnZR4cJPVaz2	\N	Messy	Lola Young	31pd6hnytykuevog22xwj5yn2qjy	2025-09-07 05:12:46+00	\N	pop
3269	24	3K4HG9evC7dg3N0R9cYqk4	\N	One Step Closer	Linkin Park	313neyxbfwxtbi2t52gjvliqxisa	2025-08-01 08:09:21+00	\N	nu metal, rap metal, rock, alternative metal
3236	23	3KA0M8SYVjkMZhTwnbqUqK	\N	Hallelujah	Black Veil Brides	313neyxbfwxtbi2t52gjvliqxisa	2025-08-29 11:35:06+00	\N	emo, screamo
3228	22	3fkA9mS8PFF7EDyBqnmL6s	\N	Alchemy	Daedric	313neyxbfwxtbi2t52gjvliqxisa	2025-09-26 10:30:28+00	\N	electronic
3252	23	3Tdih47Fm5lGlwc4qsqFGr	\N	Beautiful Colors - from Kaiju No. 8	OneRepublic	1qzcdqlwqtm8lnthmvh2a70p9	2025-09-06 23:26:01+00	\N	soft pop
3286	24	3UmaczJpikHgJFyBTAJVoz	\N	Stan	Eminem, Dido	31pd6hnytykuevog22xwj5yn2qjy	2025-08-20 10:24:19+00	\N	rap, hip hop
3231	22	3ZffCQKLFLUvYM59XKLbVm	\N	Wake Me up When September Ends	Green Day	313neyxbfwxtbi2t52gjvliqxisa	2025-09-26 10:31:08+00	\N	punk, pop punk
3272	24	3gdewACMIVMEWVbyb8O9sY	\N	Rocket Man (I Think It's Going To Be A Long, Long Time)	Elton John	1qzcdqlwqtm8lnthmvh2a70p9	2025-08-15 05:20:20+00	\N	rock
3276	24	58zsLZPvfflaiIbNWoA22O	\N	Human	Rag'n'Bone Man	1qzcdqlwqtm8lnthmvh2a70p9	2025-08-16 22:12:38+00	\N	soul
3275	24	3mfER4ORePHvN35cbZ3dkV	\N	Where Are You Now	Lost Frequencies, Calum Scott	1qzcdqlwqtm8lnthmvh2a70p9	2025-08-15 20:13:41+00	\N	tropical house
3246	23	4qsWwHVBWmAEV0509TBVZI	\N	God Wears Gucci	blessthefall	1qzcdqlwqtm8lnthmvh2a70p9	2025-09-04 18:36:39+00	\N	metalcore, post-hardcore, screamo
3227	22	5KK1LYZ3SoebYARETIUK3w	\N	Nothing Remains	Lead Horizon	313neyxbfwxtbi2t52gjvliqxisa	2025-09-26 10:30:10+00	\N	metal
3282	24	5YEOzOojehCqxGQCcQiyR4	\N	Panda	Desiigner	1qzcdqlwqtm8lnthmvh2a70p9	2025-08-18 03:50:01+00	\N	hip hop
3287	24	5TRPicyLGbAF2LGBFbHGvO	\N	Flashing Lights	Kanye West, Dwele	31pd6hnytykuevog22xwj5yn2qjy	2025-08-20 10:29:24+00	\N	rap
3239	23	6BYoQ2ijjWtld0r822QXH9	\N	Run	AIM WIND X, AIM WIND	313neyxbfwxtbi2t52gjvliqxisa	2025-08-29 11:35:31+00	\N	electronic
3233	22	5ZuHXNo5aVwJGeBKQUrNPq	\N	Антидот	[AMATORY]	313neyxbfwxtbi2t52gjvliqxisa	2025-09-26 10:33:23+00	\N	metalcore
3271	24	61mWefnWQOLf90gepjOCb3	\N	Duality	Slipknot	313neyxbfwxtbi2t52gjvliqxisa	2025-08-01 08:40:07+00	\N	nu metal, metal, alternative metal, rap metal, heavy metal
3249	23	6LiBUqQAeGDFFjyyNSNJmp	\N	Слеза - Remix	Лилая, it alone, tvzf	1qzcdqlwqtm8lnthmvh2a70p9	2025-09-04 22:36:54+00	\N	pop
3238	23	7ab1xHFYh7gnsoYFc4l8bd	\N	туманы	гнилаялирика, Wildways	313neyxbfwxtbi2t52gjvliqxisa	2025-08-29 11:35:26+00	\N	metalcore
3273	24	6O5TrlFWTYvznd9fMC0VvU	\N	When We Were Young	Adele	1qzcdqlwqtm8lnthmvh2a70p9	2025-08-15 05:33:58+00	\N	soft pop
3241	23	6PypMXsV8zmifuFPMnWE4W	\N	Portraits	Panchiko	31ghi62vkgnlb4wqr6muaisx7ldi	2025-08-31 05:58:57+00	\N	shoegaze
3243	23	6UtV1xntPbEgbbY8Dh2tQn	\N	Spicy Queen	花冷え。	313neyxbfwxtbi2t52gjvliqxisa	2025-09-04 00:04:44+00	\N	j-rock, visual kei
3262	23	6XAA7T9VHcqKQSzjmXAJ8o	\N	That's All She Wrote	T.I., Eminem	31pd6hnytykuevog22xwj5yn2qjy	2025-09-07 05:35:49+00	\N	southern hip hop
3255	23	6sQPu9fZuXKGXesabSqSjx	\N	Priceless (feat. LISA)	Maroon 5, LISA	31pd6hnytykuevog22xwj5yn2qjy	2025-09-07 05:14:28+00	\N	pop
3244	23	7cnEZCAUkoW7YmdNHJ5Q81	\N	QUERIDA AMALIA:	BRUSES	313neyxbfwxtbi2t52gjvliqxisa	2025-09-04 15:06:29+00	\N	latin
3230	22	7g5QAlHTedCAbRjJB8eCMJ	\N	Лидокаин	UBEL	313neyxbfwxtbi2t52gjvliqxisa	2025-09-26 10:30:39+00	\N	pop
3260	23	7mf6EqBXVrFZrV5sheEo35	\N	hot topic	bbno$	31ghi62vkgnlb4wqr6muaisx7ldi	2025-09-07 05:29:34+00	\N	rap
3277	24	7ySUcLPVX7KudhnmNcgY2D	\N	S&M	Rihanna	1qzcdqlwqtm8lnthmvh2a70p9	2025-08-18 03:36:17+00	\N	pop
3254	23	0WbMK4wrZ1wFSty9F7FCgu	\N	Good Luck, Babe!	Chappell Roan	31pd6hnytykuevog22xwj5yn2qjy	2025-09-07 05:13:01+00	\N	pop
3351	26	0f2zcrhhHT59aIGQvRlTZ1	\N	One More Night	Michael Kiwanuka	31pd6hnytykuevog22xwj5yn2qjy	2025-07-02 13:08:06+00	\N	soul
3340	26	1kZLJajBBu3JYsGZ4JcJO9	\N	Кабан	Чёрный Государь	313neyxbfwxtbi2t52gjvliqxisa	2025-06-27 01:28:36+00	\N	rap
3320	25	12IzrBskU17Z10IrXBa6C7	\N	The Mood	FLO, KAYTRANADA	1qzcdqlwqtm8lnthmvh2a70p9	2025-07-18 00:00:45+00	\N	uk r&b
3350	26	18Qp2oQlUvoG09Xh5vlp4Z	\N	Street Jazz	Awon, Dephlow, Phoniks	31pd6hnytykuevog22xwj5yn2qjy	2025-07-02 13:07:17+00	\N	jazz rap
3312	25	1tWetjqjiQVkRiAqitDckP	\N	как ты танцуешь	арахис	31ghi62vkgnlb4wqr6muaisx7ldi	2025-07-17 15:09:48+00	\N	pop
3328	25	2Mdv8PnOWxKhjtbQ9UnVva	\N	Blindspot	Goodboys, Nu Aspect, AVAION	1qzcdqlwqtm8lnthmvh2a70p9	2025-07-18 00:15:58+00	\N	electronic
3293	24	2nMeu6UenVvwUktBCpLMK9	\N	Young And Beautiful	Lana Del Rey	31ghi62vkgnlb4wqr6muaisx7ldi	2025-08-20 16:02:52+00	\N	indie
3291	24	2374M0fQpWi3dLnB54qaLX	\N	Africa	TOTO	31pd6hnytykuevog22xwj5yn2qjy	2025-08-20 10:37:29+00	\N	yacht rock, soft rock
3325	25	2uvE4L5ZsYKpv8hbK4TIOt	\N	MUTT	Leon Thomas	1qzcdqlwqtm8lnthmvh2a70p9	2025-07-18 00:11:09+00	\N	r&b
3344	26	2z5I5rLxZ4vBSpcJt833za	\N	TER	Shiza, Bakr	1qzcdqlwqtm8lnthmvh2a70p9	2025-06-30 14:49:30+00	\N	electronic
3352	26	2tpfPi4qSamU9EX5Q8FnNi	\N	Pain	Boy Harsher	31pd6hnytykuevog22xwj5yn2qjy	2025-07-02 13:11:45+00	\N	darkwave, cold wave, post-punk, ebm, gothic rock, deathrock, synthpop
3313	25	2zEcXc3V7dgf984BAkpOnc	\N	We R Who We R - Fred Falke Club Mix	Kesha, Fred Falke	1qzcdqlwqtm8lnthmvh2a70p9	2025-07-17 23:03:42+00	\N	house
3347	26	39t0kJ6kmH50qK1eSTY55F	\N	в кармане	Тося Чайкина	31pd6hnytykuevog22xwj5yn2qjy	2025-07-02 13:03:08+00	\N	pop
3308	25	3bqcIqIUGp9u1eYaaGpnIc	\N	Drown Me Down	Cloudless	31pd6hnytykuevog22xwj5yn2qjy	2025-07-17 11:14:09+00	\N	indie
3335	26	39UJG380DXNHAa07pGdVgI	\N	No Surprises - Remastered	Radiohead	1qzcdqlwqtm8lnthmvh2a70p9	2025-06-25 01:09:11+00	\N	art rock, alternative rock
3348	26	3eIWmn09ONQea76x9ZQPEE	\N	DENIAL IS A RIVER	Doechii	31pd6hnytykuevog22xwj5yn2qjy	2025-07-02 13:04:07+00	\N	hip hop
3337	26	3Db1iyODtiuegmMXEbOnRA	\N	Psycho	Errortica, Reptiloid	1qzcdqlwqtm8lnthmvh2a70p9	2025-06-26 23:50:34+00	\N	breakbeat
3309	25	3S4kIleZ5CJM6GVz2MeAWO	\N	Poison	Wargirl	31ghi62vkgnlb4wqr6muaisx7ldi	2025-07-17 15:03:55+00	\N	retro pop
3319	25	3ZdwCZtXWJjMqHlSFgYfIg	\N	Prequel	Falling In Reverse	313neyxbfwxtbi2t52gjvliqxisa	2025-07-17 23:59:40+00	\N	emo, rap metal
3314	25	43kPj5KUVxb9nTrjOpOWTz	\N	Smoke	Alex Who?	1qzcdqlwqtm8lnthmvh2a70p9	2025-07-17 23:03:42+00	\N	electronic
3326	25	4QkKWvtMj675AKd8IForfc	\N	I Love You	Belters Only	1qzcdqlwqtm8lnthmvh2a70p9	2025-07-18 00:12:02+00	\N	pop
3316	25	4qD9qh4FRu4wl5QevQKm0b	\N	Love's The Worst	Dinosaur Pile-Up	1qzcdqlwqtm8lnthmvh2a70p9	2025-07-17 23:52:06+00	\N	emo
3322	25	5fpLml6L2VgDYhtCTpjxT0	\N	Не цель и даже не средство	Лилая	1qzcdqlwqtm8lnthmvh2a70p9	2025-07-18 00:04:32+00	\N	indie
3307	25	4b6WRfxJRY40RBpl3TMQVq	\N	Heartbreak	Bonobo, TEED	31pd6hnytykuevog22xwj5yn2qjy	2025-07-17 11:13:52+00	\N	trip hop, downtempo, nu jazz, electronic
3346	26	5rEStIsIxm6BFXFIm3gGrF	\N	Yozek	Defne	31pd6hnytykuevog22xwj5yn2qjy	2025-07-02 13:02:06+00	\N	electronic
3333	26	4qZHGxLhYIpq5Dsxb45BLm	\N	Splinter Wolf	KOHTA YAMAMOTO	1qzcdqlwqtm8lnthmvh2a70p9	2025-06-20 20:21:27+00	\N	anime, soundtrack
3306	25	5GHbBW6bXehdUwtTPdupy4	\N	Focus	Chaleee, Enoo Napa	313neyxbfwxtbi2t52gjvliqxisa	2025-07-16 07:36:02+00	\N	afro tech, afro house, 3 step, tribal house
3315	25	5KOJrVitoBhiuAzpnzRJ12	\N	all i know is... i'd go blind for you	tmdistant	1qzcdqlwqtm8lnthmvh2a70p9	2025-07-17 23:05:40+00	\N	hyperpop
3324	25	5TpWybXTsLTUAj4WcUYkP0	\N	Campeón	ZULAN	1qzcdqlwqtm8lnthmvh2a70p9	2025-07-18 00:10:35+00	\N	uk garage
3304	25	5tdXeZOLP0dUVhJ5tTxCJW	\N	SILOS	STARSET	313neyxbfwxtbi2t52gjvliqxisa	2025-07-16 07:05:26+00	\N	metal
3302	24	6EtKlIQmGPB9SX8UjDJG5s	\N	Formula (From "Euphoria: Season 1" Soundtrack)	Labrinth	31ghi62vkgnlb4wqr6muaisx7ldi	2025-08-20 16:05:15+00	\N	soundtrack
3345	26	6GufGRVi6OQGjson1lKj9d	\N	В клубе	Timati, Dj Dlee	1qzcdqlwqtm8lnthmvh2a70p9	2025-07-01 16:27:10+00	\N	hip hop
3292	24	64BbK9SFKH2jk86U3dGj2P	\N	Otherside	Red Hot Chili Peppers	31pd6hnytykuevog22xwj5yn2qjy	2025-08-20 10:41:05+00	\N	funk rock, alternative rock, rock
3303	25	69nFLl74Rqr8LmqUCUZJL6	\N	Prophecy	Rezz	313neyxbfwxtbi2t52gjvliqxisa	2025-07-16 07:05:21+00	\N	edm, dubstep
3297	24	6GyFP1nfCDB8lbD2bG0Hq9	\N	Midnight City	M83	31ghi62vkgnlb4wqr6muaisx7ldi	2025-08-20 16:04:05+00	\N	synthwave
3323	25	6HQ8mX1kpkvrOvtx0Iregr	\N	Kiss The Pavement	Hellhills	1qzcdqlwqtm8lnthmvh2a70p9	2025-07-18 00:06:26+00	\N	rock
3310	25	6IY3cC281mz9q0bViUEldz	\N	It's A Trip!	Joywave	31ghi62vkgnlb4wqr6muaisx7ldi	2025-07-17 15:04:48+00	\N	indie
3339	26	6MJqzjRWLKRQjePJHuflNd	\N	Knot	Shyeye	313neyxbfwxtbi2t52gjvliqxisa	2025-06-27 01:28:28+00	\N	electronic
3327	25	6Qyc6fS4DsZjB2mRW9DsQs	\N	Iris	The Goo Goo Dolls	1qzcdqlwqtm8lnthmvh2a70p9	2025-07-18 00:14:11+00	\N	alternative rock
3341	26	6Rcp6bE1XGGGIVOWEBJv6u	\N	новый день	тима ищет свет	313neyxbfwxtbi2t52gjvliqxisa	2025-06-27 01:28:41+00	\N	pop
3294	24	6tDDoYIxWvMLTdKpjFkc1B	\N	telepatía	Kali Uchis	31ghi62vkgnlb4wqr6muaisx7ldi	2025-08-20 16:02:59+00	\N	pop
3338	26	7Ddh6L2q65SrDPn1qoWoqL	\N	Подожгу	CREAM SODA	313neyxbfwxtbi2t52gjvliqxisa	2025-06-27 01:27:57+00	\N	electronic
3296	24	6VObnIkLVruX4UVyxWhlqm	\N	Skyfall	Adele	31ghi62vkgnlb4wqr6muaisx7ldi	2025-08-20 16:04:01+00	\N	soft pop
3329	25	6aLmvz0CPeCNHCXK2H5QIC	\N	Debra	Beck	1qzcdqlwqtm8lnthmvh2a70p9	2025-07-18 03:27:27+00	\N	anti-folk
3343	26	6kESVt7m9Wn2WcS1OGOOmC	\N	Into Hell	I Prevail	313neyxbfwxtbi2t52gjvliqxisa	2025-06-27 01:44:58+00	\N	metalcore, metal
3336	26	7c0a73XuSJsGV8MFPtYt8i	\N	Feels So Good To Be You	Mama Duke	1qzcdqlwqtm8lnthmvh2a70p9	2025-06-26 23:39:12+00	\N	r&b
3311	25	72RisdT2OxA6XtcPnJcoXi	\N	The Ellen Show	Zior Park, Wunderkid	31ghi62vkgnlb4wqr6muaisx7ldi	2025-07-17 15:08:27+00	\N	k-rap
3349	26	74PHsfwKi13QLJAbHPVgQf	\N	Fall To The Dust	Metrik	31pd6hnytykuevog22xwj5yn2qjy	2025-07-02 13:06:01+00	\N	drum and bass, liquid funk
3299	24	7EkWXAI1wn8Ii883ecd9xr	\N	Freaks	Surf Curse	31ghi62vkgnlb4wqr6muaisx7ldi	2025-08-20 16:04:17+00	\N	indie
3331	25	7gKxCvTDWwV9wBhdeBbr3l	\N	Nice To Each Other	Olivia Dean	31pd6hnytykuevog22xwj5yn2qjy	2025-07-18 07:56:03+00	\N	pop soul
3317	25	0ouWOf4W8331O6dt2GCW7A	\N	The Shiver	Jayda G	1qzcdqlwqtm8lnthmvh2a70p9	2025-07-17 23:56:27+00	\N	electronic
3373	27	0PGKJn6vSGgCDYmrvaXUYj	\N	Злые вороны	Stas Piekha	313neyxbfwxtbi2t52gjvliqxisa	2025-06-16 15:34:21+00	\N	pop
3359	26	17emUWcCNEFzUXjV3gmMsl	\N	Рядом с тобой	hmyrov	31ghi62vkgnlb4wqr6muaisx7ldi	2025-07-04 16:25:26+00	\N	pop
3414	28	0VO8gYVDSwM1Qdd2GsMoYK	\N	Moth To A Flame (with The Weeknd)	Swedish House Mafia, The Weeknd	313neyxbfwxtbi2t52gjvliqxisa	2025-06-06 02:22:10+00	\N	edm
3363	27	0Y9BzZGT2FuLVPrHoq1g2G	\N	Fantaisie-Impromptu in C-Sharp Minor, Op. 66	Frédéric Chopin, Daniil Trifonov	1qzcdqlwqtm8lnthmvh2a70p9	2025-06-08 21:25:25+00	\N	classical piano, classical
3365	27	1158ckiB5S4cpsdYHDB9IF	\N	My Own Summer (Shove It)	Deftones	313neyxbfwxtbi2t52gjvliqxisa	2025-06-10 09:44:17+00	\N	nu metal, alternative metal, rap metal, shoegaze, rock
3410	28	19XpFsce28aByvCC4g89tJ	\N	Too Sweet	Hozier	313neyxbfwxtbi2t52gjvliqxisa	2025-06-05 23:31:27+00	\N	indie
3401	28	1XF3UZVN7lXRYzbHd3ZdKo	\N	Fortify	Kate Miller	31pd6hnytykuevog22xwj5yn2qjy	2025-06-04 08:20:42+00	\N	indie
3354	26	1s9i7W8zx7Nxx78MUIsvjV	\N	Outro	M83	31ghi62vkgnlb4wqr6muaisx7ldi	2025-07-03 12:19:26+00	\N	electronic
3408	28	2OBzYCYMNsD6yhBZZSs0xg	\N	Easy Lover	Miley Cyrus	1qzcdqlwqtm8lnthmvh2a70p9	2025-06-05 15:14:25+00	\N	pop
3377	27	25jSwur7S47WCiH0hQNUAo	\N	Words As Weapons	Seether	31pd6hnytykuevog22xwj5yn2qjy	2025-06-17 13:36:37+00	\N	post-grunge, alternative metal, rock
3400	28	2SGDxeH9stHj9bYbqtClHw	\N	Only in Your Eyes	Meltt	31pd6hnytykuevog22xwj5yn2qjy	2025-06-04 08:15:47+00	\N	indie
3415	28	2aFJcnnIvdPlfdwjnMEPHk	\N	Последний танец	Sergey Lazarev	1qzcdqlwqtm8lnthmvh2a70p9	2025-06-06 04:20:18+00	\N	pop
3376	27	2dMVIVXxaO9v2ImiSrWO0C	\N	Yesterday	breathe.	31pd6hnytykuevog22xwj5yn2qjy	2025-06-17 14:54:50+00	\N	indie
3360	26	2j0E0tP2ABhGMhJOlL1Wn4	\N	Notorious	Noémie Wolfs	31ghi62vkgnlb4wqr6muaisx7ldi	2025-07-07 12:27:55+00	\N	rock
3358	26	37adYGaYaAWTGhBaOzX4Fh	\N	Take A Slice	Glass Animals	31ghi62vkgnlb4wqr6muaisx7ldi	2025-07-03 12:39:07+00	\N	indie
3391	27	354WZaV3u6cuzTG2PmpYwm	\N	Get The Message	The Paradox	1qzcdqlwqtm8lnthmvh2a70p9	2025-06-19 22:13:44+00	\N	pop punk
3371	27	3EYOJ48Et32uATr9ZmLnAo	\N	Roxanne	The Police	1qzcdqlwqtm8lnthmvh2a70p9	2025-06-16 11:19:56+00	\N	rock
3403	28	3FC71bkSvkZhVYekAPUhrF	\N	People	half•alive	31pd6hnytykuevog22xwj5yn2qjy	2025-06-04 08:35:53+00	\N	indie
3380	27	3SNocJzkS03meGYxJ94nUV	\N	Я буду рядом	Не Твое Дело	31pd6hnytykuevog22xwj5yn2qjy	2025-06-17 20:02:36+00	\N	pop
3355	26	3gkSQbWTDBh0ZKq85WmJDz	\N	You Don’t Get Me High Anymore	Phantogram	31ghi62vkgnlb4wqr6muaisx7ldi	2025-07-03 12:26:52+00	\N	indie
3366	27	3XFaGEb6daqdj39ThpJ2XI	\N	Critical Darling	Slipknot	313neyxbfwxtbi2t52gjvliqxisa	2025-06-10 09:51:49+00	\N	nu metal, metal, alternative metal, rap metal, heavy metal
3396	28	3kG6GPkDkV2RQTm9QdYN9Z	\N	Desire	MEG MYERS	31pd6hnytykuevog22xwj5yn2qjy	2025-06-02 22:38:57+00	\N	alternative rock
3357	26	3qhlB30KknSejmIvZZLjOD	\N	End of Beginning	Djo	31ghi62vkgnlb4wqr6muaisx7ldi	2025-07-03 12:33:16+00	\N	synthwave
3406	28	3tgzhOod3UQIcbH4W1jP4u	\N	ЗАКРОЙ ГЛАЗА	DJ SMASH, Lida	1qzcdqlwqtm8lnthmvh2a70p9	2025-06-05 12:34:24+00	\N	electronic
3378	27	4BdGO1CaObRD4La9l5Zanz	\N	Sit Next to Me	Foster The People	31pd6hnytykuevog22xwj5yn2qjy	2025-06-17 13:37:21+00	\N	indie
3386	27	3uF63LzgAY5tVo2WeU9oWY	\N	Mr Centipede	Ocean Grove	1qzcdqlwqtm8lnthmvh2a70p9	2025-06-18 09:41:11+00	\N	nu metal, metalcore
3405	28	41h0H10TYujH8h3rnPKRmN	\N	Sure Thing	Impani, LU2VYK	1qzcdqlwqtm8lnthmvh2a70p9	2025-06-05 12:29:17+00	\N	afro house
3364	27	4bJygwUKrRgq1stlNXcgMg	\N	All The Things She Said	t.A.T.u.	1qzcdqlwqtm8lnthmvh2a70p9	2025-06-08 23:14:57+00	\N	pop
3412	28	4VTNDPiYfrsI2Phxwecz0z	\N	PULSE	PhaseOne, Banks Arcade	313neyxbfwxtbi2t52gjvliqxisa	2025-06-05 23:45:07+00	\N	dubstep, deathstep, riddim, bass music
3372	27	4Wm9LOrprI2pHUkuLNScaa	\N	Break Into My Heart	Daughtry	313neyxbfwxtbi2t52gjvliqxisa	2025-06-16 11:51:49+00	\N	post-grunge
3369	27	4pFvBZBMW3xHC3p92x4in4	\N	Прощай	The OM	313neyxbfwxtbi2t52gjvliqxisa	2025-06-15 23:58:19+00	\N	rock
3388	27	5qoS0fBiVHSy94hZNxWJ0r	\N	Steel Bones	Vuvuvultures	31ghi62vkgnlb4wqr6muaisx7ldi	2025-06-18 12:03:08+00	\N	rock
3397	28	4xZSaMuwXBJh2NjS3npsib	\N	Soul Clap	Showbiz & A.G.	31pd6hnytykuevog22xwj5yn2qjy	2025-06-02 23:09:12+00	\N	east coast hip hop, boom bap, old school hip hop
3379	27	55h5xNwW8na2bHKlZUfHh7	\N	SHALLOW	Magnolia Park	313neyxbfwxtbi2t52gjvliqxisa	2025-06-17 15:35:15+00	\N	pop punk
3395	28	5i1NE3fhVABUy8M22OKlfu	\N	Грустно	DenDerty	31pd6hnytykuevog22xwj5yn2qjy	2025-06-02 22:38:42+00	\N	witch house
3381	27	5kqIPrATaCc2LqxVWzQGbk	\N	7 Years	Lukas Graham	1qzcdqlwqtm8lnthmvh2a70p9	2025-06-18 09:13:27+00	\N	dansk pop
3362	26	6NkMQzeeaB3TmcMkElNl5g	\N	Darkest Days	breathe.	1qzcdqlwqtm8lnthmvh2a70p9	2025-07-10 22:37:36+00	\N	emo
3393	28	6HPLeKiNm92RbykX2BDTUB	\N	Stuck On You	Lionel Richie	1qzcdqlwqtm8lnthmvh2a70p9	2025-05-30 10:42:30+00	\N	motown
3404	28	6wElTgOfOsiTaM0jTsTh1s	\N	Abandon	EDDIE	31pd6hnytykuevog22xwj5yn2qjy	2025-06-04 10:58:31+00	\N	indie
3385	27	6ODwFNZWWbamxua9WaK6sW	\N	THE SOUND	The Plot In You	1qzcdqlwqtm8lnthmvh2a70p9	2025-06-18 09:38:40+00	\N	metalcore
3407	28	6X0pGXecf7efjR5VtaOzvn	\N	2 UR AREA	K+Lab, Pigeon Hole, Eputty	1qzcdqlwqtm8lnthmvh2a70p9	2025-06-05 12:43:42+00	\N	glitch
3411	28	6aBm5lBiBcEBc8moW055LI	\N	TYPE SH*T	Crankdat, NGHTMRE, Duke Deuce	313neyxbfwxtbi2t52gjvliqxisa	2025-06-05 23:37:49+00	\N	dubstep, riddim, edm, deathstep, bass house
3409	28	6gj0BlbkoBTW4ZVmHCciLd	\N	Blood Upon The Ashes	Killswitch Engage	313neyxbfwxtbi2t52gjvliqxisa	2025-06-05 23:31:20+00	\N	metalcore, metal
3374	27	77Fi5t6oOR6mdAHD2WA08Z	\N	ALL I WANT IS YOU	The Kid LAROI	1qzcdqlwqtm8lnthmvh2a70p9	2025-06-16 23:41:36+00	\N	pop
3389	27	77mLzdHEWRB60CLlV02TV2	\N	America	Logic, Black Thought, Chuck D, Big Lenbo, No ID	31ghi62vkgnlb4wqr6muaisx7ldi	2025-06-18 12:03:29+00	\N	hip hop
3370	27	7H6ev70Weq6DdpZyyTmUXk	\N	Say My Name	Destiny's Child	1qzcdqlwqtm8lnthmvh2a70p9	2025-06-16 11:06:42+00	\N	r&b
3353	26	7g4KNqjq1cxWETeqVpKNKK	\N	Cure	ERRA	31pd6hnytykuevog22xwj5yn2qjy	2025-07-02 18:07:02+00	\N	djent, metalcore, progressive metal, metal, deathcore, post-hardcore
3367	27	7lbCudHL7GkdPneBUaNWDn	\N	Blood Red	LANDMVRKS	313neyxbfwxtbi2t52gjvliqxisa	2025-06-10 12:20:39+00	\N	metalcore, deathcore, metal
3387	27	7oOEFDLSQscl0uGulnIEmG	\N	Love & Hate	Michael Kiwanuka	31pd6hnytykuevog22xwj5yn2qjy	2025-06-18 11:38:40+00	\N	soul
3382	27	7qEHsqek33rTcFNT9PFqLf	\N	Someone You Loved	Lewis Capaldi	1qzcdqlwqtm8lnthmvh2a70p9	2025-06-18 09:14:20+00	\N	soft pop
3465	30	0auX6W6oLjO9cHmx4UTaNj	\N	Feel It	d4vd	31pd6hnytykuevog22xwj5yn2qjy	2025-05-23 06:53:00+00	\N	pop
3435	29	0UsNgv6unHisK9NslsZxwz	\N	Where Is My Mind?	Tkay Maidza	31ghi62vkgnlb4wqr6muaisx7ldi	2025-05-29 16:40:47+00	\N	alternative r&b
3478	30	0iiB9CYptXO5Fz728LHHsQ	\N	Mahal	Glass Beams	1qzcdqlwqtm8lnthmvh2a70p9	2025-05-23 11:23:04+00	\N	indie
3424	29	2StQdgJrt31eK1iFalj9p0	\N	Ambrosia - Rival Remix	YMIR, Rival	1qzcdqlwqtm8lnthmvh2a70p9	2025-05-24 09:29:31+00	\N	future bass
3456	30	0qKX14YZHptDWiEN0CgxGz	\N	Zenith	Kavinsky, Olivia Merilahti, Morgan Phalen	31pd6hnytykuevog22xwj5yn2qjy	2025-05-21 09:41:04+00	\N	synthwave, french house
3427	29	0wCFRpwx6L9nlji6fbYhm4	\N	halcyon	whitelines	1qzcdqlwqtm8lnthmvh2a70p9	2025-05-25 16:08:36+00	\N	dark ambient, synthwave, electroclash, breakcore
3476	30	1IQA1li1Io3D5WY6RNekD6	\N	Pale Moonlight	Dayseeker	1qzcdqlwqtm8lnthmvh2a70p9	2025-05-23 11:17:10+00	\N	metalcore, post-hardcore
3459	30	1u3OxJiXoYFdA0Fmd9yURC	\N	Limits	Bad Omens	31pd6hnytykuevog22xwj5yn2qjy	2025-05-21 09:50:37+00	\N	metalcore
3467	30	1zx6GSqLYI2ynzAHnPRKBR	\N	There’d Better Be A Mirrorball	Arctic Monkeys	31pd6hnytykuevog22xwj5yn2qjy	2025-05-23 09:01:10+00	\N	indie, garage rock
3426	29	23iKK3KMQjKCcYJfe0stqE	\N	1 More Night	Axel Boy	1qzcdqlwqtm8lnthmvh2a70p9	2025-05-25 16:01:32+00	\N	bass house, bassline, dubstep, drum and bass
3473	30	2RouBNPT9c8lzQ5Hc7V45c	\N	Shoot	Yamê	1qzcdqlwqtm8lnthmvh2a70p9	2025-05-23 11:09:25+00	\N	french rap
3446	29	36EfR7HreYyTLh0fLylOUo	\N	Red Velvet	One True God	313neyxbfwxtbi2t52gjvliqxisa	2025-05-30 09:50:59+00	\N	pop
3458	30	2UKARCqDrhkYDoVR4FN5Wi	\N	Plug in Baby	Muse	31pd6hnytykuevog22xwj5yn2qjy	2025-05-21 09:48:49+00	\N	alternative rock, rock
3449	30	31iIf973tO1iLI2ql44fdI	\N	For You	The Devil Wears Prada	313neyxbfwxtbi2t52gjvliqxisa	2025-05-13 00:14:18+00	\N	metalcore, post-hardcore, screamo, deathcore, metal
3445	29	38v03rigflHcd4wPZ9xKmX	\N	ты	vestfalin, UBEL	313neyxbfwxtbi2t52gjvliqxisa	2025-05-30 09:50:42+00	\N	electronic
3464	30	3u1PIUtyVSks0qczfdJErz	\N	The End	Jutes	1qzcdqlwqtm8lnthmvh2a70p9	2025-05-22 22:02:24+00	\N	indie
3469	30	46qyu9Ybwj1uMeeCSmv0t5	\N	Камушки	Бонд с кнопкой	31ghi62vkgnlb4wqr6muaisx7ldi	2025-05-23 10:54:47+00	\N	indie
3457	30	3e0ZL2Wy0OH28zfaz44IBB	\N	Wrap Your Arms	ViVii	31pd6hnytykuevog22xwj5yn2qjy	2025-05-21 09:45:31+00	\N	stutter house
3425	29	3owm6kuLMIw8qOYuUB3HAT	\N	electric dream	Silent Boy, MASAKA, defyer	1qzcdqlwqtm8lnthmvh2a70p9	2025-05-25 11:51:32+00	\N	hyperpop
3416	28	3tlw6dqv2qejTGLnVaEsgb	\N	Gravity	Sleep Theory	1qzcdqlwqtm8lnthmvh2a70p9	2025-06-06 08:49:24+00	\N	metalcore
3417	28	4TRy6cMmSQLJLVqXi0zgTt	\N	Bishop Ford	femdot.	31ghi62vkgnlb4wqr6muaisx7ldi	2025-06-06 10:57:02+00	\N	hip hop
3475	30	4k8rROZ9PXhbegDZbKlv0D	\N	The Last Day of Summer	Hayes & Y	1qzcdqlwqtm8lnthmvh2a70p9	2025-05-23 11:14:19+00	\N	indie
3432	29	4AH5FTj8Qr5ZiWxXQJG2qs	\N	絶彩	SUGIZO, 京	31ghi62vkgnlb4wqr6muaisx7ldi	2025-05-29 16:39:39+00	\N	visual kei, j-rock, jungle
3428	29	4TGYYaUgukkUeDojVaytip	\N	Hurricane	RIOT	313neyxbfwxtbi2t52gjvliqxisa	2025-05-25 23:35:32+00	\N	dubstep, deathstep, riddim
3437	29	4p5bLiIaEktrIRoiqbV7Nk	\N	Down For You	Ayzha Nyree	1qzcdqlwqtm8lnthmvh2a70p9	2025-05-29 23:02:44+00	\N	r&b
3448	30	4TjCaQsPQhGZUk0Hls4O3Y	\N	Lachryma	Ghost	313neyxbfwxtbi2t52gjvliqxisa	2025-05-13 00:14:13+00	\N	metal, hard rock
3463	30	4rpazUkPc1QG6b9rBXB1wb	\N	COPY ME	Loqiemean, whiteback, Sqwore, Kill Eva	1qzcdqlwqtm8lnthmvh2a70p9	2025-05-22 21:07:45+00	\N	rap
3421	28	4rtbWvbrcoVtnSyjgMz0qm	\N	Inaction	Declan Welsh and The Decadent West	31ghi62vkgnlb4wqr6muaisx7ldi	2025-06-06 11:00:22+00	\N	indie
3468	30	52IT5fWqmJyvQYLikL5Q7W	\N	Не молчи	Akula	1qzcdqlwqtm8lnthmvh2a70p9	2025-05-23 10:41:00+00	\N	rap
3440	29	55zPiutxcwfzLXIUsJZAXa	\N	Ледокол	Обстоятельства	1qzcdqlwqtm8lnthmvh2a70p9	2025-05-29 23:28:08+00	\N	rock
3434	29	5W53qjFtumdTyc19tTKjFG	\N	Greeney Blue	Mellah	31ghi62vkgnlb4wqr6muaisx7ldi	2025-05-29 16:40:18+00	\N	indie
3466	30	5iEaqKbN4hgQVGEhxBmPea	\N	Still Cookin	Free Flow Flava, ndls404	31pd6hnytykuevog22xwj5yn2qjy	2025-05-23 06:55:51+00	\N	hip hop
3439	29	5PFT4URNOdk6z6H3wzuySZ	\N	Крылья	билборды	1qzcdqlwqtm8lnthmvh2a70p9	2025-05-29 23:14:16+00	\N	frenchcore
3430	29	5UrZ1UfrJhyB7RMmWaRjXO	\N	Crash & Burn	Northlane, PhaseOne	313neyxbfwxtbi2t52gjvliqxisa	2025-05-25 23:37:27+00	\N	djent, metalcore, progressive metal, metal, deathcore, post-hardcore
3423	29	62prK5eKq1U6qIzGvIRMdG	\N	KID AGAIN	Jon Bellion	1qzcdqlwqtm8lnthmvh2a70p9	2025-05-23 22:56:49+00	\N	pop
3451	30	5cBNCR4qXiNLCOHTFdU809	\N	So Numb	TX2	313neyxbfwxtbi2t52gjvliqxisa	2025-05-13 00:14:28+00	\N	emo
3472	30	5g4vnyN4eF4ymZuViUd3cG	\N	Death Sprint	Enei, En:vy	1qzcdqlwqtm8lnthmvh2a70p9	2025-05-23 11:03:34+00	\N	drum and bass, liquid funk, jungle
3471	30	69zCrlRTLn4sLeU4fJOzmE	\N	Кухни	Бонд с кнопкой	31ghi62vkgnlb4wqr6muaisx7ldi	2025-05-23 10:56:17+00	\N	alternative rock
3436	29	6siOHdRw7Y4g0NmAZ5bweV	\N	White Picket Fence	psykhi	31ghi62vkgnlb4wqr6muaisx7ldi	2025-05-29 16:41:02+00	\N	indie
3418	28	73J7dvqf4u1SZZAkQaGp2b	\N	The Meeting	Whilk & Misky	31ghi62vkgnlb4wqr6muaisx7ldi	2025-06-06 10:57:16+00	\N	downtempo
3479	30	6FhWelfRDMFZRtFUU6SIdC	\N	怪獣	sakanaction	1qzcdqlwqtm8lnthmvh2a70p9	2025-05-23 11:26:58+00	\N	j-pop, j-rock, japanese indie
3419	28	6NzIiBuvtfwtcaAK6HzfMQ	\N	Want It	Pola & Bryson, IYAMAH	31ghi62vkgnlb4wqr6muaisx7ldi	2025-06-06 10:58:19+00	\N	liquid funk, drum and bass
3461	30	7DJNQmAfr1TyyNEkBgVloy	\N	I Wish	Tamahau, Rebel Musique	1qzcdqlwqtm8lnthmvh2a70p9	2025-05-21 10:22:40+00	\N	electronic
3477	30	7Kn0hFlO6FlfEPxmv8veBZ	\N	We don't talk anymore	Cellz, Packed Rich	1qzcdqlwqtm8lnthmvh2a70p9	2025-05-23 11:19:07+00	\N	rap
3429	29	78pJf69QrLLzAmW5A6bxIS	\N	In My Head	Pythius, REEBZ	313neyxbfwxtbi2t52gjvliqxisa	2025-05-25 23:35:59+00	\N	drum and bass, drumstep
3444	29	7cHFF1TL8b9sD1ylgd6GdK	\N	ДВОР	VERNO, The OM	313neyxbfwxtbi2t52gjvliqxisa	2025-05-30 09:50:04+00	\N	hip hop
3441	29	7cLICLD3pmaVErFdkfEmxw	\N	No Psychic Vamps	Bruvvy	1qzcdqlwqtm8lnthmvh2a70p9	2025-05-29 23:36:08+00	\N	punk
3422	28	7qOSylQyXSIIXrXMhr8wWd	\N	24	Jem	31ghi62vkgnlb4wqr6muaisx7ldi	2025-06-06 11:05:38+00	\N	pop
3460	30	7ySGIM3JqhwlFu5mrULOR8	\N	In The Echo	Koven	1qzcdqlwqtm8lnthmvh2a70p9	2025-05-21 10:20:07+00	\N	drum and bass, liquid funk, drumstep, chillstep
3420	28	0LCHO5qNN5fEncfAIcjtAH	\N	Falling Endlessly	WILLOW	31ghi62vkgnlb4wqr6muaisx7ldi	2025-06-06 10:59:31+00	\N	alternative rock
3495	31	0EYOdF5FCkgOJJla8DI2Md	\N	B.Y.O.B.	System Of A Down	31pd6hnytykuevog22xwj5yn2qjy	2025-05-02 07:05:41+00	\N	nu metal, metal, alternative metal, rap metal, rock
3507	31	0KiIoqFR32NisiykHCXsOo	\N	Ohio	Mr FijiWiji	1qzcdqlwqtm8lnthmvh2a70p9	2025-05-02 08:26:29+00	\N	chillstep
3508	31	0eFqPUbuiobmOEiotEFxGy	\N	R 2 ME	BL3SS, Tchami	1qzcdqlwqtm8lnthmvh2a70p9	2025-05-02 08:27:03+00	\N	house
3521	32	0lkreRN3IFw0vkJiYHPBtL	\N	Zaza and Some Runtz (Smoke Break)	Terry Presume	31ghi62vkgnlb4wqr6muaisx7ldi	2025-04-24 12:14:01+00	\N	r&b
3481	31	0qRepSHHU3ir0OYAzAO2a6	\N	Гори, моя любовь	RAUSH	313neyxbfwxtbi2t52gjvliqxisa	2025-04-29 11:47:10+00	\N	pop
3540	33	1CvkQFKpHQYfpXjR90fAGH	\N	Понарошку	Juriy Titov	1qzcdqlwqtm8lnthmvh2a70p9	2025-04-16 10:34:46+00	\N	folk
3533	33	1c4Bmw0mpb6DEF8UFI2T3M	\N	Вова-чума	Irakli	31pd6hnytykuevog22xwj5yn2qjy	2025-03-31 09:13:27+00	\N	pop
3499	31	1W3fMkViHndp2kv7PQNfAQ	\N	Hung Up	The Mysterines	31ghi62vkgnlb4wqr6muaisx7ldi	2025-05-02 07:20:14+00	\N	indie rock
3514	32	1mCvM05OlYWQd77RDxCTLD	\N	Life Worth Living	LAUREL	31pd6hnytykuevog22xwj5yn2qjy	2025-04-24 08:32:46+00	\N	indie
3503	31	1rnDXKFsZVk9i9telTbGlm	\N	Zatoichi	Free Flow Flava	1qzcdqlwqtm8lnthmvh2a70p9	2025-05-02 07:33:46+00	\N	hip hop
3539	33	1yR1QBcKdad813IFqvqRfo	\N	Высоко	Yulia Savicheva	31pd6hnytykuevog22xwj5yn2qjy	2025-03-31 09:25:37+00	\N	pop
3527	32	1ulH5PIntNj0ro2K69W4Fx	\N	Damocles	Sleep Token	313neyxbfwxtbi2t52gjvliqxisa	2025-04-24 23:37:23+00	\N	progressive metal, metalcore
3498	31	2ENgaBS5vLUpqUw8inkZZp	\N	Hey Now	London Grammar	31pd6hnytykuevog22xwj5yn2qjy	2025-05-02 07:09:53+00	\N	indie
3494	31	2IWtloZYQDcP8Ashwx8QEF	\N	Black Out Days	Phantogram	31pd6hnytykuevog22xwj5yn2qjy	2025-05-02 07:04:30+00	\N	alternative rock
3484	31	2ZVkS4Zybo4XxCaBAMl29h	\N	Моя Лили	YOUNG LARI	1qzcdqlwqtm8lnthmvh2a70p9	2025-05-02 06:48:04+00	\N	rap
3528	32	2katj8BEukc8fc2hwYw5a4	\N	Дисфория	polnalyubvi	1qzcdqlwqtm8lnthmvh2a70p9	2025-04-25 10:09:56+00	\N	emo
3496	31	3850dYVgOFIXJh5U4BFEWH	\N	Hung Up	Madonna	31pd6hnytykuevog22xwj5yn2qjy	2025-05-02 07:07:19+00	\N	pop
3487	31	2ypgH76n4e8TR6IFAv8Z88	\N	Eyes Closed	Don Diablo	1qzcdqlwqtm8lnthmvh2a70p9	2025-05-02 06:54:14+00	\N	future house, edm
3532	32	3BNxtHk2hMby1EJb5SAdZ8	\N	DRAMATIQUE	Земфира от Луки	1qzcdqlwqtm8lnthmvh2a70p9	2025-04-25 10:47:05+00	\N	rock
3531	32	397jCX8wRPKsSZTDcAUccg	\N	NADA DE NADA	KVRXD, MAXPVNK, DJ RITMO DIVINO	1qzcdqlwqtm8lnthmvh2a70p9	2025-04-25 10:27:33+00	\N	phonk, brazilian phonk
3512	32	3Im3W2ml2VthOmZxS5gRac	\N	Под испанским небом	Ariana	313neyxbfwxtbi2t52gjvliqxisa	2025-04-18 12:45:04+00	\N	pop
3524	32	3GAqddcV0nwMHQI5RfMXoI	\N	Afterlife (from the Netflix Series "Devil May Cry")	Evanescence	313neyxbfwxtbi2t52gjvliqxisa	2025-04-24 23:28:20+00	\N	alternative metal
3535	33	3tELfeaQgjuEuur62sVNPU	\N	Я теряю корни	Korni	31pd6hnytykuevog22xwj5yn2qjy	2025-03-31 09:14:53+00	\N	pop
3509	32	3NowUoHEukN7NLT1vmoAdm	\N	Drop in the Ocean	Venjent	313neyxbfwxtbi2t52gjvliqxisa	2025-04-18 12:44:35+00	\N	drum and bass
3525	32	3OLf8hZ1i437w7SGXoNXDR	\N	Creatures of Chaos	The Rasmus	313neyxbfwxtbi2t52gjvliqxisa	2025-04-24 23:28:28+00	\N	finnish rock
3497	31	3Q30QundzRyAG6x19JVYtA	\N	Hold Your Colour	Pendulum	31pd6hnytykuevog22xwj5yn2qjy	2025-05-02 07:08:08+00	\N	drum and bass, dubstep
3519	32	3wtu6DzTlTho7oEl0BtQUq	\N	мой дивный мир	астра	31ghi62vkgnlb4wqr6muaisx7ldi	2025-04-24 12:13:20+00	\N	electronic
3530	32	3uqwPw8HylQn9vcmZuDQK3	\N	Nada Quedo	Impani, LU2VYK	1qzcdqlwqtm8lnthmvh2a70p9	2025-04-25 10:12:19+00	\N	afro house
3537	33	49CWhrMH4bKxZtnXGuf7t0	\N	Твой или ничей	Бис	31pd6hnytykuevog22xwj5yn2qjy	2025-03-31 09:21:50+00	\N	pop
3534	33	4Mu1RNmuZdyRK2Kbvskh5D	\N	Беспризорник	Hi-Fi	31pd6hnytykuevog22xwj5yn2qjy	2025-03-31 09:14:02+00	\N	pop
3506	31	583UlDn7B9ccYF0NQgvBVv	\N	БОЛОТО СТРУГАЦКИХ	Loqiemean, Thomas Mraz, BOOKER	1qzcdqlwqtm8lnthmvh2a70p9	2025-05-02 07:39:25+00	\N	pop
3515	32	4go8e3GDxEIjqz7AkdxR2W	\N	Hold On	HÆLOS	31pd6hnytykuevog22xwj5yn2qjy	2025-04-24 08:32:55+00	\N	alternative dance
3483	31	4xBNejHCh7vBVb4m4lQD00	\N	I Don't Like People (& They Don't Like Me)	Boston Manor	313neyxbfwxtbi2t52gjvliqxisa	2025-04-30 13:00:45+00	\N	pop punk
3485	31	5fWVTCBOLOYSZfd6cck1PI	\N	АМЕЛИ	Юля Паршута	1qzcdqlwqtm8lnthmvh2a70p9	2025-05-02 06:49:32+00	\N	pop
3526	32	5N3yqWjKCdVF2KExX6tM2P	\N	Hate Not Gone	Stone Sour	313neyxbfwxtbi2t52gjvliqxisa	2025-04-24 23:28:37+00	\N	post-grunge, alternative metal, nu metal
3504	31	5r0S3IR72j7WHg4hFod25g	\N	Углами	Rushana	1qzcdqlwqtm8lnthmvh2a70p9	2025-05-02 07:35:40+00	\N	electronic
3511	32	5pDsLciWKVoFt2bUBTLp4n	\N	XLR8	REAPER	313neyxbfwxtbi2t52gjvliqxisa	2025-04-18 12:44:49+00	\N	drum and bass, drumstep, dubstep
3486	31	5pxpGt5lC7t26nlIUbtOqL	\N	FROSTSURGE	qõke	1qzcdqlwqtm8lnthmvh2a70p9	2025-05-02 06:53:11+00	\N	phonk, rally house
3529	32	65I233XwMBY6EpVHdJL1wQ	\N	Sometimes	One True God, Cxssidy	1qzcdqlwqtm8lnthmvh2a70p9	2025-04-25 10:11:16+00	\N	hip hop
3501	31	64WA9NLkZDyIFRcnqfJTu3	\N	is that love?	cloudyfield	1qzcdqlwqtm8lnthmvh2a70p9	2025-05-02 07:29:57+00	\N	shoegaze
3541	33	65QwqNYfTuVRV4Ccmx4NLC	\N	Поздно	Natalia Podolskaya	1qzcdqlwqtm8lnthmvh2a70p9	2025-04-16 10:36:44+00	\N	pop
3513	32	69WNjN8IAwp8C27TT5i6DQ	\N	Sid & Nancy	Lumen	313neyxbfwxtbi2t52gjvliqxisa	2025-04-18 12:45:39+00	\N	punk
3522	32	6FrnXFzf5YWh9CNUw7rtOB	\N	Закричу на весь мир	Танисия	31ghi62vkgnlb4wqr6muaisx7ldi	2025-04-24 12:17:28+00	\N	pop
3500	31	6X1qkAaZoCIgcrqyeRJP8L	\N	23, Never Me	Dead Pony	31ghi62vkgnlb4wqr6muaisx7ldi	2025-05-02 07:21:13+00	\N	punk
3493	31	6nO2E5BXNpBze6juPjzMua	\N	Chin Chin	Noga Erez, ECHO	31ghi62vkgnlb4wqr6muaisx7ldi	2025-05-02 07:03:22+00	\N	pop
3538	33	7G8DzRRKA9PfcEh01pRUOt	\N	Про любовь	Fabrika	31pd6hnytykuevog22xwj5yn2qjy	2025-03-31 09:22:55+00	\N	pop
3518	32	71fSn6OIF7HnCbgCzOBqpj	\N	Runnin' Wild	Airbourne	31pd6hnytykuevog22xwj5yn2qjy	2025-04-24 08:54:53+00	\N	hard rock
3488	31	7hZ1JuwJm4hZsS8IHnKDt3	\N	Note to Self	From First To Last	1qzcdqlwqtm8lnthmvh2a70p9	2025-05-02 06:58:34+00	\N	post-hardcore, screamo, emo
3492	31	7nxPLz8uUvjnnunEak24jG	\N	Ventimiglia	Canine	31ghi62vkgnlb4wqr6muaisx7ldi	2025-05-02 07:02:36+00	\N	french indie pop
3536	33	0aqsbxUP2sX8m9aGO8aTSv	\N	Самая любимая	Челси	31pd6hnytykuevog22xwj5yn2qjy	2025-03-31 09:20:50+00	\N	pop
3595	35	0iWc82wGrRK64rASgdjfBY	\N	Бешеные псы	Гости Гаррисона	1qzcdqlwqtm8lnthmvh2a70p9	2025-03-20 23:29:14+00	\N	rap
3601	35	0uuxAXS1X7kH0WjC0nD6q9	\N	By The Time You're Reading This	YONAKA	31pd6hnytykuevog22xwj5yn2qjy	2025-03-21 10:04:37+00	\N	alternative rock
3556	34	15jVcWWnNFEVPbN8a8ORex	\N	ОСТАНОВИ МЕНЯ	BOOKER	31ghi62vkgnlb4wqr6muaisx7ldi	2025-03-27 12:03:36+00	\N	electronic
3569	34	11TTMESBDi9mN6c3GApKYh	\N	Drama	sadance	1qzcdqlwqtm8lnthmvh2a70p9	2025-03-28 06:22:35+00	\N	breakcore
3547	33	163LFPs0EjyjeCo6a3frCa	\N	Понимаешь	Ирина Тонева, Павел Артемьев	31ghi62vkgnlb4wqr6muaisx7ldi	2025-04-16 11:39:12+00	\N	pop
3543	33	1Ys49LDfoYonmmtoglUKfN	\N	Чужая невеста	Челси	1qzcdqlwqtm8lnthmvh2a70p9	2025-04-16 10:37:36+00	\N	pop
3564	34	19gqEo6BksJ7OEqyOAziks	\N	Hush	IMANU, KROY	1qzcdqlwqtm8lnthmvh2a70p9	2025-03-28 06:15:04+00	\N	drum and bass, drumstep
3582	35	1kcLWoFxC515vJ64Gxtqnj	\N	Совпадения	PALC	31ghi62vkgnlb4wqr6muaisx7ldi	2025-03-20 16:10:40+00	\N	rap
3561	34	21bqHdkh0VhZWRH2DgdPeV	\N	Survivor	APOC, THE DAY WE LEFT EARTH	313neyxbfwxtbi2t52gjvliqxisa	2025-03-27 23:59:27+00	\N	electronic
3567	34	2Cq9S6dIfLtueB1Aquv1Rj	\N	Where The Silence Goes	LEAP	1qzcdqlwqtm8lnthmvh2a70p9	2025-03-28 06:19:25+00	\N	electronic
3580	35	267WPtfCQlbwIPWWX3PJdd	\N	Garden	Frizzy P & Mr Cole	31ghi62vkgnlb4wqr6muaisx7ldi	2025-03-20 15:47:50+00	\N	jazz rap
3545	33	2BOqDYLOJBiMOXShCV1neZ	\N	Dancing On My Own	Calum Scott	1qzcdqlwqtm8lnthmvh2a70p9	2025-04-16 10:48:02+00	\N	soft pop
3566	34	2lnineAGp4ibOq4kRFrryr	\N	Черная полоса	Keendy, KEER	1qzcdqlwqtm8lnthmvh2a70p9	2025-03-28 06:17:28+00	\N	pop
3570	34	2Bs0RFcxDaTgmpM1Kdmy46	\N	shadows	shxpe	1qzcdqlwqtm8lnthmvh2a70p9	2025-03-28 06:23:58+00	\N	witch house, electroclash
3597	35	2rBfdz3AJvYXIddlptHgbi	\N	Ошибки	RAUSH	313neyxbfwxtbi2t52gjvliqxisa	2025-03-20 23:57:18+00	\N	pop
3574	34	34R5dih7V1DWiuuUxH2tcj	\N	A+ (feat. Ravid Plotnik)	Noga Erez, Ravid Plotnik	31pd6hnytykuevog22xwj5yn2qjy	2025-03-28 08:39:26+00	\N	pop
3593	35	3kOZ1dSwiERAx6RigDcm6y	\N	не уходи	Armich	1qzcdqlwqtm8lnthmvh2a70p9	2025-03-20 23:29:14+00	\N	pop
3583	35	2xKLzKhm2AEGyZapAL5NjH	\N	Piss Punk	VIAL	31ghi62vkgnlb4wqr6muaisx7ldi	2025-03-20 16:18:32+00	\N	riot grrrl, queercore
3550	33	4LYp7qbnW7pYc90vHjyw7E	\N	Лондон-Париж	Irakli	313neyxbfwxtbi2t52gjvliqxisa	2025-04-16 23:32:17+00	\N	pop
3571	34	3AJpflJmBCW0ToJqvSMYLx	\N	Silver	Sibewest	1qzcdqlwqtm8lnthmvh2a70p9	2025-03-28 06:23:58+00	\N	witch house, drift phonk, chillstep
3587	35	3dNDt0VLKc0xUcuTI20Q73	\N	Innocence 2025	NERO, Taiki Nulight	1qzcdqlwqtm8lnthmvh2a70p9	2025-03-20 23:29:14+00	\N	dubstep, dub
3560	34	4d5X6eE4rjNoehTyvwKe49	\N	Моя Ми	Динамит	313neyxbfwxtbi2t52gjvliqxisa	2025-03-27 23:59:16+00	\N	pop
3559	34	3uE2CHkhqSk2UZdKNb4dUl	\N	Limosina	1tbsp, cherry chola	31ghi62vkgnlb4wqr6muaisx7ldi	2025-03-27 12:07:56+00	\N	lo-fi house
3573	34	4l2dISua5ZoGKx7Bz7PZLa	\N	ROCK BOTTOM	Heylu	1qzcdqlwqtm8lnthmvh2a70p9	2025-03-28 07:16:38+00	\N	rock
3568	34	4YHeXM7mgLvxpvaUGnybGK	\N	Whiplash (English Version)	aespa	1qzcdqlwqtm8lnthmvh2a70p9	2025-03-28 06:21:22+00	\N	k-pop
3558	34	4rE4qF4baoXpustrgtnFRw	\N	Backyard Boy (with Jeremy Zucker)	Claire Rosinkranz, Jeremy Zucker	31ghi62vkgnlb4wqr6muaisx7ldi	2025-03-27 12:05:20+00	\N	pop
3586	35	5CcJq7qz9fLKaA6DLpffeF	\N	A PLACE CALLED EUPHORIA	Tropic Gold	313neyxbfwxtbi2t52gjvliqxisa	2025-03-20 23:26:56+00	\N	electronic
3557	34	5xlraY7SqLFWMexkVuDGXl	\N	Ол ин	TERELYA, ГÓРОН	31ghi62vkgnlb4wqr6muaisx7ldi	2025-03-27 12:04:21+00	\N	pop
3548	33	6ZBVvOXNy3zONVEWcRsU26	\N	Сердце-магнит	Sogdiana	31ghi62vkgnlb4wqr6muaisx7ldi	2025-04-16 11:44:05+00	\N	r&b
3551	33	5PIEUhmz7jG3AXLoIjy66m	\N	Дальше всех	Elena Temnikova	313neyxbfwxtbi2t52gjvliqxisa	2025-04-16 23:40:32+00	\N	europop
3600	35	5jcwno0cS1H268LWyYpof1	\N	7 Seconds	Joezi, Coco, Pape Diouf	31pd6hnytykuevog22xwj5yn2qjy	2025-03-21 10:01:40+00	\N	afro house, afro tech, tribal house
3596	35	5qmYsAjOo7AVWcVSvQm8Wh	\N	INCOMPLETE	coldrain	313neyxbfwxtbi2t52gjvliqxisa	2025-03-20 23:32:26+00	\N	j-rock, metalcore, anime
3581	35	6aLpLTAUASREvQE105XOb3	\N	Right To It (with Ashe)	Louis The Child, Ashe	31ghi62vkgnlb4wqr6muaisx7ldi	2025-03-20 15:49:34+00	\N	electronic
3599	35	636WyFxSbCDIMLPbWkfVBQ	\N	Butterflies and Hurricanes	Muse	31pd6hnytykuevog22xwj5yn2qjy	2025-03-21 09:58:59+00	\N	alternative rock, rock
3591	35	69FsZtKV3syfUMApe92Spf	\N	Waiting For Me	Monocule, Louis III, Nicky Romero	1qzcdqlwqtm8lnthmvh2a70p9	2025-03-20 23:29:14+00	\N	progressive house
3579	34	6Xuz1r6GgUXgYZPn8XEFAV	\N	La vie - A COLORS SHOW	Ichon, COLORS	1qzcdqlwqtm8lnthmvh2a70p9	2025-03-28 10:24:56+00	\N	french rap, french r&b
3592	35	6aTEg2WEAc6tNWGbQtVgbi	\N	Пташка	ROXOLANA, Wavewalkrs	1qzcdqlwqtm8lnthmvh2a70p9	2025-03-20 23:29:14+00	\N	pop
3555	34	6lFnMWwsdIkKF92Ky6fu0u	\N	Everything Is Fine	J Rongson	31ghi62vkgnlb4wqr6muaisx7ldi	2025-03-27 12:02:19+00	\N	downtempo
3594	35	6y4dmIK3PxtOgzKXseFK29	\N	take it for granted	GRAHAM	1qzcdqlwqtm8lnthmvh2a70p9	2025-03-20 23:29:14+00	\N	indie
3576	34	6jTbKd7VnhCt5qxyWTdak7	\N	Karibu	WITH U	31pd6hnytykuevog22xwj5yn2qjy	2025-03-28 08:39:44+00	\N	afro house
3589	35	7ntWYANwXttsfejXrUxQcm	\N	Cherry Waves	MISSIO	1qzcdqlwqtm8lnthmvh2a70p9	2025-03-20 23:29:14+00	\N	alternative rock
3577	34	6qgvlhy3tBwY0V7SPjYZut	\N	Libertine - Abbey Road Version	Architects	31pd6hnytykuevog22xwj5yn2qjy	2025-03-28 08:46:04+00	\N	metalcore, djent, metal, mathcore, post-hardcore, deathcore
3578	34	7CuXB3Dr61IvDFEWfqG3sE	\N	More	Jan Blomqvist, Elena Pitoulis	31pd6hnytykuevog22xwj5yn2qjy	2025-03-28 08:51:26+00	\N	melodic house, melodic techno
3562	34	7Iiek3SL6PluRxj9IgbTC1	\N	Cure For Me	AURORA	313neyxbfwxtbi2t52gjvliqxisa	2025-03-27 23:59:33+00	\N	norwegian pop, art pop
3598	35	7hX6BNKMLU4O5S32srAtCC	\N	Egyptian Luvr	Rejjie Snow, Aminé, Dana Williams	31pd6hnytykuevog22xwj5yn2qjy	2025-03-21 09:56:39+00	\N	jazz rap
3588	35	7lrnjamb0dVKPuh5aiiGdT	\N	Jaded	二口魔菜 Futakuchi Mana	1qzcdqlwqtm8lnthmvh2a70p9	2025-03-20 23:29:14+00	\N	j-rock
3565	34	7yRkdZDEKjSUP45TlkGvCd	\N	Born Again (feat. Doja Cat & RAYE) - Purple Disco Machine Remix	LISA, Purple Disco Machine, Doja Cat, RAYE	1qzcdqlwqtm8lnthmvh2a70p9	2025-03-28 06:17:11+00	\N	k-pop
3546	33	0QYQSGzZOndmoqtposNMeV	\N	Когда я стану кошкой	Мария Ржевская	31ghi62vkgnlb4wqr6muaisx7ldi	2025-04-16 11:38:23+00	\N	pop
3634	36	0hiOEa5YFyyOSnAuoN82Qm	\N	Mud Angel (Live)	Blacklit Canopy Official	1qzcdqlwqtm8lnthmvh2a70p9	2025-03-13 12:11:22+00	\N	indie
3615	36	0pLP2dpbwmuKa0rL0ktrxr	\N	Protein v2 (feat. Obongjayar & WESTSIDE BOOGIE)	Jeshi, Obongjayar, WESTSIDE BOOGIE	31ghi62vkgnlb4wqr6muaisx7ldi	2025-03-11 10:19:50+00	\N	hip hop
3624	36	0hpWmAB3L0OJ3VBeMkOQUu	\N	Kool-Aid	Bring Me The Horizon	313neyxbfwxtbi2t52gjvliqxisa	2025-03-13 06:01:31+00	\N	metalcore, emo, rock, screamo, post-hardcore
3621	36	0q65P0K9LM6PkNPbB2S9JI	\N	The Beginning	Rationale	31pd6hnytykuevog22xwj5yn2qjy	2025-03-12 20:53:22+00	\N	pop
3618	36	1au2UduxcvHfa0fZS3Szci	\N	Lavender Sunflower	Tory Lanez	31pd6hnytykuevog22xwj5yn2qjy	2025-03-12 10:32:49+00	\N	r&b
3647	37	0xoyUiHhxVH4gwb0CRgNmg	\N	Like A Villain	Bad Omens	313neyxbfwxtbi2t52gjvliqxisa	2025-03-04 13:55:50+00	\N	metalcore
3637	37	1WRKUuAYZ0khHs4TJ5JHlC	\N	The King	Kayar	31ghi62vkgnlb4wqr6muaisx7ldi	2025-03-01 04:09:14+00	\N	tamil indie
3625	36	1cFlpmDhA2naLoFMjQjvqK	\N	Prey	Split Persona	313neyxbfwxtbi2t52gjvliqxisa	2025-03-13 09:40:27+00	\N	electronic
3653	37	1geEunKfdAxM9Y9UmDmQdu	\N	Мне стыдно жить	Slava KPSS	1qzcdqlwqtm8lnthmvh2a70p9	2025-03-06 16:30:03+00	\N	rap
3651	37	24Jz4728DNTr93ISVdAEsk	\N	Блок	Roman Bestseller	1qzcdqlwqtm8lnthmvh2a70p9	2025-03-06 16:30:03+00	\N	rap
3649	37	1zhPsf64QGn0BrjgQAuWeA	\N	Calling	Don Kon	1qzcdqlwqtm8lnthmvh2a70p9	2025-03-06 16:30:03+00	\N	melodic techno
3602	35	2BG4zWmWuxTIpA4uheItEh	\N	Dead To Me	Palaye Royale	31pd6hnytykuevog22xwj5yn2qjy	2025-03-21 10:06:10+00	\N	emo
3608	36	2ziD99akA0emD2qtj7WWfw	\N	Тыпырдатып	Дышать	31pd6hnytykuevog22xwj5yn2qjy	2025-03-10 13:27:12+00	\N	pop
3654	37	2OyestNLBmdbsQJaL9qaVG	\N	Where Have You Been	REESE	1qzcdqlwqtm8lnthmvh2a70p9	2025-03-06 16:30:03+00	\N	bassline, uk garage, bass house
3623	36	2S53xe3CB5RgDELKeU97g0	\N	Nazareth	Sleep Token	313neyxbfwxtbi2t52gjvliqxisa	2025-03-13 05:44:53+00	\N	progressive metal, metalcore
3657	37	2Uq8o3398JlRbWdpvObYii	\N	God Fearing Man	Imminence	313neyxbfwxtbi2t52gjvliqxisa	2025-03-06 23:16:56+00	\N	metalcore, metal
3662	38	2oaK4JLVnmRGIO9ytBE1bt	\N	Dark Necessities	Red Hot Chili Peppers	31pd6hnytykuevog22xwj5yn2qjy	2025-02-17 12:14:37+00	\N	funk rock, alternative rock, rock
3619	36	2rvd6akG8qEtBNUvQpN7iY	\N	How Bad Do U Want Me	Lady Gaga	31pd6hnytykuevog22xwj5yn2qjy	2025-03-12 12:42:29+00	\N	art pop, pop
3655	37	2wQVTVal8EySJgcE7LoPmH	\N	KILL4R TR4NING	FOVLA, YONKER DILLA	1qzcdqlwqtm8lnthmvh2a70p9	2025-03-06 16:30:03+00	\N	drift phonk
3633	36	38aJAzjCVhi2znvtg1zQZA	\N	Particles - Piano Version	Nothing But Thieves	1qzcdqlwqtm8lnthmvh2a70p9	2025-03-13 12:11:22+00	\N	alternative rock
3606	35	3bT6kD1TdSM9tXrf0uyxts	\N	VKTM	SICKOTOY, INNA, The Anti Group	31pd6hnytykuevog22xwj5yn2qjy	2025-03-21 10:28:42+00	\N	house
3652	37	3nO25qbjlOkVLd2vVPctBE	\N	Вплотную	БАЗАР	1qzcdqlwqtm8lnthmvh2a70p9	2025-03-06 16:30:03+00	\N	hip hop
3626	36	3xydy4pWx6N2qxTpL0mW3l	\N	THE BACKROOM	SEVER THE DAY, Obzene	313neyxbfwxtbi2t52gjvliqxisa	2025-03-13 10:26:30+00	\N	alternative rock
3646	37	3o7TMr6RmIusYH7Kkg7ujR	\N	Coming Undone	Korn	313neyxbfwxtbi2t52gjvliqxisa	2025-03-04 13:55:08+00	\N	nu metal, metal, rap metal, alternative metal
3640	37	4EXFMcskUoIg3mwfSCanH0	\N	Old Habits	MID CITY	31ghi62vkgnlb4wqr6muaisx7ldi	2025-03-01 04:13:05+00	\N	indie
3642	37	48RuUiK70EkPPz6xTb7q03	\N	Sleepwalker	The Killers	31pd6hnytykuevog22xwj5yn2qjy	2025-03-02 07:36:30+00	\N	alternative rock
3620	36	5AGQSF0ytihJyt96K5vW9d	\N	Heartbeat	Childish Gambino	31pd6hnytykuevog22xwj5yn2qjy	2025-03-12 14:29:03+00	\N	r&b
3617	36	4P4YHtpE4OlhlaCjJovNoW	\N	TIME MACHINE	Dreams Shadow	31ghi62vkgnlb4wqr6muaisx7ldi	2025-03-11 10:29:56+00	\N	electro swing, swing music
3658	37	4UqKJx2oFJvgLIBrBV82Ou	\N	Sfiorivano le viole	Rino Gaetano	31pd6hnytykuevog22xwj5yn2qjy	2025-03-07 10:34:10+00	\N	italian singer-songwriter, singer-songwriter
3610	36	4pdLZsxq0y5oJDb6Cxlokw	\N	You Got Me	The Roots, Tariq Trotter, Erykah Badu, Eve	31pd6hnytykuevog22xwj5yn2qjy	2025-03-11 08:46:34+00	\N	east coast hip hop, jazz rap, hip hop
3656	37	4tT2Xr3vZLvfrXFrGVjaBi	\N	Round & Round (Remix) - Squid Game Afro House	Impani, LU2VYK	1qzcdqlwqtm8lnthmvh2a70p9	2025-03-06 16:30:03+00	\N	afro house
3650	37	5113cmRZTLSxc2343gbsz8	\N	American Woman	The Guess Who	1qzcdqlwqtm8lnthmvh2a70p9	2025-03-06 16:30:03+00	\N	classic rock
3612	36	54t8CUKlQTRJsKDKuXxl6o	\N	паттерн	ста2тика	31ghi62vkgnlb4wqr6muaisx7ldi	2025-03-11 10:13:34+00	\N	experimental hip hop
3614	36	6BIp0f6BpNVUuP2Eemocz6	\N	Snow, Lights	flora cash	31ghi62vkgnlb4wqr6muaisx7ldi	2025-03-11 10:16:44+00	\N	indie
3661	38	5JZdu2fK7qvJgg0DfVmJe5	\N	All In One Night	Stereophonics	31pd6hnytykuevog22xwj5yn2qjy	2025-02-17 12:12:57+00	\N	britpop
3636	36	5NRpxJxtR6JkUhQS4F0um6	\N	Emergence	Sleep Token	1qzcdqlwqtm8lnthmvh2a70p9	2025-03-13 12:14:25+00	\N	progressive metal, metalcore
3639	37	5dUJxCMhKoK9yRWgqnDBV9	\N	Garage	Frizzy P & Mr Cole	31ghi62vkgnlb4wqr6muaisx7ldi	2025-03-01 04:12:49+00	\N	jazz rap
3627	36	6D65DMzIaFxFYYdliXx1Js	\N	Run Rabbit	ALT BLK ERA	31ghi62vkgnlb4wqr6muaisx7ldi	2025-03-13 11:38:40+00	\N	alternative rock
3648	37	6aVcbdwsT3JRqJ03We9v9P	\N	Москва	Аффинаж	313neyxbfwxtbi2t52gjvliqxisa	2025-03-04 14:41:10+00	\N	folk
3628	36	6RmHv8x9vcHnuFKhfyRjEC	\N	Lovers	Isaac Hong	1qzcdqlwqtm8lnthmvh2a70p9	2025-03-13 12:11:22+00	\N	k-ballad, soundtrack
3641	37	7DooSQQXeaZRKqNx5FgB17	\N	Waiter	MOSES	31ghi62vkgnlb4wqr6muaisx7ldi	2025-03-01 04:14:17+00	\N	r&b
3604	35	6eLSYGoJhXsR6ZhQEtTC3o	\N	Pain	De La Soul, Snoop Dogg	31pd6hnytykuevog22xwj5yn2qjy	2025-03-21 10:10:52+00	\N	jazz rap, east coast hip hop
3635	36	6xe6ZGFgMGbEjU6Q3lxeHZ	\N	Alone	Eptic, Habstrakt	1qzcdqlwqtm8lnthmvh2a70p9	2025-03-13 12:11:22+00	\N	dubstep, riddim, deathstep, bass music, bass house, dub
3645	37	74tLlkN3rgVzRqQJgPfink	\N	Money Trees	Kendrick Lamar, Jay Rock	31pd6hnytykuevog22xwj5yn2qjy	2025-03-04 09:46:38+00	\N	hip hop, west coast hip hop
3607	36	7cFgBkv95E8OdKEzU2imAI	\N	Хоррор	UBEL	313neyxbfwxtbi2t52gjvliqxisa	2025-03-10 04:08:35+00	\N	metal
3609	36	7KwZNVEaqikRSBSpyhXK2j	\N	Hypnotize - 2014 Remaster	The Notorious B.I.G.	31pd6hnytykuevog22xwj5yn2qjy	2025-03-10 13:27:25+00	\N	old school hip hop, gangster rap, east coast hip hop, hip hop
3663	38	7fJFDK6XjYsXcMKNHESbot	\N	Fun (feat. Tove Lo)	Coldplay	31pd6hnytykuevog22xwj5yn2qjy	2025-02-17 12:15:39+00	\N	pop
3644	37	7oMxnvhZ3TQq58f1lqBI21	\N	ACT A FOOL	KXNVRA	31pd6hnytykuevog22xwj5yn2qjy	2025-03-04 09:41:28+00	\N	phonk, drift phonk
3611	36	0b4RF27x5RiKT2VfNTxr4V	\N	кричу	синдром главного героя	31ghi62vkgnlb4wqr6muaisx7ldi	2025-03-11 10:11:34+00	\N	emo
3673	38	0ADZiovpy5y3kFeJ25ULBA	\N	Dreamcore.mp3	Burned Time Machine	1qzcdqlwqtm8lnthmvh2a70p9	2025-02-27 21:36:57+00	\N	downtempo
3719	40	0IX7TLYptAPkJscwmeyBhT	\N	привет	iskrit, ioneweb, BORIS REDWALL	31ghi62vkgnlb4wqr6muaisx7ldi	2025-02-07 11:01:39+00	\N	electronic
3710	39	0Syxj1ZtWoLcceQIkthFl5	\N	Провода	passmurny	31ghi62vkgnlb4wqr6muaisx7ldi	2025-02-14 11:15:53+00	\N	indie
3707	39	0cgyeBU54kjmI54TflMANg	\N	Neon Pill	Cage The Elephant	31ghi62vkgnlb4wqr6muaisx7ldi	2025-02-14 11:14:42+00	\N	alternative rock
3671	38	0b24ULrwGJgAVkt60fHSKi	\N	Frozen	Kastuvas	1qzcdqlwqtm8lnthmvh2a70p9	2025-02-27 21:35:06+00	\N	slap house, drum and bass
3702	39	0ccoGCaOFCxI6pHixrQpKj	\N	Neverender	Justice, Tame Impala	1qzcdqlwqtm8lnthmvh2a70p9	2025-02-14 08:53:31+00	\N	french house, new rave
3670	38	0dgdDB39uUoC8WICmTE2U8	\N	No Bad Vibes	Jazzy, KILIMANJARO	31pd6hnytykuevog22xwj5yn2qjy	2025-02-26 14:22:15+00	\N	electronic
3674	38	0j6P0PbBapl1FxRytFlfy0	\N	До утра	Dequine	1qzcdqlwqtm8lnthmvh2a70p9	2025-02-27 21:36:57+00	\N	pop
3717	40	16EAgNahcnXNE3VEoMWJUG	\N	ДУРАКИ	UBEL, Antoha MC	31ghi62vkgnlb4wqr6muaisx7ldi	2025-02-07 11:01:16+00	\N	rap
3667	38	171FM79pYmoIKC1icV34IG	\N	fade	Holywatr	313neyxbfwxtbi2t52gjvliqxisa	2025-02-18 12:58:33+00	\N	electronic
3675	38	19nAFg6Mb6jXN3yxPC2sSk	\N	Superman	Lazlo Bane	1qzcdqlwqtm8lnthmvh2a70p9	2025-02-27 21:37:14+00	\N	rock
3691	39	16tvIGzCNfRLVbm8G39DDo	\N	The Seed	AURORA	31pd6hnytykuevog22xwj5yn2qjy	2025-02-11 10:48:45+00	\N	norwegian pop, art pop
3715	40	1JSTJqkT5qHq8MDJnJbRE1	\N	Every Breath You Take	The Police	31433d6i5sfekboj5hr2fjtnwe7u	2025-02-06 05:30:17+00	\N	rock
3664	38	20TYc2OwFNxPVFRT2LYmZH	\N	In the Shadows	Foreign Air	31pd6hnytykuevog22xwj5yn2qjy	2025-02-17 12:16:27+00	\N	rock
3700	39	2IBPiQ52UsI2lYW53voP2L	\N	Долетай	Katya Lel	1qzcdqlwqtm8lnthmvh2a70p9	2025-02-14 08:53:31+00	\N	pop
3695	39	1lXAzSbRH4VXrqgFuPQSFp	\N	The Offering	Sleep Token	313neyxbfwxtbi2t52gjvliqxisa	2025-02-12 23:30:24+00	\N	progressive metal, metalcore
3684	38	2xhGZ3WzOa3tir28y7Cb88	\N	Falling for U	Peachy!, mxmtoon	31ghi62vkgnlb4wqr6muaisx7ldi	2025-02-28 08:28:13+00	\N	indie
3689	39	2DtPEKs3Pj7E06EoWW4vw8	\N	Carnival of Rust	Poets of the Fall	31pd6hnytykuevog22xwj5yn2qjy	2025-02-11 09:57:51+00	\N	finnish rock
3687	39	3RuXX9CwnyoqMvTRvUA2RT	\N	Snuff the Pilot Light	Samy Sharif	31pd6hnytykuevog22xwj5yn2qjy	2025-02-10 21:01:00+00	\N	alternative rock
3697	39	2S9jqUEI9fiDNtSH707KR4	\N	So Good	Nosi	313neyxbfwxtbi2t52gjvliqxisa	2025-02-14 00:46:31+00	\N	stutter house
3669	38	3UrP8yrUa3jovvJ4OasVb7	\N	Успокой	Drummatix	31pd6hnytykuevog22xwj5yn2qjy	2025-02-19 14:02:34+00	\N	electronic
3672	38	3DdPuaXAXkZdSz63LWBQ1K	\N	Break My Heart - Rameses B Remix	Slushii, sapientdream, Rameses B	1qzcdqlwqtm8lnthmvh2a70p9	2025-02-27 21:35:12+00	\N	future bass
3676	38	3reMiUmF2Y34NlEFrXio4r	\N	Retribution	NEFFEX	1qzcdqlwqtm8lnthmvh2a70p9	2025-02-27 21:37:31+00	\N	metal
3696	39	3wb37UgM4P9zT8ZVbzEHa5	\N	Каплями	Yulia Savicheva, TRITIA	313neyxbfwxtbi2t52gjvliqxisa	2025-02-13 23:29:20+00	\N	pop
3685	39	3qVKp0bGG2uEkrkMOtwb5F	\N	Fitzpleasure	alt-J	31pd6hnytykuevog22xwj5yn2qjy	2025-02-10 09:56:37+00	\N	indie, indie rock
3725	40	41hRWgoaw67f4VGMbNSfoZ	\N	Врубай	Parfeniuk	1qzcdqlwqtm8lnthmvh2a70p9	2025-02-07 11:16:25+00	\N	electronic
3720	40	4Tyb1yqPkrVI5hyudVc0QW	\N	Lost	Santé Rose	31ghi62vkgnlb4wqr6muaisx7ldi	2025-02-07 11:01:47+00	\N	pop
3693	39	3wnNwuoNTLWXRKfBdTeRLs	\N	Perfect Soul	Spiritbox	31pd6hnytykuevog22xwj5yn2qjy	2025-02-12 14:42:18+00	\N	metalcore, djent, metal
3706	39	4n82AVSg6y0mSPw9PY06Gf	\N	In The Air Tonight	State of Mine	313neyxbfwxtbi2t52gjvliqxisa	2025-02-14 11:04:00+00	\N	rock
3712	40	43ToXUJ7CA3Dk6HjauOR4h	\N	Feel It Too (It's Too Much)	Scrim	31433d6i5sfekboj5hr2fjtnwe7u	2025-02-02 06:25:31+00	\N	emo rap, horrorcore
3721	40	526fD9LiAEi3KKvhhYfWmm	\N	What You Wanna Try	Masego	31ghi62vkgnlb4wqr6muaisx7ldi	2025-02-07 11:05:50+00	\N	r&b
3686	39	4mRSbPLnOm54ttkTYvxxSY	\N	Decks Dark	Radiohead	31pd6hnytykuevog22xwj5yn2qjy	2025-02-10 13:08:51+00	\N	art rock, alternative rock
3680	38	5KzoodusN0DdVeZs8W21pl	\N	No Surrender	MID CITY	31ghi62vkgnlb4wqr6muaisx7ldi	2025-02-28 08:22:58+00	\N	emo
3678	38	4qVR3CF8FuFvHN4L6vXlB1	\N	Lying from You	Linkin Park	313neyxbfwxtbi2t52gjvliqxisa	2025-02-27 23:34:38+00	\N	nu metal, rap metal, rock, alternative metal
3681	38	5b2lmp4CIsmfTMVZsoNaG4	\N	Just Repeating What's Around Me	James Supercave	31ghi62vkgnlb4wqr6muaisx7ldi	2025-02-28 08:23:32+00	\N	indie
3713	40	5KMiLXEmchWGZRMe1OO4PN	\N	Selbstverliebt & Arrogant	Rosc	31pd6hnytykuevog22xwj5yn2qjy	2025-02-03 23:13:09+00	\N	german hip hop
3665	38	5uuPDgZe2xlN5UN4sUQyAc	\N	Sleepyhead	Jutes	31pd6hnytykuevog22xwj5yn2qjy	2025-02-17 22:05:03+00	\N	indie
3704	39	6GuVLubDfYlFVc1YKWmEVR	\N	Espionage	Rainbow Kitten Surprise	1qzcdqlwqtm8lnthmvh2a70p9	2025-02-14 08:53:31+00	\N	indie
3699	39	6UnOxNp0jZfFXyKcAtJwUj	\N	Masquerade	Stellar	1qzcdqlwqtm8lnthmvh2a70p9	2025-02-14 08:53:31+00	\N	pop
3716	40	6ZHRi0QxzSnlevyhyNkj4a	\N	Sweat	ZAYN	31pd6hnytykuevog22xwj5yn2qjy	2025-02-06 14:12:15+00	\N	pop
3703	39	6m94NnMDxM5KM5Ut5vgfhR	\N	Made For Me	Muni Long	1qzcdqlwqtm8lnthmvh2a70p9	2025-02-14 08:53:31+00	\N	r&b
3679	38	6oxfnbwSvVvl8FhqojHfd5	\N	DARK THINGS	STARSET	313neyxbfwxtbi2t52gjvliqxisa	2025-02-27 23:50:25+00	\N	metal
3683	38	75GhyGaBPZnFnCHIYo3mvQ	\N	You Will Never Know It	Carpetman	31ghi62vkgnlb4wqr6muaisx7ldi	2025-02-28 08:28:03+00	\N	indie
3688	39	76b8kLnhKDoSWJbCyMXIBi	\N	Perfect Man	Gio	31pd6hnytykuevog22xwj5yn2qjy	2025-02-10 21:02:59+00	\N	pop
3677	38	6yerffT19n4aHyY25Rnkfq	\N	Bratva	Slaughter to Prevail	313neyxbfwxtbi2t52gjvliqxisa	2025-02-27 23:33:23+00	\N	deathcore, metal, death metal, metalcore
3714	40	71p2ub5QJhJTzfvXbXaUXd	\N	High No More	Hajaj	31pd6hnytykuevog22xwj5yn2qjy	2025-02-05 09:16:19+00	\N	retro soul
3709	39	7LwLxil5ucG4qXcsxrkWEn	\N	Adored	LAUREL	31ghi62vkgnlb4wqr6muaisx7ldi	2025-02-14 11:15:33+00	\N	indie
3692	39	7GDqw5IBzAiu9zV7paGLnT	\N	I Believe	Killswitch Engage	313neyxbfwxtbi2t52gjvliqxisa	2025-02-11 11:36:23+00	\N	metalcore, metal
3722	40	7q1z5PFOlyR3p56y1pXeMG	\N	Jezebel	Recoil	31ghi62vkgnlb4wqr6muaisx7ldi	2025-02-07 11:08:08+00	\N	trip hop, ebm
3711	39	7rpoKoTczMF1Uv94pCszRb	\N	Понедельник	Dreams Shadow	31ghi62vkgnlb4wqr6muaisx7ldi	2025-02-14 11:24:43+00	\N	electro swing, swing music
3705	39	08eRMOVak3INPGvdM5PJOS	\N	полюбить с разбега	baur karbon	1qzcdqlwqtm8lnthmvh2a70p9	2025-02-14 08:53:31+00	\N	pop
3779	42	0cczJAXn3CrMKmJ48Wz8pW	\N	Красивые слова	Динамит	313neyxbfwxtbi2t52gjvliqxisa	2025-01-24 07:12:03+00	\N	pop
3739	41	0JVKPoqpx4Clhhb3Sa2Co2	\N	Let Me Know	Freaks & Geeks, Veronica Bravo	31pd6hnytykuevog22xwj5yn2qjy	2025-01-29 14:04:01+00	\N	drum and bass, liquid funk
3750	41	0LTwdL5yZ6YOTEGUQPFuSN	\N	ROSONES	Tito Double P	1qzcdqlwqtm8lnthmvh2a70p9	2025-01-31 08:33:06+00	\N	corrido, corridos tumbados, corridos bélicos, electro corridos, sierreño, dembow belico, música mexicana
3765	42	17CWWoszMuoGecCJzmOubE	\N	J CHRIST	Lil Nas X	31pd6hnytykuevog22xwj5yn2qjy	2024-12-23 12:04:30+00	\N	rap
3751	41	1SRg5WImDS1LbjbWR24Ln4	\N	Monsters	Nova Twins	1qzcdqlwqtm8lnthmvh2a70p9	2025-01-31 08:33:06+00	\N	metal
3778	42	0qZ03ABKZsGbGhvh1zbbil	\N	Sun Killer	Spiritbox	313neyxbfwxtbi2t52gjvliqxisa	2025-01-24 07:11:19+00	\N	metalcore, djent, metal
3768	42	10ASBwZsp7oUUDsJEYz3uS	\N	Dance With The Devil	Breaking Benjamin	31pd6hnytykuevog22xwj5yn2qjy	2025-01-01 13:46:05+00	\N	alternative metal, post-grunge, rock
3777	42	13QtB6wmo1Y54gf1jW8uqw	\N	Не умоляй	At The Ruins	313neyxbfwxtbi2t52gjvliqxisa	2025-01-24 07:11:04+00	\N	metalcore
3755	41	2d8YezEcud9RugJToac8n5	\N	Woke up Late	Geoffroy	31ghi62vkgnlb4wqr6muaisx7ldi	2025-01-31 11:34:57+00	\N	indie
3754	41	1CTerGAfnw0KyowY4wcFgf	\N	The Initial High	Twisted Insane	1qzcdqlwqtm8lnthmvh2a70p9	2025-01-31 08:33:06+00	\N	horrorcore
3771	42	3RzYbj6Rr6mSJCar4Ua86F	\N	I Don't Care	VIOLENT VIRA	1qzcdqlwqtm8lnthmvh2a70p9	2025-01-11 16:35:30+00	\N	pop
3767	42	1WYEDcS7WGjv0rG7rmMX3o	\N	Bitter Sweet Symphony	The Verve	31433d6i5sfekboj5hr2fjtnwe7u	2024-12-25 11:38:13+00	\N	britpop, shoegaze
3729	40	1qTbKDhFTM4am7zAXk2jsp	\N	Fire In The Sky	Jimmy Clash, Robbie Rosen, Kill The Buzz	1qzcdqlwqtm8lnthmvh2a70p9	2025-02-07 11:16:25+00	\N	big room
3733	40	2E3AjDjfiXJgK8xbjIA2QO	\N	Карфаген	Мегамозг, Pasha Technique	313neyxbfwxtbi2t52gjvliqxisa	2025-02-07 11:44:51+00	\N	nu metal
3776	42	2X9xNcQnRPNLa9fUvl218u	\N	River Of Sorrows	Paleface Swiss	313neyxbfwxtbi2t52gjvliqxisa	2025-01-24 07:10:34+00	\N	deathcore, metalcore, metal
3745	41	3l9p9hK2YheDUJgycBA1h8	\N	Румба	Огней Ночных	313neyxbfwxtbi2t52gjvliqxisa	2025-01-30 23:47:57+00	\N	latin
3760	42	2gDqG1o9jKU4owbkNeyNHt	\N	Cross	lagosta	31433d6i5sfekboj5hr2fjtnwe7u	2024-12-19 08:35:48+00	\N	emo rap
3781	42	2qcXDpEzi89CMgxPXAiiI8	\N	Blackhole	Architects	313neyxbfwxtbi2t52gjvliqxisa	2025-01-24 07:12:14+00	\N	metalcore, djent, metal, mathcore, post-hardcore, deathcore
3738	41	2ta1uHvZMY7yG8xms7VTr3	\N	To The Sky	[IVY]	31pd6hnytykuevog22xwj5yn2qjy	2025-01-29 14:02:53+00	\N	drum and bass
3741	41	3HPPcZ9oK7yGmy5vn7OMLC	\N	Hammer	Dirtyphonics, Sullivan King	31pd6hnytykuevog22xwj5yn2qjy	2025-01-29 14:36:04+00	\N	dubstep, deathstep, riddim, drumstep, drum and bass, bass music
3749	41	4WBPFtI9ZNTlLZRXTVySJb	\N	With You	Sigala, Ely Oaks	1qzcdqlwqtm8lnthmvh2a70p9	2025-01-31 08:33:06+00	\N	electronic
3728	40	4iBdVlW8FbzvNYmryWZaOr	\N	Облака	CREAM SODA	1qzcdqlwqtm8lnthmvh2a70p9	2025-02-07 11:16:25+00	\N	pop
3737	41	4kreL49xOapJRVTKl2OcmQ	\N	Cambio Dolor	Natalia Oreiro	31pd6hnytykuevog22xwj5yn2qjy	2025-01-29 14:02:07+00	\N	latin
3762	42	4ztdjZ2t7BVo5DLIFQBdJh	\N	Jericho	Iniko	31pd6hnytykuevog22xwj5yn2qjy	2024-12-20 11:03:48+00	\N	pop
3732	40	4iVnfuAmwJNAGsiHz8Po6Y	\N	Femme Like U	K.Maro	313neyxbfwxtbi2t52gjvliqxisa	2025-02-07 11:44:41+00	\N	french r&b
3784	42	5K5flNNiJnOWJbQY5XCDfx	\N	Криминал	Гости Гаррисона	31ghi62vkgnlb4wqr6muaisx7ldi	2025-01-24 11:17:59+00	\N	rock
3772	42	4tSBgZd6G68rpkC6iDXkeH	\N	Ignorance	Paramore	1qzcdqlwqtm8lnthmvh2a70p9	2025-01-11 16:35:57+00	\N	pop punk, emo
3746	41	5NmHEnQI23be8KwaK39EcR	\N	Горящий человек	Ink.visitor	313neyxbfwxtbi2t52gjvliqxisa	2025-01-30 23:49:54+00	\N	rock
3764	42	53c4gcV0FBKxo9HHAxrK9s	\N	Cliche	Fish	31pd6hnytykuevog22xwj5yn2qjy	2024-12-23 12:02:44+00	\N	progressive rock, art rock
3761	42	5txWBmYDYOXulUabyQvsU3	\N	Can't Get You out Of My Head	Glimmer of Blooms	31433d6i5sfekboj5hr2fjtnwe7u	2024-12-19 16:17:26+00	\N	pop
3782	42	6DRZmJa38MaMNthwG3fCBD	\N	two	bbno$	1qzcdqlwqtm8lnthmvh2a70p9	2025-01-24 10:17:11+00	\N	rap
3730	40	5mGmBf08TFaRZlobhpJM2O	\N	YOU ARE MY STAR	Sublab	1qzcdqlwqtm8lnthmvh2a70p9	2025-02-07 11:16:25+00	\N	chillstep, witch house
3756	41	6nX78hJTi7Lw7ZnwbvYos3	\N	Cigarette Lighter	Mellah	31ghi62vkgnlb4wqr6muaisx7ldi	2025-01-31 11:35:11+00	\N	indie
3759	42	6BD9XMxKnjL6dCJbxXAPUa	\N	Not Strong Enough	Apocalyptica, Brent Smith	31pd6hnytykuevog22xwj5yn2qjy	2024-12-19 12:51:40+00	\N	symphonic metal
3787	42	6pTp4Q32NjhIrzrhIpOzDI	\N	Talking To Myself	Declan Welsh and The Decadent West	31ghi62vkgnlb4wqr6muaisx7ldi	2025-01-24 11:24:05+00	\N	indie
3727	40	6Ilomcr9iLplsgAvZjHkJP	\N	Location	Zerb, Ty Dolla $ign, Wiz Khalifa	1qzcdqlwqtm8lnthmvh2a70p9	2025-02-07 11:16:25+00	\N	afro house
3770	42	6UTUFQdLHBHKpvKDGqFwMq	\N	LEAVE IT ALL BEHIND	Alex LeMirage	31pd6hnytykuevog22xwj5yn2qjy	2024-12-31 01:22:19+00	\N	stutter house
3731	40	6hZkQjIQBY7HAj4nzLUvdx	\N	All These Things I Hate (Revolve Around Me)	Bullet For My Valentine	313neyxbfwxtbi2t52gjvliqxisa	2025-02-07 11:44:34+00	\N	metalcore, metal
3748	41	6vPvVnU1u8lHdj0AhlnxDB	\N	Даже если	Егор Сесарев	313neyxbfwxtbi2t52gjvliqxisa	2025-01-30 23:52:55+00	\N	pop
3740	41	6xBifM893zgSssatuI6YAf	\N	неболей	Basta, Zivert	31pd6hnytykuevog22xwj5yn2qjy	2025-01-29 14:26:27+00	\N	pop
3747	41	78dFakBfd6hq9t2o7HHi36	\N	Тени	Плавица	313neyxbfwxtbi2t52gjvliqxisa	2025-01-30 23:50:35+00	\N	indie
3753	41	7br5do4xaJZQtvGo7TICkG	\N	my lawyer said don't	VALORANT, 8AE	1qzcdqlwqtm8lnthmvh2a70p9	2025-01-31 08:33:06+00	\N	electronic
3766	42	75sGNpidmjIEHDaILUPhjZ	\N	No Sleep	Morandi, Eneli	31pd6hnytykuevog22xwj5yn2qjy	2024-12-23 12:07:28+00	\N	europop
3774	42	7chkzLIvIBSEfIsb8J7jS5	\N	To the Moon	Brennan Savage, Nedarb	31433d6i5sfekboj5hr2fjtnwe7u	2025-01-17 15:50:19+00	\N	emo rap, cloud rap
3780	42	7f6X7zERAXAbIYVLizIZ3O	\N	ANTI-SOCIAL	While She Sleeps	313neyxbfwxtbi2t52gjvliqxisa	2025-01-24 07:12:10+00	\N	metalcore, metal, post-hardcore
3758	42	7tpXSkOY0R38GsUg0xk1fX	\N	Rosaries and Requiems	Anders Manga	31pd6hnytykuevog22xwj5yn2qjy	2024-12-18 10:16:22+00	\N	darkwave, gothic rock, deathrock, cold wave, ebm, post-punk, industrial
3785	42	7yc7XqMqoJZe28MfPqDjVg	\N	0 GRAVITY	Zior Park	31ghi62vkgnlb4wqr6muaisx7ldi	2025-01-24 11:18:38+00	\N	k-rap
3775	42	0IhCSFHlwQNeEei241BH1J	\N	Sun Showers	Phillip Berry, Drama B	313neyxbfwxtbi2t52gjvliqxisa	2025-01-24 07:09:56+00	\N	r&b
3810	43	03pWkKJjo8ATe0z4SWGzyd	\N	A Narnia Lullaby	Harry Gregson-Williams	31ghi62vkgnlb4wqr6muaisx7ldi	2025-01-11 17:18:58+00	\N	soundtrack, score
3797	43	05UMQXFCsa9oPnLgfJHVyF	\N	Ezio's Family	Jesper Kyd, Assassin's Creed	31pd6hnytykuevog22xwj5yn2qjy	2024-12-18 10:21:36+00	\N	soundtrack
3840	43	1efFDQ8J671FyCHvtgzSfr	\N	Палишь	NOVRUNYA	313neyxbfwxtbi2t52gjvliqxisa	2025-10-20 02:08:56+00	\N	rap
3799	43	1HNE2PX70ztbEl6MLxrpNL	\N	In Too Deep	Sum 41	31pd6hnytykuevog22xwj5yn2qjy	2024-12-22 10:04:49+00	\N	pop punk, punk, skate punk
3796	43	1HXchhExSIsJODlUyAXPlB	\N	Pirates Of The Caribbean - Main Theme - He's A Pirate	Geek Music	31pd6hnytykuevog22xwj5yn2qjy	2024-12-18 10:19:09+00	\N	anime
3826	43	28UMEtwyUUy5u0UWOVHwiI	\N	I'll Make a Man Out of You	Donny Osmond, Chorus - Mulan, Disney	1qzcdqlwqtm8lnthmvh2a70p9	2025-01-12 08:47:09+00	\N	soundtrack
3820	43	1elGwF4VwkwglV4nCBPJtv	\N	Now We Are Free	Hans Zimmer, Klaus Badelt, Lisa Gerrard, Gavin Greenaway, The Lyndhurst Orchestra	1qzcdqlwqtm8lnthmvh2a70p9	2025-01-12 08:47:09+00	\N	soundtrack, score
3823	43	1fvRueeK5f60hkG1VzoXXq	\N	Victor's Piano Solo	Danny Elfman	1qzcdqlwqtm8lnthmvh2a70p9	2025-01-12 08:47:09+00	\N	soundtrack, score
3814	43	20rmtxljOGVz4T3nSrtAV1	\N	Elysium	Klaus Badelt, Lisa Gerrard, Gavin Greenaway, The Lyndhurst Orchestra	31ghi62vkgnlb4wqr6muaisx7ldi	2025-01-11 17:19:08+00	\N	soundtrack
3791	43	2CgxZd3yImoYLHz71zFNAK	\N	I'll Keep Coming	Low Roar	31pd6hnytykuevog22xwj5yn2qjy	2024-12-18 10:00:25+00	\N	indie
3804	43	29U7stRjqHU6rMiS8BfaI9	\N	What A Wonderful World	Louis Armstrong	31433d6i5sfekboj5hr2fjtnwe7u	2025-01-11 08:02:15+00	\N	jazz, swing music, vocal jazz, big band
3807	43	2stkLJ0JNcXkIRDNF3ld6c	\N	You've Got a Friend in Me	Randy Newman	31433d6i5sfekboj5hr2fjtnwe7u	2025-01-11 08:14:43+00	\N	soundtrack
3813	43	2gaZJDgE71VL9PzzUUlpMg	\N	Dragonborn	Jeremy Soule	31ghi62vkgnlb4wqr6muaisx7ldi	2025-01-11 17:19:05+00	\N	medieval, soundtrack
3806	43	3pRaLNL3b8x5uBOcsgvdqM	\N	Hallelujah	Jeff Buckley	31433d6i5sfekboj5hr2fjtnwe7u	2025-01-11 08:10:32+00	\N	rock
3821	43	2wQN8tMYOHStr6Q61jh0IK	\N	...To Die For	Hans Zimmer	1qzcdqlwqtm8lnthmvh2a70p9	2025-01-12 08:47:09+00	\N	soundtrack, score
3822	43	330sOXv9tw1NmSgsIKPHbM	\N	Песенка Атаманши (Из м/ф «Бременские музыканты»)	Oleg Anofriyev, Anatoli Gorokhov, Оркестр п/у Г. Гладкова	1qzcdqlwqtm8lnthmvh2a70p9	2025-01-12 08:47:09+00	\N	children's music
3793	43	3OCS075lQnGG3gOUI0bava	\N	Find Yourself	Brad Paisley	31pd6hnytykuevog22xwj5yn2qjy	2024-12-18 10:03:48+00	\N	country
3815	43	3R558vzNPUNRHHlmu5FFBD	\N	Hanezeve Caradhina	Kevin Penkin, Takeshi Saito	31ghi62vkgnlb4wqr6muaisx7ldi	2025-01-11 17:19:11+00	\N	anime, soundtrack
3818	43	3ZVOIu02drSOsMf6gLE31J	\N	Can't Hardly Stand It	Charlie Feathers	31ghi62vkgnlb4wqr6muaisx7ldi	2025-01-11 17:19:18+00	\N	rockabilly, psychobilly
3830	43	3lPr8ghNDBLc2uZovNyLs9	\N	Supermassive Black Hole	Muse	313neyxbfwxtbi2t52gjvliqxisa	2025-01-15 22:54:00+00	\N	alternative rock, rock
3803	43	4bAFo6r2ODMDoqM5YHV2gM	\N	I Like To Move It	will.i.am	31433d6i5sfekboj5hr2fjtnwe7u	2025-01-11 07:59:01+00	\N	house
3836	43	46tSt69Xw10Ej8Rn7wJmFt	\N	I Disappear	Metallica	313neyxbfwxtbi2t52gjvliqxisa	2025-01-16 10:47:35+00	\N	metal, thrash metal, rock, heavy metal, hard rock
3819	43	4qykSxCPj7dmhY3OHbf9L6	\N	Funnel Of Love	SQÜRL, Madeline Follin	31ghi62vkgnlb4wqr6muaisx7ldi	2025-01-11 17:19:20+00	\N	soundtrack
3831	43	4ymByZAPRqTlyJASAoJ921	\N	Bounce	Timbaland, Missy Elliott, Justin Timberlake, Dr. Dre	313neyxbfwxtbi2t52gjvliqxisa	2025-01-16 08:53:33+00	\N	hip hop
3802	43	4ulazbh06sz38sgFSYce32	\N	Голубой Вагон	Igor Belkin, Anna Belkin	31433d6i5sfekboj5hr2fjtnwe7u	2025-01-11 07:58:18+00	\N	children's music
3841	44	5RePVWy39tLpHH0WwXgBsK	\N	Rah Tah Tah	Tyler, The Creator	31pd6hnytykuevog22xwj5yn2qjy	2024-12-08 11:46:09+00	\N	hip hop
3812	43	587i4g5fwUDAdl5xTP7UtW	\N	Miserlou	Dick Dale & His Del-Tones	31ghi62vkgnlb4wqr6muaisx7ldi	2025-01-11 17:19:03+00	\N	surf rock, rockabilly
3798	43	5NmL2zxnlt9GiTB2TQbvFM	\N	8 Mile	Eminem	31pd6hnytykuevog22xwj5yn2qjy	2024-12-18 10:25:47+00	\N	rap, hip hop
3843	44	5j99dfS5X643RxuJdyizt3	\N	GEMINI	BLK ODYSSY, Jackie Giroux	31ghi62vkgnlb4wqr6muaisx7ldi	2024-12-08 17:52:12+00	\N	r&b
3809	43	5j3QqRGflS4o5jbsFSwKW1	\N	Six Days - Remix	DJ Shadow, Mos Def	31433d6i5sfekboj5hr2fjtnwe7u	2025-01-11 08:38:29+00	\N	trip hop, plunderphonics, downtempo
3805	43	60nZcImufyMA1MKQY3dcCH	\N	Happy - From "Despicable Me 2"	Pharrell Williams	31433d6i5sfekboj5hr2fjtnwe7u	2025-01-11 08:04:35+00	\N	pop
3789	42	6LyAwkJsHlW7RQ8S1cYAtM	\N	Overdue (with Travis Scott)	Metro Boomin, Travis Scott	1qzcdqlwqtm8lnthmvh2a70p9	2025-01-24 13:46:15+00	\N	hip hop
3832	43	6HSXNV0b4M4cLJ7ljgVVeh	\N	Knockin' On Heaven's Door	Bob Dylan	313neyxbfwxtbi2t52gjvliqxisa	2025-01-16 08:55:17+00	\N	folk rock, folk, singer-songwriter, roots rock
3833	43	6ctWstoouxCcvuTsd4cHNS	\N	Desire - Gryffin Remix	Olly Alexander (Years & Years), Gryffin	313neyxbfwxtbi2t52gjvliqxisa	2025-01-16 10:28:31+00	\N	future bass
3817	43	6PF9zGfeUjMFMADqzZ1JTI	\N	Que Sera Sera	Pixies	31ghi62vkgnlb4wqr6muaisx7ldi	2025-01-11 17:19:16+00	\N	alternative rock
3837	43	6Wx88Mv6b9ofjKMKkdwOJd	\N	New Divide	Linkin Park	313neyxbfwxtbi2t52gjvliqxisa	2025-01-16 11:57:17+00	\N	nu metal, rap metal, rock, alternative metal
3824	43	6rPZBAOiKUrb3rWqqlJ6zT	\N	Она одна...	Ранетки	1qzcdqlwqtm8lnthmvh2a70p9	2025-01-12 08:47:09+00	\N	pop
3801	43	6hs3SDnbO3f6VQuPO4KBEb	\N	Send Me on My Way	Rusted Root	31433d6i5sfekboj5hr2fjtnwe7u	2025-01-11 07:53:12+00	\N	jam band
3790	43	6pWgRkpqVfxnj3WuIcJ7WP	\N	Cornfield Chase	Hans Zimmer	31pd6hnytykuevog22xwj5yn2qjy	2024-12-18 09:54:50+00	\N	soundtrack, score
3842	44	7GZksoDm6EaRhtM2AO8FaN	\N	C'est Exquis	Walter Astral	31ghi62vkgnlb4wqr6muaisx7ldi	2024-12-08 17:50:18+00	\N	jazz
3795	43	6zW80jVqLtgSF1yCtGHiiD	\N	The Shire	Howard Shore	31pd6hnytykuevog22xwj5yn2qjy	2024-12-18 10:18:04+00	\N	soundtrack, score
3828	43	6zezOLouSWKEfMizbzcsad	\N	All Gone (No Escape)	Gustavo Santaolalla, Alan Umstead	1qzcdqlwqtm8lnthmvh2a70p9	2025-01-12 08:47:09+00	\N	soundtrack
3794	43	72Z28IsvEVLjSWdUKEQgZ0	\N	White Christmas	The Drifters	31pd6hnytykuevog22xwj5yn2qjy	2024-12-18 10:11:40+00	\N	doo-wop, motown
3838	43	7oTQ4d0UJeH8LOyvpfd5uW	\N	I’m So Sorry	Imagine Dragons	313neyxbfwxtbi2t52gjvliqxisa	2025-01-16 12:04:40+00	\N	rock
3835	43	7e61sMsW9ET6rMkhBaulQp	\N	Late Goodbye	Poets of the Fall	313neyxbfwxtbi2t52gjvliqxisa	2025-01-16 10:39:34+00	\N	finnish rock
3834	43	0K3nfJQSHbbrZNFA8ygKEQ	\N	Нежность	KREC	313neyxbfwxtbi2t52gjvliqxisa	2025-01-16 10:38:29+00	\N	rap
3896	46	0DbdwGmYsyax64LpniHfxV	\N	Love is Gonna Save Us	Benny Benassi, The Biz	31pd6hnytykuevog22xwj5yn2qjy	2024-11-20 09:27:36+00	\N	electro house
3876	45	0TwKov50GELgwuAW4I3oeN	\N	ALL MY LOVE - PNAU x Coldplay	Coldplay, PNAU	1qzcdqlwqtm8lnthmvh2a70p9	2024-12-08 06:20:47+00	\N	pop
3870	45	0Yy4En9vnGdAgMoGnCfB5W	\N	Let the Bells Ring	Wild Belle	31ghi62vkgnlb4wqr6muaisx7ldi	2024-12-07 16:00:35+00	\N	indie
3879	45	0jge40AXxEAOCa5qJHLwDH	\N	Ночной гость (Соседка)	Mikhail Shufutinsky	1qzcdqlwqtm8lnthmvh2a70p9	2024-12-08 06:21:01+00	\N	pop
3887	46	0qP4QTGEmlslzEWIqF5oNs	\N	Home	Mahalo, Swedish Red Elephant	31pd6hnytykuevog22xwj5yn2qjy	2024-11-13 11:25:38+00	\N	house
3878	45	1IFRVS4t1olI0XG9RBWdKH	\N	The Girl	City and Colour	1qzcdqlwqtm8lnthmvh2a70p9	2024-12-08 06:21:01+00	\N	indie
3875	45	0zTtemJw1mP4IF2Xczl2Br	\N	Apart	SLESS	1qzcdqlwqtm8lnthmvh2a70p9	2024-12-08 06:20:47+00	\N	drum and bass
3884	46	14wbsRn4dzYtLE4QVhI0qB	\N	Only You	Aperio, Leo Wood	313neyxbfwxtbi2t52gjvliqxisa	2024-11-04 02:25:20+00	\N	liquid funk, drum and bass
3868	45	1ErN6a5lgQXlNipBZmH6MF	\N	Venom	AKOV, Venjent	313neyxbfwxtbi2t52gjvliqxisa	2024-12-07 04:55:16+00	\N	drum and bass, drumstep
3897	46	1mEOxHlvU3zxIOLv2JrcqP	\N	Milk	Garbage	1qzcdqlwqtm8lnthmvh2a70p9	2024-11-24 06:36:37+00	\N	alternative rock
3859	45	1SUFXbwdv6PEpcKmaQEaqN	\N	Aladin	Alphadog	31pd6hnytykuevog22xwj5yn2qjy	2024-11-24 12:53:17+00	\N	melodic techno, indie dance, melodic house
3863	45	1i1VgyiM9ZiPBu8EoxhFw5	\N	Mayday	Three Days Grace	313neyxbfwxtbi2t52gjvliqxisa	2024-11-24 12:55:41+00	\N	post-grunge, rock
3877	45	1zweWaoKk2OrF3sNf09XMt	\N	SNOVA	Eldzhey, FEDUK, Biicla	1qzcdqlwqtm8lnthmvh2a70p9	2024-12-08 06:20:47+00	\N	hip hop
3846	44	21jGcNKet2qwijlDFuPiPb	\N	Circles	Post Malone	31433d6i5sfekboj5hr2fjtnwe7u	2024-12-14 10:45:42+00	\N	pop
3894	46	2d0K6DxRA8ppPUjGBFKZuE	\N	Падал снег	Igor Sarukhanov	31pd6hnytykuevog22xwj5yn2qjy	2024-11-18 10:12:54+00	\N	pop
3857	44	2FRnf9qhLbvw8fu4IBXx78	\N	Last Christmas	Wham!	1qzcdqlwqtm8lnthmvh2a70p9	2024-12-15 07:50:19+00	\N	christmas
3885	46	2QQPdD4KRl8qIgiSYz1U08	\N	Black Fingernails	Sowhatimdead	31433d6i5sfekboj5hr2fjtnwe7u	2024-11-05 01:25:03+00	\N	emo rap, cloud rap
3874	45	2VG8HBqZzKl7g11fXPUmYL	\N	Never Give Up On Me	Mary J. Blige	1qzcdqlwqtm8lnthmvh2a70p9	2024-12-08 06:20:35+00	\N	r&b
3889	46	2toVe5hfuIi97ytDPDbQFt	\N	Taste (feat. Offset)	Tyga, Offset	31pd6hnytykuevog22xwj5yn2qjy	2024-11-15 14:06:57+00	\N	hip hop
3862	45	2tS71jMHwyKFXhXaVrBRwJ	\N	Люби, пока есть время	Ермак!	313neyxbfwxtbi2t52gjvliqxisa	2024-11-24 12:55:19+00	\N	post-hardcore
3891	46	3nHuKdFJZm78CoeBnDcFKe	\N	Bad Dreams	Teddy Swims	31pd6hnytykuevog22xwj5yn2qjy	2024-11-16 12:15:58+00	\N	r&b
3849	44	3bg2qahpZmsg5wV2EMPXIk	\N	Forever Young	David Guetta, Alphaville, Ava Max	1qzcdqlwqtm8lnthmvh2a70p9	2024-12-15 07:29:34+00	\N	edm
3899	46	3mDIXJyQpfF370sLkNkjvf	\N	About You	Bancali	1qzcdqlwqtm8lnthmvh2a70p9	2024-11-24 06:52:41+00	\N	future house, big room
3893	46	3wqMCDKWWYHnPLldMskKHe	\N	Civilian	Wye Oak	31433d6i5sfekboj5hr2fjtnwe7u	2024-11-17 01:54:58+00	\N	indie
3865	45	3siwsiaEoU4Kuuc9WKMUy5	\N	No One Noticed	The Marías	31433d6i5sfekboj5hr2fjtnwe7u	2024-11-28 02:27:25+00	\N	bedroom pop
3852	44	47yp74QwH1ylYHj3KB3OBl	\N	Мы не увидимся никогда	Mirèle, BORIS REDWALL, ACID BOSS	1qzcdqlwqtm8lnthmvh2a70p9	2024-12-15 07:36:44+00	\N	electronic
3886	46	4LBkEsigdY1ojpMUXf9KXq	\N	Чина	Irina Kairatovna	31pd6hnytykuevog22xwj5yn2qjy	2024-11-13 21:19:18+00	\N	pop
3844	44	4AFqxUgTjluFRfjPLuoZ0a	\N	Nu Delhi	Bloodywood	313neyxbfwxtbi2t52gjvliqxisa	2024-12-10 12:30:38+00	\N	folk metal, metal
3864	45	4Q3N4Ct4zCuIHuZ65E3BD4	\N	Tunnel Vision	Kodak Black	31433d6i5sfekboj5hr2fjtnwe7u	2024-11-25 03:45:28+00	\N	rap
3861	45	4l554u04uMRS3HCfZcjVnm	\N	Ауткаст	Ауткаст	313neyxbfwxtbi2t52gjvliqxisa	2024-11-24 12:54:54+00	\N	rap
3856	44	54UwHm1Z6oa4XoEZ45A6WH	\N	Swim - Becky Hill x MK	Becky Hill, MK	1qzcdqlwqtm8lnthmvh2a70p9	2024-12-15 07:48:18+00	\N	house
3901	46	551Gm760iMCfEMjJvDeWbi	\N	Из этих стен	Louna	313neyxbfwxtbi2t52gjvliqxisa	2024-11-24 09:16:48+00	\N	rock
3905	47	589Vyp9ZXlM9HfgyqNPSx1	\N	Мир зеленого цвета	Leonid Agutin, JONY	313neyxbfwxtbi2t52gjvliqxisa	2024-10-20 10:38:30+00	\N	pop
3895	46	59B9JrIV9aZmdiCG1dQDTU	\N	вдыхать волны.	летяга	31pd6hnytykuevog22xwj5yn2qjy	2024-11-18 19:27:31+00	\N	indie
3866	45	5Z3GHaZ6ec9bsiI5BenrbY	\N	Young Dumb & Broke	Khalid	31433d6i5sfekboj5hr2fjtnwe7u	2024-11-30 16:13:30+00	\N	r&b
3880	45	5Axl2Rjg3wOC3JHju1Gess	\N	Freestyler (Rock The Microphone)	Lost Frequencies, Bomfunk MC's	1qzcdqlwqtm8lnthmvh2a70p9	2024-12-08 06:21:21+00	\N	tropical house
3858	45	5LbGC2dXsjgkYc1KBnYEF8	\N	FERHAT YILMAZ	Ben Fero	31pd6hnytykuevog22xwj5yn2qjy	2024-11-24 12:51:55+00	\N	turkish hip hop
3882	46	5Xh6302f050OXxVvSHiGW5	\N	Bring Me To Life	Venjent, Oktae	313neyxbfwxtbi2t52gjvliqxisa	2024-11-03 15:14:39+00	\N	drum and bass
3847	44	6Y6bYcQX70CTEoY571olvl	\N	Капалавада	ZOLOTO	1qzcdqlwqtm8lnthmvh2a70p9	2024-12-14 18:14:39+00	\N	electronic
3845	44	6SJbybzXWrVnBOjbr25Fus	\N	SpiderSilkRobes	BONES, Lyson	31pd6hnytykuevog22xwj5yn2qjy	2024-12-11 09:40:35+00	\N	cloud rap, emo rap, horrorcore, trap metal, underground hip hop
3904	47	6SXy02aTZU3ysoGUixYCz0	\N	Maybe Tomorrow	Stereophonics	313neyxbfwxtbi2t52gjvliqxisa	2024-10-20 10:38:26+00	\N	britpop
3860	45	6hCZqjIrd68aT1Ce9lpF8e	\N	Нежная Любовь	Beautiful Boys	31pd6hnytykuevog22xwj5yn2qjy	2024-11-26 16:00:43+00	\N	pop
3854	44	71VhNXBjrGRtHpMGbzBzFY	\N	no option	GRAHAM	1qzcdqlwqtm8lnthmvh2a70p9	2024-12-15 07:48:05+00	\N	indie
3853	44	7HMkTthlFcV104mKE5N1zO	\N	Reason - Bonobo Rework	Kanako Yamamoto, Bonobo	1qzcdqlwqtm8lnthmvh2a70p9	2024-12-15 07:46:26+00	\N	downtempo
3855	44	7Lmx8Vz0NRCZRcdHDpuRsn	\N	Stay Awake	VALORANT, Willim, HAOO	1qzcdqlwqtm8lnthmvh2a70p9	2024-12-15 07:48:09+00	\N	electronic
3883	46	7f1EMPdIEkpxVVoydUFsPb	\N	Уходя Уходи	TRITIA	313neyxbfwxtbi2t52gjvliqxisa	2024-11-03 15:15:40+00	\N	pop
3903	47	7qujXXdrRttu71xEywaFoV	\N	Сон Нереид	ТЕППО, Drummatix	313neyxbfwxtbi2t52gjvliqxisa	2024-10-20 10:38:21+00	\N	downtempo
3871	45	7nDrQOUNCJ7kzduuRcBzyW	\N	Toujours +	Adé	31ghi62vkgnlb4wqr6muaisx7ldi	2024-12-07 16:00:49+00	\N	french pop, variété française, french indie pop, french house, chanson
3892	46	7xDd7gl6AGgpiOz5trz4dM	\N	Eyes Closed	Imagine Dragons	31pd6hnytykuevog22xwj5yn2qjy	2024-11-16 12:16:35+00	\N	rock
3872	45	0E7FZsY8dFo2NFmQZAuI2C	\N	Плетут Косы	Klava Bravo	31pd6hnytykuevog22xwj5yn2qjy	2024-12-07 22:49:42+00	\N	pop
3913	47	0BxE4FqsDD1Ot4YuBXwAPp	\N	505	Arctic Monkeys	31433d6i5sfekboj5hr2fjtnwe7u	2024-10-21 04:00:16+00	\N	indie, garage rock
3906	47	0YQoydFmON1rBkbmoa5nhr	\N	Speechless	J'calm	313neyxbfwxtbi2t52gjvliqxisa	2024-10-20 10:38:47+00	\N	r&b
3953	48	0Vd28XYye7Ev1eaGuNP47m	\N	sLeepwALkeR	The Pretty Wild	313neyxbfwxtbi2t52gjvliqxisa	2024-10-18 14:51:52+00	\N	metalcore
3914	47	0VgkVdmE4gld66l8iyGjgx	\N	Mask Off	Future	31pd6hnytykuevog22xwj5yn2qjy	2024-10-21 13:28:55+00	\N	rap
3959	48	0Ycvg2wbafZjiTeOBCBoqd	\N	Утонем	passmurny	31ghi62vkgnlb4wqr6muaisx7ldi	2024-10-20 05:14:24+00	\N	indie
3920	47	1DjGJyM9tG01hB2tuLf40K	\N	Остров - Remix	Leonid Agutin, DJ DANI WOO	31pd6hnytykuevog22xwj5yn2qjy	2024-10-30 13:18:24+00	\N	house
3907	47	0gplL1WMoJ6iYaPgMCL0gX	\N	Easy On Me	Adele	313neyxbfwxtbi2t52gjvliqxisa	2024-10-20 10:38:55+00	\N	soft pop
3931	47	2RM539CjIJyE0EW4efxbgx	\N	Guantanamera - Акустическая версия	Kaspiyskiy Gruz	1qzcdqlwqtm8lnthmvh2a70p9	2024-11-03 07:28:17+00	\N	folk
3908	47	1Jijb30txJ6YZNe5DTu3Lb	\N	GENESIS	From First To Last	313neyxbfwxtbi2t52gjvliqxisa	2024-10-20 10:39:04+00	\N	post-hardcore, screamo, emo
3923	47	1dB0NylVkpjdOe8DiekIs7	\N	HOLIDAY	Turnstile	31ghi62vkgnlb4wqr6muaisx7ldi	2024-11-02 14:25:22+00	\N	hardcore punk, hardcore
3909	47	25RLsZHZOmY6IG23UrTtgI	\N	Pine	LASTELLE	313neyxbfwxtbi2t52gjvliqxisa	2024-10-20 10:39:09+00	\N	melodic hardcore, post-hardcore, metalcore
3940	48	2DI5PnNnnscXVQSIeKR1gw	\N	The Time Is Now	Culture Shock	313neyxbfwxtbi2t52gjvliqxisa	2024-09-22 11:19:01+00	\N	drum and bass, liquid funk
3941	48	2Y9OBE7x3aeJ0qEh5RWxru	\N	Отражение	Tell Me a Fairytale	313neyxbfwxtbi2t52gjvliqxisa	2024-09-22 11:23:57+00	\N	indie
3950	48	393MDhe62s8hbH8ETrlxe5	\N	Mr. Rager	Kid Cudi	31433d6i5sfekboj5hr2fjtnwe7u	2024-10-11 07:55:47+00	\N	hip hop
3946	48	3VCXx37jNGNOMns6z2OnvJ	\N	Swing Lynn	Harmless	31433d6i5sfekboj5hr2fjtnwe7u	2024-09-27 15:03:32+00	\N	indie
3951	48	3CboywxfJIgvHqi2FF4exb	\N	Loverboy	A-Wall	31433d6i5sfekboj5hr2fjtnwe7u	2024-10-13 02:55:23+00	\N	bedroom pop
3922	47	4UjIn11odL0KVopPpO0AvH	\N	Моя мелодия	5sta Family, DJ Pankratov	31433d6i5sfekboj5hr2fjtnwe7u	2024-11-02 02:59:04+00	\N	pop
3949	48	4E5xVW505akJX0wcKj8Mpd	\N	Tornado Of Souls - 2004 Remix	Megadeth	31pd6hnytykuevog22xwj5yn2qjy	2024-10-09 08:57:19+00	\N	thrash metal, metal, heavy metal, speed metal
3942	48	4PdJSsESm34djLfBde9Pr2	\N	Would I Lie to You - Radio Edit	David Guetta, Cedric Gervais, Chris Willis	31pd6hnytykuevog22xwj5yn2qjy	2024-09-23 10:46:38+00	\N	edm
3924	47	4hs0ol9UoDjDzuT3LHgaFQ	\N	Come Along	Cosmo Sheldrake	31ghi62vkgnlb4wqr6muaisx7ldi	2024-11-02 14:25:27+00	\N	indie
3933	47	51VRQpMsOizf1RLkPBiMgG	\N	Голос	Dana Sokolova, L'One	1qzcdqlwqtm8lnthmvh2a70p9	2024-11-03 07:28:17+00	\N	hip hop
3916	47	4pwc7bdKUhjAxE9GncmAe1	\N	Destinazione Mare	Tiziano Ferro	31pd6hnytykuevog22xwj5yn2qjy	2024-10-23 06:26:33+00	\N	italian singer-songwriter
3919	47	5Gd66MYFICFMfWvAG5EJ2K	\N	Urban Melody	IVOXYGEN	31433d6i5sfekboj5hr2fjtnwe7u	2024-10-25 11:47:01+00	\N	electronic
3962	48	5Tf1BtJ5v5PebDYSwQXGFv	\N	Worn / Wander	Vundabar	31ghi62vkgnlb4wqr6muaisx7ldi	2024-10-20 05:23:01+00	\N	indie
3939	48	5qehd5xIsEaifMFy3jcoYr	\N	Jezebel	Sade	313neyxbfwxtbi2t52gjvliqxisa	2024-09-22 11:18:22+00	\N	r&b
3925	47	5dTHtzHFPyi8TlTtzoz1J9	\N	Helena	My Chemical Romance	31ghi62vkgnlb4wqr6muaisx7ldi	2024-11-02 14:25:44+00	\N	emo, pop punk
3930	47	5ywxCogRGJEq39bEdgvSUw	\N	Стану песней	UBEL	1qzcdqlwqtm8lnthmvh2a70p9	2024-11-03 07:28:17+00	\N	indie
3954	48	69B1LNCFR2kjrJczNeQdRf	\N	Xerecation	DJ Nardini, Jhona!	313neyxbfwxtbi2t52gjvliqxisa	2024-10-18 14:52:03+00	\N	electronic
3932	47	6CcO2UHsaE3h6WVYeXYju9	\N	Diamonds And Pearls	THEY.	1qzcdqlwqtm8lnthmvh2a70p9	2024-11-03 07:28:17+00	\N	r&b
3928	47	6HnN1rwLed720u00blTFf3	\N	Hot Girls Club	Дора	1qzcdqlwqtm8lnthmvh2a70p9	2024-11-03 07:28:17+00	\N	pop
3952	48	6FfLg6FFqhCsrFOaHIGkg0	\N	Honeypie	JAWNY	1qzcdqlwqtm8lnthmvh2a70p9	2024-10-16 22:16:09+00	\N	bedroom pop
3948	48	6dOtVTDdiauQNBQEDOtlAB	\N	BIRDS OF A FEATHER	Billie Eilish	31pd6hnytykuevog22xwj5yn2qjy	2024-10-09 08:28:22+00	\N	pop
3960	48	6JJ3UK1YfxO26iEiMWUHHj	\N	Right on time	Metronomy	31ghi62vkgnlb4wqr6muaisx7ldi	2024-10-20 05:14:37+00	\N	new rave, alternative dance
3961	48	6lAG98ZqSThYCcWKl3ABN0	\N	Всё, что я хочу тебе сказать	Деревянные киты	31ghi62vkgnlb4wqr6muaisx7ldi	2024-10-20 05:21:13+00	\N	indie
3915	47	70bKvRcTP1J2pWzALifodZ	\N	Феникс	L'One, Leonid Agutin	31pd6hnytykuevog22xwj5yn2qjy	2024-10-22 21:16:04+00	\N	latin
3938	48	6x9KQT3H2YLqsg8VHPDrmr	\N	The Shape Of Water	Siamese, ten56.	313neyxbfwxtbi2t52gjvliqxisa	2024-09-22 11:06:54+00	\N	metalcore, post-hardcore
3945	48	71wBCrOywU9w3q6KT3VxGF	\N	Not Alone	Benji Lewis	31pd6hnytykuevog22xwj5yn2qjy	2024-09-27 09:28:29+00	\N	electronic
3956	48	7Av1fjNUSXcLJpuFQhxXqC	\N	Метель	Лилая	1qzcdqlwqtm8lnthmvh2a70p9	2024-10-18 15:59:43+00	\N	indie
3929	47	7BYqyvu0dpZDLA86V37p3F	\N	LoLo	Thomas Mraz	1qzcdqlwqtm8lnthmvh2a70p9	2024-11-03 07:28:17+00	\N	pop
3934	47	7ITEvUxFXqvmzrCvcWKQyI	\N	переживем	baur karbon	1qzcdqlwqtm8lnthmvh2a70p9	2024-11-03 07:28:17+00	\N	phonk
3935	47	7cwaJRJ77yHcRizUtNGIUv	\N	Don’t HMU	Anella	1qzcdqlwqtm8lnthmvh2a70p9	2024-11-03 07:28:17+00	\N	r&b
3926	47	7iSE9o1sSduimjMrmToYbq	\N	Серый пёс	Antoha MC, Basta	31ghi62vkgnlb4wqr6muaisx7ldi	2024-11-02 14:30:30+00	\N	hip hop
3910	47	7tcX7UQSdXTB5i5WbPhwRT	\N	Давай держаться за руки	SEREBRO	313neyxbfwxtbi2t52gjvliqxisa	2024-10-20 10:41:43+00	\N	pop
3944	48	7yXSsBfB6qvBJhmK1irhf3	\N	Bloodbath (feat. Chino Moreno)	Polyphia, Chino Moreno	31pd6hnytykuevog22xwj5yn2qjy	2024-09-25 12:55:51+00	\N	math rock, djent, progressive metal, progressive rock
3957	48	0FDzzruyVECATHXKHFs9eJ	\N	A Sky Full of Stars	Coldplay	31433d6i5sfekboj5hr2fjtnwe7u	2024-10-19 04:36:50+00	\N	pop
3921	47	7sm8erq84KNSYh82VBxBwJ	\N	Bunny Party	Nawrras Music	31433d6i5sfekboj5hr2fjtnwe7u	2024-11-01 05:58:22+00	\N	electronic
4006	50	0R8P9KfGJCDULmlEoBagcO	\N	Trouble	Coldplay	31pd6hnytykuevog22xwj5yn2qjy	2024-08-25 12:32:52+00	\N	alternative rock
4018	50	0L7vlrUbYlt9aBJ4FEanKu	\N	Valkyrie	Varien, Laura Brehm	1qzcdqlwqtm8lnthmvh2a70p9	2024-09-07 16:13:59+00	\N	dubstep, drumstep
4025	50	0a1IQZEZnpMVnHFanXHLZu	\N	Льды	At The Ruins	313neyxbfwxtbi2t52gjvliqxisa	2024-09-08 23:48:06+00	\N	metalcore
4011	50	106vWgOc5xlj05wewZ2V4u	\N	FIELD TRIP	¥$, Kanye West, Ty Dolla $ign	31pd6hnytykuevog22xwj5yn2qjy	2024-08-28 08:25:23+00	\N	hip hop
4016	50	17gNddzEEIycz3UuvmmnsM	\N	Мой мармеладный	INSTASAMKA	1qzcdqlwqtm8lnthmvh2a70p9	2024-09-03 23:34:50+00	\N	rap
4007	50	3UBItNVbFQiVC5hBQlBvnr	\N	Your Woman	White Town	31pd6hnytykuevog22xwj5yn2qjy	2024-08-26 22:18:31+00	\N	alternative rock
4024	50	3o60vkANXIudW9WXDIVw3K	\N	урна	астра	313neyxbfwxtbi2t52gjvliqxisa	2024-09-08 23:46:23+00	\N	electronic
4013	50	4IDfVjI1TlB1UwlC01T4Bm	\N	Decode - Twilight Soundtrack Version	Paramore	31pd6hnytykuevog22xwj5yn2qjy	2024-08-29 12:56:02+00	\N	pop punk, emo
4008	50	4KBOnpPbABfXoIQS9Axlh8	\N	Hotride	The Prodigy	31pd6hnytykuevog22xwj5yn2qjy	2024-08-27 10:00:59+00	\N	big beat, breakbeat
4017	50	4bs75O2YGLncWyF6OYRwpy	\N	Happy End - Acustic version	Para Normal`nykh	1qzcdqlwqtm8lnthmvh2a70p9	2024-09-07 16:12:25+00	\N	acoustic
4028	50	5HziDdyCpqzacpMk1PzgCv	\N	Последние цветы	ПОЧТИСЧАСТЛИВ	1qzcdqlwqtm8lnthmvh2a70p9	2024-09-16 16:49:28+00	\N	hardstyle, frenchcore
4022	50	5kHCsELTDAwAz3ghslicoO	\N	Foxglove	Boston Manor	313neyxbfwxtbi2t52gjvliqxisa	2024-09-08 23:42:33+00	\N	pop punk
4019	50	5kx5K2vmXQXeZYrCrsWgPz	\N	Slip Away	Atena	313neyxbfwxtbi2t52gjvliqxisa	2024-09-08 23:27:29+00	\N	djent, metalcore, deathcore
4023	50	5tKUeR7lAKc8l8yksQB8Lu	\N	Города	TRITIA	313neyxbfwxtbi2t52gjvliqxisa	2024-09-08 23:42:49+00	\N	electronic
4021	50	5sVJvhpBwKMPqeU2Ylom0l	\N	Улыбнись	NAT, Samplekilla	313neyxbfwxtbi2t52gjvliqxisa	2024-09-08 23:37:26+00	\N	hi-nrg
4026	50	67hUUu8V72iqADfmWrXC2w	\N	PLAYBOi	Vana, Sophie Powers	313neyxbfwxtbi2t52gjvliqxisa	2024-09-09 11:21:36+00	\N	pop
4004	50	6ADDNqHN7DYthA6ZCYeHRv	\N	Ренессанс	Ivan Dorn, Roman Bestseller	31pd6hnytykuevog22xwj5yn2qjy	2024-08-22 08:51:55+00	\N	pop
4009	50	73ApzKghePbzo6WRbXMYNm	\N	Пой моя молодость (Remastered)	GSTFC	31pd6hnytykuevog22xwj5yn2qjy	2024-08-27 11:30:08+00	\N	folk
4027	50	6GQ10e3XnbqKZrbrICfFB2	\N	My Soldiers Rage	Lost Souls	313neyxbfwxtbi2t52gjvliqxisa	2024-09-11 23:23:13+00	\N	metalcore
4005	50	7KX65PC1UZuImsUInThbav	\N	Cold Little Heart - Radio Edit	Michael Kiwanuka	31pd6hnytykuevog22xwj5yn2qjy	2024-08-25 12:32:43+00	\N	soul
4012	50	7zBTi3ApwkzdgiqBZWU1QM	\N	Déjà Vu	blessthefall	1qzcdqlwqtm8lnthmvh2a70p9	2024-08-28 09:09:16+00	\N	metalcore, post-hardcore, screamo
4045	51	0Q1BqQkTxk04B8ieUVKwvM	\N	Day Ones	Baauer, Novelist, Leikeli47	313neyxbfwxtbi2t52gjvliqxisa	2024-08-11 10:29:33+00	\N	edm trap
4080	52	0lPInaPlS07BwVCanq7Hdt	\N	Нелюбовь	Irakli, Даша Суворова	1qzcdqlwqtm8lnthmvh2a70p9	2024-09-07 21:16:07+00	\N	r&b
4049	51	0dEIca2nhcxDUV8C5QkPYb	\N	Give Life Back to Music	Daft Punk	31pd6hnytykuevog22xwj5yn2qjy	2024-08-15 16:10:12+00	\N	french house, electronic, electro
4030	50	0t7ElZEl7hzwstTYIYfdEs	\N	где твой дом	Beamerlight, Cold Carti	1qzcdqlwqtm8lnthmvh2a70p9	2024-09-16 16:54:31+00	\N	phonk
4029	50	1CT6Ob6nEfUYawi356myC2	\N	кружева	балкон ожиданий, KEER	1qzcdqlwqtm8lnthmvh2a70p9	2024-09-16 16:49:43+00	\N	electronic
4066	52	14iN3o8ptQ8cFVZTEmyQRV	\N	I Kissed A Girl	Katy Perry	1qzcdqlwqtm8lnthmvh2a70p9	2024-09-07 21:16:07+00	\N	pop
4033	50	16M39MZuioqXSmMVUxKBLo	\N	Tears of Russia	Kercha	31ghi62vkgnlb4wqr6muaisx7ldi	2024-09-21 08:08:36+00	\N	dubstep, dub, bass music
4057	51	175xPRXSrf7RSWdjAhc6oD	\N	ТАЙМАУТ	Nikitata	1qzcdqlwqtm8lnthmvh2a70p9	2024-08-16 17:52:37+00	\N	drift phonk, phonk
4054	51	1LPGwuFgIzbJoShfDdw7MY	\N	Youth	Glass Animals	31ghi62vkgnlb4wqr6muaisx7ldi	2024-08-16 12:23:34+00	\N	indie
4031	50	21VOKQvNJj6Hy180JwmLib	\N	Кусай мои губы	лучнадежды	1qzcdqlwqtm8lnthmvh2a70p9	2024-09-20 01:55:52+00	\N	pop
4062	52	1LaV103mcoPexeywIcV1Ev	\N	First Day	Timo Maas	1qzcdqlwqtm8lnthmvh2a70p9	2024-09-07 21:16:07+00	\N	big beat
4086	52	1NB0VPwAw6Rx8b9qvDKB5M	\N	Automatic	ZHU, AlunaGeorge	1qzcdqlwqtm8lnthmvh2a70p9	2024-09-07 07:14:58+00	\N	edm
4056	51	1Rd5OVjqDAr5xC96MHt448	\N	Daydreaming	Radiohead	31ghi62vkgnlb4wqr6muaisx7ldi	2024-08-16 12:24:15+00	\N	art rock, alternative rock
4034	50	1nVa8C6mlUZvM6090Od3v9	\N	Last Night	Subwave, BOP	31ghi62vkgnlb4wqr6muaisx7ldi	2024-09-21 08:08:38+00	\N	liquid funk, drum and bass
4077	52	1uPhDXK4Uji8Z5M9j0qfud	\N	Faces (Dave Winnel Remix)	Glover, Dave Winnel	1qzcdqlwqtm8lnthmvh2a70p9	2024-09-07 21:16:07+00	\N	future house, melbourne bounce
4041	51	2aYUCHQYt8Ggk7Pr1rOYAB	\N	С.М.Г.О.	Slot	313neyxbfwxtbi2t52gjvliqxisa	2024-08-11 10:28:56+00	\N	nu metal
4051	51	2BGyjLA7era3GunIrwqASc	\N	DISTRACTION	Montell Fish	31ghi62vkgnlb4wqr6muaisx7ldi	2024-08-16 12:04:52+00	\N	christian lo-fi
4084	52	2e1WR9PYEAyuu9k5hNHHI1	\N	Castle In The Snow	The Avener, Kadebostany	1qzcdqlwqtm8lnthmvh2a70p9	2024-09-07 07:14:58+00	\N	electronic
4081	52	2b37blpwo9tOYS9oCU0Ly2	\N	Hold on Love	Dan Balan	1qzcdqlwqtm8lnthmvh2a70p9	2024-09-07 21:16:07+00	\N	europop
4070	52	2lsnKlAYv6Qpk1i8whLGkR	\N	Париж	PIZZA	1qzcdqlwqtm8lnthmvh2a70p9	2024-09-07 21:16:07+00	\N	rock
3987	49	5bK1QHcNKo6sKrEAwSOP1a	\N	OK	LSP	31433d6i5sfekboj5hr2fjtnwe7u	2024-09-29 10:20:26+00	\N	hip hop
4055	51	32zkKx35Et6A515oZKxDkD	\N	Life Itself	Glass Animals	31ghi62vkgnlb4wqr6muaisx7ldi	2024-08-16 12:24:04+00	\N	indie
4060	51	2yuoF9C4QF9kCsoDf3yUHP	\N	Feel the Same - EDX Dubai Skyline Remix Edit	Lika Morgan, EDX	1qzcdqlwqtm8lnthmvh2a70p9	2024-08-16 21:32:07+00	\N	future house, house
4067	52	3RDcUlLGp3SLp2AmUbUbls	\N	Cookie Jar (feat. The-Dream)	Gym Class Heroes, The-Dream	1qzcdqlwqtm8lnthmvh2a70p9	2024-09-07 21:16:07+00	\N	hip hop
4073	52	37WssUIwxFxg785SVYSc6H	\N	The Keeper - Alex Banks Remix	Bonobo, Alex Banks, Andreya Triana	1qzcdqlwqtm8lnthmvh2a70p9	2024-09-07 21:16:07+00	\N	trip hop, downtempo, nu jazz, electronic
4083	52	4gDbud61RPFlTwMwtkjMRk	\N	Пепел любви	Aleksey Glyzin	1qzcdqlwqtm8lnthmvh2a70p9	2024-09-07 07:15:27+00	\N	pop
4047	51	3iqV0aca24HL4vTi2e9d8n	\N	Shape Of My Heart - Live At Villa Il Palagio, Italy/2001	Sting	31pd6hnytykuevog22xwj5yn2qjy	2024-08-12 08:42:01+00	\N	soft rock
4078	52	4DEakFTIhXT6JFyCsQUffd	\N	The Party (This Is How We Do It)	Joe Stone, Montell Jordan	1qzcdqlwqtm8lnthmvh2a70p9	2024-09-07 21:16:07+00	\N	future house
4061	51	4WsjvGdBhKFaoIIpp5VtQ7	\N	Let Me Out	Mr FijiWiji	1qzcdqlwqtm8lnthmvh2a70p9	2024-08-17 23:00:36+00	\N	chillstep
4071	52	4lSepgNgfYvE8ICDPeQtJX	\N	Высоко	Yulia Savicheva	1qzcdqlwqtm8lnthmvh2a70p9	2024-09-07 21:16:07+00	\N	pop
4050	51	4hvCxgioUiT85MCgfIhDP3	\N	Too Close / Too Late	Spiritbox	31pd6hnytykuevog22xwj5yn2qjy	2024-08-16 09:55:10+00	\N	metalcore, djent, metal
4069	52	4kJWtxDDNb9oAk3h7sX3N4	\N	Strobe	deadmau5	1qzcdqlwqtm8lnthmvh2a70p9	2024-09-07 21:16:07+00	\N	edm, progressive house, dubstep
4079	52	4scpF6J5uMBvoh6sFB7EL1	\N	No Type	Rae Sremmurd	1qzcdqlwqtm8lnthmvh2a70p9	2024-09-07 21:16:07+00	\N	hip hop
4059	51	5CclXIz1XRJQUfqsLOlqN7	\N	В таком красивом кино	Makhno Project	1qzcdqlwqtm8lnthmvh2a70p9	2024-08-16 20:22:53+00	\N	indie
4043	51	5RPHhu2CyStXFgRhvFYcJ5	\N	Машина времени	TEMNEE	313neyxbfwxtbi2t52gjvliqxisa	2024-08-11 10:29:06+00	\N	rock
4075	52	5V3EXnYq2cw6tuZsy7PuIb	\N	Королева	Каролина	1qzcdqlwqtm8lnthmvh2a70p9	2024-09-07 21:16:07+00	\N	pop
4048	51	5SuOikwiRyPMVoIQDJUgSV	\N	Comedy	Gen Hoshino	1qzcdqlwqtm8lnthmvh2a70p9	2024-08-13 09:53:55+00	\N	j-pop, anime
4082	52	5kLSshBGFxK7aSLF5yT1Kc	\N	Сопрано	МОТ, Ani Lorak	1qzcdqlwqtm8lnthmvh2a70p9	2024-09-07 21:16:07+00	\N	pop
4052	51	5kmv9qvrOgxlOY0ottSalh	\N	Whiplash	bôa	31ghi62vkgnlb4wqr6muaisx7ldi	2024-08-16 12:20:32+00	\N	alternative rock
4063	52	5maJs7vHkn9ESNmMct9a6X	\N	Отпускаю	MakSim	1qzcdqlwqtm8lnthmvh2a70p9	2024-09-07 21:16:07+00	\N	pop
4037	51	7Efr5ZaeWMQ0k998ioxDn7	\N	Only Place To Hide - Edit	Saults	313neyxbfwxtbi2t52gjvliqxisa	2024-08-11 10:28:22+00	\N	alternative rock
4035	50	5nJvKQsFRmCp2i7EiKjZDg	\N	GOTTASADAE	BewhY	31ghi62vkgnlb4wqr6muaisx7ldi	2024-09-21 08:08:42+00	\N	k-rap
4038	51	62agR37W0s0H1Xg1sUgBrz	\N	Killing You	Asking Alexandria	313neyxbfwxtbi2t52gjvliqxisa	2024-08-11 10:28:30+00	\N	metalcore, screamo, post-hardcore, metal, emo
4042	51	63lDtJHqKhUxcGOFZdxG3D	\N	Rave to Love	Venjent	313neyxbfwxtbi2t52gjvliqxisa	2024-08-11 10:29:01+00	\N	drum and bass
4068	52	6v0xtmSo0M16LsyDqUeWLh	\N	To Hell And Back	blessthefall	1qzcdqlwqtm8lnthmvh2a70p9	2024-09-07 21:16:07+00	\N	metalcore, post-hardcore, screamo
4046	51	7K5ERQnsCFYT7XzigQY8sp	\N	Ты и Питер	Wildways	313neyxbfwxtbi2t52gjvliqxisa	2024-08-12 05:57:25+00	\N	metalcore, post-hardcore
4044	51	7hK0aTf0wyxRkYqWAabUwG	\N	As Sick As The Secrets Within	Marilyn Manson	313neyxbfwxtbi2t52gjvliqxisa	2024-08-11 10:29:29+00	\N	industrial metal, industrial rock, industrial, metal, nu metal
4089	52	7lZuT9MkrDoccUfw50jesw	\N	Collide	Fytch	1qzcdqlwqtm8lnthmvh2a70p9	2024-09-07 07:14:49+00	\N	dubstep, future bass
4040	51	7scGzRwZMeHzFNuEJgnzvh	\N	I Won't Give In	Asking Alexandria	313neyxbfwxtbi2t52gjvliqxisa	2024-08-11 10:28:43+00	\N	metalcore, screamo, post-hardcore, metal, emo
4053	51	0ZK8TGOsngrstVPsnrHbK1	\N	Peach Pit	Peach Pit	31ghi62vkgnlb4wqr6muaisx7ldi	2024-08-16 12:23:19+00	\N	indie
4104	53	0JL9TZip7mL7iwC5EOkALS	\N	Lady Brown (feat. Cise Starr from CYNE)	Nujabes, Cise Starr	1qzcdqlwqtm8lnthmvh2a70p9	2024-07-25 23:15:00+00	\N	jazz rap
4141	54	0JLiYHwL8CXEysiurWmdow	\N	Light	Nu Aspect	313neyxbfwxtbi2t52gjvliqxisa	2024-06-30 15:33:33+00	\N	deep house
4096	52	2O0v3gsU9jG7MMFFhir8uk	\N	Я твой враг	t.A.T.u.	1qzcdqlwqtm8lnthmvh2a70p9	2024-09-07 07:16:21+00	\N	pop
4132	53	19w8zzRtBkmTjoEAayPZMx	\N	Отпусти меня	Linda	1qzcdqlwqtm8lnthmvh2a70p9	2024-08-11 00:39:45+00	\N	witch house
4139	54	1lHqZm5MsAc7wZ7W95KcOe	\N	Heretic (feat. Loz Taylor)	Bury Tomorrow	313neyxbfwxtbi2t52gjvliqxisa	2024-06-30 15:33:21+00	\N	metalcore, metal, deathcore
4136	54	2PXxdh7WHZAlONZW8P3H2h	\N	juice	daryana	1qzcdqlwqtm8lnthmvh2a70p9	2024-06-26 22:16:36+00	\N	pop
4100	52	2Gt7fjNlx901pPRkvBiNBZ	\N	Take Me Back To Eden	Sleep Token	1qzcdqlwqtm8lnthmvh2a70p9	2024-09-07 07:17:08+00	\N	progressive metal, metalcore
4099	52	2GzLKB9LnboEfhKxFHuRfC	\N	Journée de merde.	The Caracal Project	1qzcdqlwqtm8lnthmvh2a70p9	2024-09-07 07:17:02+00	\N	drum and bass, liquid funk, drumstep
4102	53	2kLWSmKHhfUBepkIA9oNe5	\N	Abyss - from Kaiju No. 8	YUNGBLUD	1qzcdqlwqtm8lnthmvh2a70p9	2024-07-22 19:19:06+00	\N	rock
4133	54	2tglMa0BeewRE2q1bdNwnP	\N	Огоньки	Lyapis Trubetskoy	1qzcdqlwqtm8lnthmvh2a70p9	2024-06-25 10:16:41+00	\N	rock
4128	53	2v7ywbUzCgcVohHaKUcacV	\N	Like a Prayer	Madonna	31pd6hnytykuevog22xwj5yn2qjy	2024-08-08 07:51:02+00	\N	pop
4131	53	37kioiKMlSg9bdg5KkwUEL	\N	Лютики - live	просто Лера	1qzcdqlwqtm8lnthmvh2a70p9	2024-08-10 21:50:15+00	\N	pop
4142	54	3HvR3yNldsa0cNgbzBYzar	\N	strangeluv	nightlife	313neyxbfwxtbi2t52gjvliqxisa	2024-06-30 15:33:43+00	\N	electronic
4122	53	3RKLJPyyMZfwebsePAzqjL	\N	I'm Good Luv, Enjoy.	Aaron May	31ghi62vkgnlb4wqr6muaisx7ldi	2024-08-01 10:11:41+00	\N	rap
4111	53	39XVc9tJMwgBpaMgGp8wSB	\N	Girei	Leblanc	313neyxbfwxtbi2t52gjvliqxisa	2024-07-30 11:34:28+00	\N	melodic techno, electronic classical
4140	54	3DqOJ2BoddzZpNdty3okJH	\N	RIZZ	AYYBO	313neyxbfwxtbi2t52gjvliqxisa	2024-06-30 15:33:25+00	\N	tech house, house
4143	54	3hWyvp1VMnP1173LPZn07d	\N	Шарады	Luverance	313neyxbfwxtbi2t52gjvliqxisa	2024-06-30 15:33:49+00	\N	pop
4121	53	3hxIUxnT27p5WcmjGUXNwx	\N	Shut up My Moms Calling	Hotel Ugly	31ghi62vkgnlb4wqr6muaisx7ldi	2024-08-01 10:11:26+00	\N	rap
4097	52	3RSpK5Y0y5tl25qvssrwJ6	\N	My All	Mariah Carey	1qzcdqlwqtm8lnthmvh2a70p9	2024-09-07 07:16:56+00	\N	christmas
4093	52	3uyueDmID11OlrcN6CRZ4C	\N	Nobody To Love - Xanti Remix	Out Of Sound, Xanti	1qzcdqlwqtm8lnthmvh2a70p9	2024-09-07 07:16:21+00	\N	house
4095	52	431dLa3HnVrcW6cVdKWe1h	\N	Overglow	Adam Lambert	1qzcdqlwqtm8lnthmvh2a70p9	2024-09-07 07:16:21+00	\N	pop
4149	54	4D7WGniYHsapNrosDX8KDK	\N	Glad I Found You	Elderbrook, George FitzGerald	31pd6hnytykuevog22xwj5yn2qjy	2024-07-05 09:22:09+00	\N	house
4090	52	4K6uXHhNzUjV5OCNETntRD	\N	Angel	Zvonkiy	1qzcdqlwqtm8lnthmvh2a70p9	2024-09-07 07:04:16+00	\N	electronic
4117	53	4KlQFMGjgovv2MiFVIauXY	\N	Ты	Обе-Рек	313neyxbfwxtbi2t52gjvliqxisa	2024-07-30 11:36:57+00	\N	pop
4094	52	4DBLAy03Xk88LOVtrOQ1RD	\N	Coffee (Give Me Something)	Tiësto, Vintage Culture	1qzcdqlwqtm8lnthmvh2a70p9	2024-09-07 07:16:21+00	\N	edm, trance, big room, house
4145	54	4T2FPiKHxD0XUzauvdEIwU	\N	Пускай всё горит	ТАйМСКВЕР, RAM, KOMMO	313neyxbfwxtbi2t52gjvliqxisa	2024-06-30 15:34:45+00	\N	hip hop
4137	54	4bdfdM0YSCo6IcH56PkYTI	\N	Celebrate the Love	Otnicka	1qzcdqlwqtm8lnthmvh2a70p9	2024-06-28 20:53:09+00	\N	electronic
4101	52	4OxdGcetL0r0lH3GPOjvxX	\N	VOH	Kevin Penkin, Takeshi Saito	1qzcdqlwqtm8lnthmvh2a70p9	2024-09-07 07:17:08+00	\N	anime, soundtrack
4118	53	4k6Uh1HXdhtusDW5y8Gbvy	\N	Bad Habit	Steve Lacy	31ghi62vkgnlb4wqr6muaisx7ldi	2024-08-01 10:07:10+00	\N	r&b
4146	54	4olevV9BVXIZpcI3g8E6kI	\N	IF IT DOESN'T HURT	NOTHING MORE	313neyxbfwxtbi2t52gjvliqxisa	2024-06-30 15:34:53+00	\N	metal
4138	54	4t2fT4JBAyjwi7ZLMwl9l9	\N	I LUV U (Sunny)	Alex Gaudino, BLENDER, Ragdoll	1qzcdqlwqtm8lnthmvh2a70p9	2024-06-28 20:55:16+00	\N	house
4106	53	50t0rSOl8nIkyOoHKZjT33	\N	Жесть и чернуха	Slot, ТАйМСКВЕР, Garry Topor	31pd6hnytykuevog22xwj5yn2qjy	2024-07-30 08:17:31+00	\N	rap
4116	53	4oyQFA7BnwLUPFFk8ptNOa	\N	Sold My Soul	RIOT	313neyxbfwxtbi2t52gjvliqxisa	2024-07-30 11:35:40+00	\N	dubstep, deathstep, riddim
4092	52	52IT5fWqmJyvQYLikL5Q7W	\N	Не молчи	Akula	1qzcdqlwqtm8lnthmvh2a70p9	2024-09-07 07:16:00+00	\N	rap
4098	52	5elnCt6iLxfrjtKLyJwspN	\N	Это была любовь	Dima Bilan, Zivert	1qzcdqlwqtm8lnthmvh2a70p9	2024-09-07 07:17:02+00	\N	pop
4103	53	5mUvo0CSNSLn2GPRXwdCZy	\N	It's Not the End	breathe.	31pd6hnytykuevog22xwj5yn2qjy	2024-07-23 07:56:44+00	\N	emo
4147	54	54CVYLbzPYTqM5HHdvXt4O	\N	Slaves	Wolves At The Gate	313neyxbfwxtbi2t52gjvliqxisa	2024-06-30 15:35:09+00	\N	christian rock, metalcore, post-hardcore
4148	54	5ZUIPLoTLJZrPQh2kFZEUM	\N	Addicted	Zerb, The Chainsmokers, Ink	31pd6hnytykuevog22xwj5yn2qjy	2024-07-05 08:50:36+00	\N	afro house
4107	53	6485IYdITAUfoks5gla60L	\N	Всё в порядке	DK	31pd6hnytykuevog22xwj5yn2qjy	2024-07-30 11:03:58+00	\N	indie
4130	53	6c3aRf8VpxyaqEYfI0uAyx	\N	Вечная зима	sylva	1qzcdqlwqtm8lnthmvh2a70p9	2024-08-09 01:37:34+00	\N	indie
4091	52	6dqvyjRaNVP8ALsm4WZNLH	\N	Lost Control	The First Station	1qzcdqlwqtm8lnthmvh2a70p9	2024-09-07 07:16:00+00	\N	indie
4135	54	6SgiZyha5z6oD0EhkWm4Cu	\N	Monument	Automhate, Daeya	1qzcdqlwqtm8lnthmvh2a70p9	2024-06-25 10:20:21+00	\N	riddim, dubstep, deathstep, bass music
4150	54	6aZvOjxEb7sjxsGBgV8oW8	\N	They Say	Paris Blohm, Wasback, Krigarè	1qzcdqlwqtm8lnthmvh2a70p9	2024-07-12 22:30:05+00	\N	progressive house, edm, big room
4129	53	73y1sIyjM3jsIcIV4ZvtHi	\N	Бывшие	SERYABKINA	1qzcdqlwqtm8lnthmvh2a70p9	2024-08-09 01:31:32+00	\N	pop
4119	53	751srcHf5tUqcEa9pRCQwP	\N	Tek It	Cafuné	31ghi62vkgnlb4wqr6muaisx7ldi	2024-08-01 10:08:07+00	\N	rap
4120	53	7fyG2MquxykO3Ufiku1Dj2	\N	Treehouse	Alex G, Emily Yacina	31ghi62vkgnlb4wqr6muaisx7ldi	2024-08-01 10:10:58+00	\N	indie
4110	53	7rQeehJRFCNTwqDffP8c5t	\N	new way out	Poppy	313neyxbfwxtbi2t52gjvliqxisa	2024-07-30 11:32:03+00	\N	pop
4127	53	7m53DM8zCJc07R8q70iTo0	\N	When Orange Is the Sky - Slowed + Reverb	Fabrizio Paterlini	31pd6hnytykuevog22xwj5yn2qjy	2024-08-07 08:35:07+00	\N	neoclassical
4144	54	7uFyVm7wVemyJ3FhFTtyWV	\N	Purgatory	The Narrator	313neyxbfwxtbi2t52gjvliqxisa	2024-06-30 15:34:28+00	\N	metalcore
4115	53	0criiQKIY1hyU0lRbVhZ8L	\N	Monster	STARSET	313neyxbfwxtbi2t52gjvliqxisa	2024-07-30 11:35:22+00	\N	metal
4188	55	0Ja4hLKiUSw01E01pJ1yGr	\N	Breathe	The Prodigy	31pd6hnytykuevog22xwj5yn2qjy	2024-06-22 12:12:01+00	\N	big beat, breakbeat
4153	54	0w005yiQt3No8sOFzZrWvF	\N	Зачем я тебе?!	ARTIK & ASTI	1qzcdqlwqtm8lnthmvh2a70p9	2024-07-18 18:41:05+00	\N	pop
4160	54	0TZejo18HlJ86OrWNsXKnw	\N	Mrs Magic	Strawberry Guy	31ghi62vkgnlb4wqr6muaisx7ldi	2024-07-20 13:18:41+00	\N	bedroom pop
4201	55	1B7S5cEGb5Ku1w74DdQHq8	\N	Living	TENDER	31pd6hnytykuevog22xwj5yn2qjy	2024-06-24 10:52:09+00	\N	indie
4195	55	10Nmj3JCNoMeBQ87uw5j8k	\N	Dani California	Red Hot Chili Peppers	31pd6hnytykuevog22xwj5yn2qjy	2024-06-24 10:07:46+00	\N	funk rock, alternative rock, rock
4186	55	1yEfCKc9mErqrHvwQq5aJi	\N	Кошмар	Big Russian Boss	31pd6hnytykuevog22xwj5yn2qjy	2024-06-22 11:51:15+00	\N	rap
4163	54	22DH8NChecsgPxDjA4pqer	\N	Tough	Quavo, Lana Del Rey	31pd6hnytykuevog22xwj5yn2qjy	2024-07-21 11:13:11+00	\N	hip hop
4177	55	2CWbf5NVt0SaqZgcAlnRss	\N	My Only - Australian Version	Goodnight Nurse	31pd6hnytykuevog22xwj5yn2qjy	2024-06-22 12:19:11+00	\N	pop
4168	55	2BqDbaNNOMdxKc6jfJ8O0e	\N	Immortalized	Disturbed	31pd6hnytykuevog22xwj5yn2qjy	2024-06-26 08:57:42+00	\N	metal, nu metal, alternative metal, rap metal, hard rock
4202	55	2Fn0TbHnNqYVTs5zQY4ne9	\N	Re.Up	Rationale	31pd6hnytykuevog22xwj5yn2qjy	2024-06-24 10:55:31+00	\N	pop
4208	56	2FnVO6u7v1qLiNlcxQZ4M0	\N	Было давно	GUF	31ghi62vkgnlb4wqr6muaisx7ldi	2024-06-22 12:44:36+00	\N	rap
4159	54	2kKKhed7zm8CKmlUALpYu3	\N	Fire Escape	Call Me Karizma	31ghi62vkgnlb4wqr6muaisx7ldi	2024-07-20 13:17:42+00	\N	hip hop
4176	55	2Tn7OGpPsAaxKqMLyycJo3	\N	She Sun	The Subways	31pd6hnytykuevog22xwj5yn2qjy	2024-06-22 12:15:28+00	\N	garage rock
4151	54	2WPIxceRvtnq6VtA8gjftE	\N	Hideaway	Cigarettes After Sex	31pd6hnytykuevog22xwj5yn2qjy	2024-07-15 20:09:52+00	\N	dream pop
4203	55	2XdcUAsMCuNMaWLmXIhdjW	\N	Dead Butterflies	Architects	31pd6hnytykuevog22xwj5yn2qjy	2024-06-25 08:40:34+00	\N	metalcore, djent, metal, mathcore, post-hardcore, deathcore
4157	54	2aPTvyE09vUCRwVvj0I8WK	\N	Sundress	A$AP Rocky	31ghi62vkgnlb4wqr6muaisx7ldi	2024-07-20 13:16:41+00	\N	rap
4162	54	2nG6kTV1NDqkCtFhFZOQGu	\N	Hit My Heart	DNF, Dhany	1qzcdqlwqtm8lnthmvh2a70p9	2024-07-21 02:53:20+00	\N	r&b
4193	55	331EQC6sdW3fIRYLmeDv3l	\N	Счастье	Assai	31pd6hnytykuevog22xwj5yn2qjy	2024-06-22 12:51:41+00	\N	pop
4212	56	3Orno5QU2SSptrbE6bzJNY	\N	Снег идёт	Глюк'oZa	31ghi62vkgnlb4wqr6muaisx7ldi	2024-06-22 12:44:45+00	\N	pop
4184	55	3WQlJpaUUbGtUqAskvGA7c	\N	Yonkers	Tyler, The Creator	31pd6hnytykuevog22xwj5yn2qjy	2024-06-22 12:04:23+00	\N	hip hop
4196	55	3RAFcUBrCNaboRXoP3S5t1	\N	Psychosocial	Slipknot	31pd6hnytykuevog22xwj5yn2qjy	2024-06-22 13:03:35+00	\N	nu metal, metal, alternative metal, rap metal, heavy metal
4155	54	3azJifCSqg9fRij2yKIbWz	\N	The Color Violet	Tory Lanez	31pd6hnytykuevog22xwj5yn2qjy	2024-07-19 11:19:36+00	\N	r&b
4173	55	431dLa3HnVrcW6cVdKWe1h	\N	Overglow	Adam Lambert	31pd6hnytykuevog22xwj5yn2qjy	2024-06-16 11:24:13+00	\N	pop
4200	55	3zYufmyv6HOuiHn1eMR6Ja	\N	Desert Rose	Sting, Cheb Mami	31pd6hnytykuevog22xwj5yn2qjy	2024-06-22 10:13:39+00	\N	soft rock
4183	55	42GcjriRK6srwHkfbkBqVl	\N	Blood On The Leaves	Kanye West	31pd6hnytykuevog22xwj5yn2qjy	2024-06-22 11:45:05+00	\N	rap
4170	55	49FYlytm3dAAraYgpoJZux	\N	Umbrella	Rihanna, JAŸ-Z	31pd6hnytykuevog22xwj5yn2qjy	2024-06-24 10:55:50+00	\N	r&b
4210	56	4Ik9Yhh91b4KsCuyx9NtyF	\N	Blood Gets Thin	Pete And The Pirates	31ghi62vkgnlb4wqr6muaisx7ldi	2024-06-22 12:44:41+00	\N	indie
4209	56	4CbKVDZkYKdv69I4bCaKUq	\N	Hero	Skillet	31ghi62vkgnlb4wqr6muaisx7ldi	2024-06-22 12:44:40+00	\N	christian rock, christian alternative rock, christian
4164	55	4CeeEOM32jQcH3eN9Q2dGj	\N	Smells Like Teen Spirit	Nirvana	31pd6hnytykuevog22xwj5yn2qjy	2024-06-09 14:08:51+00	\N	grunge, rock
4198	55	4rf00ZhiMOM4Bl2rzlYEQE	\N	Kiss Me Where It Smells Funny	Bloodhound Gang	31pd6hnytykuevog22xwj5yn2qjy	2024-06-24 10:15:49+00	\N	punk
4172	55	4gbVRS8gloEluzf0GzDOFc	\N	Maps	Maroon 5	31pd6hnytykuevog22xwj5yn2qjy	2024-06-13 11:37:43+00	\N	pop
4181	55	4nva9EpKntUTs6CRSGBCn9	\N	Just A Lil Bit	50 Cent	31pd6hnytykuevog22xwj5yn2qjy	2024-06-22 11:08:23+00	\N	old school hip hop, east coast hip hop
4179	55	5NqhAFTgPTsxhm7kDhfVCw	\N	Вокруг шум	Kasta	31pd6hnytykuevog22xwj5yn2qjy	2024-06-22 10:41:00+00	\N	rap
4189	55	4uUG5RXrOk84mYEfFvj3cK	\N	I'm Good (Blue)	David Guetta, Bebe Rexha	31pd6hnytykuevog22xwj5yn2qjy	2024-06-25 14:27:24+00	\N	edm
4194	55	5bkfPKnHLi6AUP3fJA5Xf5	\N	Вселенная бесконечна?	Noize MC	31pd6hnytykuevog22xwj5yn2qjy	2024-07-08 06:42:28+00	\N	hip hop
4207	56	5cbVQm11IEZieWTgX1UT25	\N	The Moss	Cosmo Sheldrake	31ghi62vkgnlb4wqr6muaisx7ldi	2024-06-22 12:44:29+00	\N	indie
4191	55	5ozW0fwPT87p3hUSf7fUQl	\N	Невеста	Глюк'oZa	31pd6hnytykuevog22xwj5yn2qjy	2024-06-24 10:22:30+00	\N	pop
4192	55	6RqIn2HfI8zlIUwh4u54rZ	\N	почему	Zemfira	31pd6hnytykuevog22xwj5yn2qjy	2024-06-24 10:33:24+00	\N	rock
4166	55	5sNESr6pQfIhL3krM8CtZn	\N	Numb / Encore	JAŸ-Z, Linkin Park	31pd6hnytykuevog22xwj5yn2qjy	2024-06-24 10:01:24+00	\N	hip hop, east coast hip hop, rap
4206	56	6eSB9z6SKIlGeqMLvO5lAb	\N	Zoom	Last Dinosaurs	31ghi62vkgnlb4wqr6muaisx7ldi	2024-06-22 12:44:27+00	\N	indie
4185	55	73tXOEqTow62wTYLl50Xii	\N	Wild Youngster (feat. ScHoolboy Q)	NEZ, ScHoolboy Q	31pd6hnytykuevog22xwj5yn2qjy	2024-06-24 10:18:58+00	\N	hip hop
4165	55	6eYUbXmncekAKMYZcsSkyD	\N	I Stand Alone	Godsmack	31pd6hnytykuevog22xwj5yn2qjy	2024-06-16 11:53:54+00	\N	alternative metal, nu metal, hard rock, rap metal, metal
4174	55	6nTiIhLmQ3FWhvrGafw2zj	\N	American Idiot	Green Day	31pd6hnytykuevog22xwj5yn2qjy	2024-06-22 10:28:50+00	\N	punk, pop punk
4187	55	73aOM4jyU3begiIYxYUd89	\N	How Much Is The Fish?	Scooter	31pd6hnytykuevog22xwj5yn2qjy	2024-06-16 10:48:51+00	\N	happy hardcore, eurodance
4178	55	77z8kq849BIkL26TAuk8O4	\N	Легко ли быть молодым	Centr	31pd6hnytykuevog22xwj5yn2qjy	2024-06-22 10:36:51+00	\N	rap
4199	55	7J1uxwnxfQLu4APicE5Rnj	\N	Billie Jean	Michael Jackson	31pd6hnytykuevog22xwj5yn2qjy	2024-06-24 10:43:46+00	\N	pop
4204	56	7ACxUo21jtTHzy7ZEV56vU	\N	Crazy Train	Ozzy Osbourne	31ghi62vkgnlb4wqr6muaisx7ldi	2024-06-22 12:44:23+00	\N	metal, glam metal, heavy metal, hard rock
4180	55	7lQ8MOhq6IN2w8EYcFNSUk	\N	Without Me	Eminem	31pd6hnytykuevog22xwj5yn2qjy	2024-06-22 10:48:35+00	\N	rap, hip hop
4158	54	0OskO5yG0OzyxmzCybqNRE	\N	2	Life After Youth	31ghi62vkgnlb4wqr6muaisx7ldi	2024-07-20 13:17:08+00	\N	indie
4239	56	0fv2KH6hac06J86hBUTcSf	\N	NEW MAGIC WAND	Tyler, The Creator	31ghi62vkgnlb4wqr6muaisx7ldi	2024-06-22 12:45:41+00	\N	rap
4238	56	0mYqpOzNOl4UtWBeIwVq3s	\N	ты	джинсы тарковского	31ghi62vkgnlb4wqr6muaisx7ldi	2024-06-22 12:45:39+00	\N	emo
4224	56	0xNOmqiuCAd3auYycZ2BoM	\N	Равнодушие	Malbec, Siuzanna	31ghi62vkgnlb4wqr6muaisx7ldi	2024-06-22 12:45:11+00	\N	pop
4236	56	0oQb78vfcQqzu9mBtWT1oM	\N	Ехидна	Ермак!	31ghi62vkgnlb4wqr6muaisx7ldi	2024-06-22 12:45:35+00	\N	post-hardcore
4234	56	10hMM5nsZQf66ldBlgWBfG	\N	All For Us - from the HBO Original Series Euphoria	Labrinth, Zendaya	31ghi62vkgnlb4wqr6muaisx7ldi	2024-06-22 12:45:31+00	\N	soundtrack
4254	57	1RuSmAD4rKVpUHY7lb6sz9	\N	HUSH Epais Remix	Biometrix, Charli Brix, Epais	313neyxbfwxtbi2t52gjvliqxisa	2024-06-16 05:45:20+00	\N	drum and bass
4255	57	1DOJAC971RZsoIdyM5sB53	\N	Into The Fire	Asking Alexandria	313neyxbfwxtbi2t52gjvliqxisa	2024-06-16 06:32:20+00	\N	metalcore, screamo, post-hardcore, metal, emo
4214	56	1PJRDeZSoZk7gtisdTYfLi	\N	Crawling In The Dark	Hoobastank	31ghi62vkgnlb4wqr6muaisx7ldi	2024-06-22 12:44:49+00	\N	nu metal
4237	56	1cmIuauHOxvxzTCFXFnNRL	\N	В диапазоне	Pornofilmy	31ghi62vkgnlb4wqr6muaisx7ldi	2024-06-22 12:45:37+00	\N	pop
4227	56	1SbqxemPdwGlvmirtQVkCU	\N	Summit (feat. Ellie Goulding)	Skrillex, Ellie Goulding	31ghi62vkgnlb4wqr6muaisx7ldi	2024-06-22 12:45:18+00	\N	dubstep, edm, electro, electronic
4233	56	377gcOwauAYITC3AoXqSyr	\N	17:05	Samoe Bolshoe Prostoe Chislo, Naadia	31ghi62vkgnlb4wqr6muaisx7ldi	2024-06-22 12:45:29+00	\N	pop
4260	57	2A6sF07HNFgkkluQGBvD7j	\N	Jaded	Imminence	313neyxbfwxtbi2t52gjvliqxisa	2024-06-16 06:00:51+00	\N	metalcore, metal
4261	57	2Gt7fjNlx901pPRkvBiNBZ	\N	Take Me Back To Eden	Sleep Token	313neyxbfwxtbi2t52gjvliqxisa	2024-06-16 06:02:09+00	\N	progressive metal, metalcore
4256	57	2JgLS3CJLyBffCUrJaFgdM	\N	In These Shadows (feat. Carmen Forbes)	Fytch, Carmen Forbes	313neyxbfwxtbi2t52gjvliqxisa	2024-06-16 05:47:30+00	\N	dubstep, future bass
4271	58	32Rf95ZT8gxisQMK6xAhba	\N	Amen Brother	The Winstons	1qzcdqlwqtm8lnthmvh2a70p9	2024-05-30 10:45:28+00	\N	breakbeat
4229	56	39JQbidaa4OUKds37VbBqW	\N	Вверх-вниз	LSP	31ghi62vkgnlb4wqr6muaisx7ldi	2024-06-22 12:45:22+00	\N	pop
4259	57	3mkgsrr9prHc7nz2jvOwuH	\N	Котик	Аффинаж	313neyxbfwxtbi2t52gjvliqxisa	2024-06-16 05:58:49+00	\N	folk
4241	56	3R558vzNPUNRHHlmu5FFBD	\N	Hanezeve Caradhina	Kevin Penkin, Takeshi Saito	31ghi62vkgnlb4wqr6muaisx7ldi	2024-06-22 12:45:44+00	\N	anime, soundtrack
4223	56	435yU2MvEGfDdmbH0noWZ0	\N	worldstar money (interlude)	Joji	31ghi62vkgnlb4wqr6muaisx7ldi	2024-06-22 12:45:09+00	\N	hip hop
4265	58	3oy3m2ppYCBQEB6ZQrdigZ	\N	Jealous	MAXPVNK, Fatyzzz	1qzcdqlwqtm8lnthmvh2a70p9	2024-05-30 09:54:53+00	\N	phonk, brazilian phonk
4245	57	3tz0aXYY6YuW2uGz0ocq7P	\N	Blue	Gemini	313neyxbfwxtbi2t52gjvliqxisa	2024-06-16 05:30:12+00	\N	dubstep, chillstep, dub
4269	58	49FYlytm3dAAraYgpoJZux	\N	Umbrella	Rihanna, JAŸ-Z	1qzcdqlwqtm8lnthmvh2a70p9	2024-05-30 10:26:02+00	\N	r&b
4213	56	4B3qEctMpLkb7eewdrQ6lU	\N	Ain't No Rest for the Wicked	Cage The Elephant	31ghi62vkgnlb4wqr6muaisx7ldi	2024-06-22 12:44:47+00	\N	alternative rock
4235	56	4EbMgU3Iidw5Mf6LVEAka7	\N	Возможно	My	31ghi62vkgnlb4wqr6muaisx7ldi	2024-06-22 12:45:33+00	\N	pop
4264	58	4v7DCN09hgXkKazefkznDQ	\N	Lonely	Akon	1qzcdqlwqtm8lnthmvh2a70p9	2024-05-30 08:01:35+00	\N	r&b
4219	56	4UFQBhIOgANiBG44USIgsf	\N	Army Of Me	Björk	31ghi62vkgnlb4wqr6muaisx7ldi	2024-06-22 12:45:00+00	\N	art pop, trip hop
4248	57	4tJB5f9Pw6yuVjMmAzNK8U	\N	Louder (feat. Sian Evans) - Doctor P & Flux Pavilion Remix	DJ Fresh, Sian Evans, Doctor P, Flux Pavilion	313neyxbfwxtbi2t52gjvliqxisa	2024-06-16 05:47:08+00	\N	drum and bass
4246	57	5FC9AXSEZjdHRLCbPSJNzB	\N	Я никогда не видел моря	25/17	313neyxbfwxtbi2t52gjvliqxisa	2024-06-16 05:39:06+00	\N	rock
4272	58	51ml2bJs9zDLv1PbzNQzPP	\N	Apache	Incredible Bongo Band	1qzcdqlwqtm8lnthmvh2a70p9	2024-05-30 10:54:08+00	\N	breakbeat
4247	57	5JoYyS2VEJeUjZrPQwC6g2	\N	ТМЛБ (feat. Ямыч)	Адвайта, Ямыч	313neyxbfwxtbi2t52gjvliqxisa	2024-06-16 05:42:47+00	\N	hip hop
4228	56	5qaHd2XUX2heyaGpi6Gukm	\N	РАССВЕТ	Джизус	31ghi62vkgnlb4wqr6muaisx7ldi	2024-06-22 12:45:20+00	\N	rap
4220	56	5TXDeTFVRVY7Cvt0Dw4vWW	\N	Revenge	XXXTENTACION	31ghi62vkgnlb4wqr6muaisx7ldi	2024-06-22 12:45:03+00	\N	emo rap
4263	58	5UGAXwbA17bUC0K9uquGY2	\N	Antarctica	$uicideboy$	31pd6hnytykuevog22xwj5yn2qjy	2024-05-29 13:16:58+00	\N	emo rap, horrorcore, cloud rap, trap metal, underground hip hop
4262	58	5VZ0soW5syQfefCUj603DW	\N	MASHA ULTRAFUNK	HISTED, TXVSTERPLAYA	1qzcdqlwqtm8lnthmvh2a70p9	2024-05-28 19:52:13+00	\N	phonk, brazilian phonk
4244	57	5i7fZq3chLyCHo3VeB6goD	\N	First of the Year (Equinox)	Skrillex	313neyxbfwxtbi2t52gjvliqxisa	2024-06-16 05:30:05+00	\N	dubstep, edm, electro, electronic
4225	56	6DqbkYHW2x1l3IbK0pA9g9	\N	Lin Ansty	влюбиться в тебя, LIL MORFY	31ghi62vkgnlb4wqr6muaisx7ldi	2024-06-22 12:45:13+00	\N	pop
4230	56	5zjthjh40n5oYMatViAoET	\N	Память	Pasosh	31ghi62vkgnlb4wqr6muaisx7ldi	2024-06-22 12:45:23+00	\N	post-punk
4252	57	66y0FcRJl7dff2XIaOQ8DA	\N	Hell city (feat. тони раут)	Wildways, Tony Raut	313neyxbfwxtbi2t52gjvliqxisa	2024-06-16 06:10:22+00	\N	metalcore, post-hardcore
4243	57	69QHm3pustz01CJRwdo20z	\N	Hells Bells	AC/DC	313neyxbfwxtbi2t52gjvliqxisa	2024-06-16 05:37:26+00	\N	rock, hard rock, classic rock, rock and roll
4232	56	6MX3FFYbH2wvPUk12qDzcm	\N	Чернила	Thomas Mraz	31ghi62vkgnlb4wqr6muaisx7ldi	2024-06-22 12:45:28+00	\N	pop
4253	57	6XoRFJeXO3TOQ7q45Gi8K0	\N	Когда ты улыбаешься	Dневник Dжессики	313neyxbfwxtbi2t52gjvliqxisa	2024-06-16 05:45:25+00	\N	pop
4217	56	7rnHYmrdjha6D4uE9A6l7z	\N	Fresh Blood	Eels	31ghi62vkgnlb4wqr6muaisx7ldi	2024-06-22 12:44:57+00	\N	rock
4231	56	6bo6aMi51B8IIvpgNlgmJB	\N	HBO	Electroforez	31ghi62vkgnlb4wqr6muaisx7ldi	2024-06-22 12:45:26+00	\N	post-punk, darkwave, cold wave
4215	56	6qZjm61s6u8Ead9sWxCDro	\N	Elephant	Tame Impala	31ghi62vkgnlb4wqr6muaisx7ldi	2024-06-22 12:44:52+00	\N	neo-psychedelic, indie
4222	56	77xZFu9TwwYnX7JNWfbavn	\N	Matilda	alt-J	31ghi62vkgnlb4wqr6muaisx7ldi	2024-06-22 12:45:07+00	\N	indie, indie rock
4268	58	7ixiCZEHWHc8FxaQXQh2P4	\N	Bam Bam	Sister Nancy	1qzcdqlwqtm8lnthmvh2a70p9	2024-05-30 10:24:34+00	\N	reggae, ragga, rocksteady
4257	57	7zHe3QFT8s36Pa4bSkUHoE	\N	Круги на воде	Slot	313neyxbfwxtbi2t52gjvliqxisa	2024-06-16 05:47:11+00	\N	rock
4258	57	0PjjLpu9RzqCOAZk6Sum5v	\N	Basic Needs	Jonathan Davis	313neyxbfwxtbi2t52gjvliqxisa	2024-06-16 06:49:09+00	\N	nu metal
4279	59	0B4YX3OMtZSmPm9KpiZKl2	\N	Alkaline	Sleep Token	313neyxbfwxtbi2t52gjvliqxisa	2024-05-22 11:36:38+00	\N	progressive metal, metalcore
4304	60	0FCABIXhXHI4mi0qao8gTR	\N	SAFE WITH ME (SECRETOS)	Jhay Rivas	1qzcdqlwqtm8lnthmvh2a70p9	2024-05-14 13:13:17+00	\N	stutter house
4276	58	1RKUoGiLEbcXN4GY4spQDx	\N	Clint Eastwood	Gorillaz, Del The Funky Homosapien	313neyxbfwxtbi2t52gjvliqxisa	2024-06-09 10:08:32+00	\N	hip hop
4309	60	0gmbgwZ8iqyMPmXefof8Yf	\N	How You Remind Me	Nickelback	31pd6hnytykuevog22xwj5yn2qjy	2024-05-17 17:17:00+00	\N	post-grunge, rock
4318	60	0idKC9Hl0fT8anE1xtO6NK	\N	Pinnacle - SENZA Remix	4URA, SENZA, PhiloSofie	1qzcdqlwqtm8lnthmvh2a70p9	2024-05-19 07:57:27+00	\N	melodic bass, edm trap, future bass
4325	61	0oJajz1nc2RPhIenNydW0M	\N	Begin the End	Placebo	1qzcdqlwqtm8lnthmvh2a70p9	2024-04-24 12:31:57+00	\N	britpop
4293	59	0uMYTvGhl0kyrVUqCOQmby	\N	I Can't Stop	ONEIL, Aize	1qzcdqlwqtm8lnthmvh2a70p9	2024-05-25 13:56:01+00	\N	slap house, g-house
4296	59	1VKWQgq0g2uKtgNfL0ceNM	\N	Perfect (Exceeder) - 1991 Remix	Mason, Princess Superstar, 1991	313neyxbfwxtbi2t52gjvliqxisa	2024-05-25 17:30:50+00	\N	house
4306	60	1ZMiCix7XSAbfAJlEZWMCp	\N	Falling	Harry Styles	313neyxbfwxtbi2t52gjvliqxisa	2024-05-16 00:47:42+00	\N	pop
4305	60	1t6yzcLN3JFlQPW1WtQqmF	\N	I Lost a Friend	FINNEAS	313neyxbfwxtbi2t52gjvliqxisa	2024-05-14 23:31:53+00	\N	pop
4287	59	1fcR1xtq85n7k14tRuCsjw	\N	Whisper Whisper Whisper	Azari	31ghi62vkgnlb4wqr6muaisx7ldi	2024-05-25 12:00:49+00	\N	vocaloid, j-pop
4315	60	29plTG4R8PVzDxD0ybsusV	\N	While I'm In It	Talkless	31ghi62vkgnlb4wqr6muaisx7ldi	2024-05-18 10:31:54+00	\N	indie
4317	60	2K7xn816oNHJZ0aVqdQsha	\N	Softcore	The Neighbourhood	31ghi62vkgnlb4wqr6muaisx7ldi	2024-05-19 07:57:18+00	\N	indie
4328	61	2AiIximBPa0ZHp8dlxiiPd	\N	Life Ain't A Game	Ja Rule	1qzcdqlwqtm8lnthmvh2a70p9	2024-04-24 13:39:06+00	\N	east coast hip hop
4294	59	2BpUgxmfgf0eKfGLGN8k5L	\N	Romanticise	Chela et Cetera	1qzcdqlwqtm8lnthmvh2a70p9	2024-05-25 13:58:03+00	\N	nu disco
4298	60	2GWtLHhqPjvZt1aWiBDsTU	\N	Cellar Door	Spiritbox	313neyxbfwxtbi2t52gjvliqxisa	2024-05-12 15:32:06+00	\N	metalcore, djent, metal
4330	61	2bPprDTu2ZT8NOdANKh27g	\N	Ветер	MONOKINI	1qzcdqlwqtm8lnthmvh2a70p9	2024-04-24 18:14:25+00	\N	indie
4278	59	2fcvY7LS29i1NvtrMpCJ9D	\N	Котенок	Никита Малинин	313neyxbfwxtbi2t52gjvliqxisa	2024-05-22 10:25:39+00	\N	pop
4295	59	2tUBqZG2AbRi7Q0BIrVrEj	\N	I Wanna Dance with Somebody (Who Loves Me)	Whitney Houston	1qzcdqlwqtm8lnthmvh2a70p9	2024-05-25 14:01:21+00	\N	pop
4275	58	2kkSXTDCGHWcnl5PQPTK0e	\N	Splinter	Savant	313neyxbfwxtbi2t52gjvliqxisa	2024-06-05 23:23:53+00	\N	dubstep, drumstep
4289	59	3QeYYS4Ynv7OXSg5feOXpr	\N	Самурай	TERELYA	31ghi62vkgnlb4wqr6muaisx7ldi	2024-05-25 12:02:36+00	\N	electronic
4313	60	2zmkaUm9bNE8bGQ7JkRWr9	\N	POLITITS 2024 (Hjemmesnekk)	BORGHINI, POLITITS, FISH N’ TITS, DINULFTITS, EL-TITS, JAPSETITS	1qzcdqlwqtm8lnthmvh2a70p9	2024-05-18 10:22:21+00	\N	russelåter, epadunk
4312	60	32fmpSErWILMEMgjnGI0p9	\N	Stack That	Code: Pandorum, Virus Syndicate	1qzcdqlwqtm8lnthmvh2a70p9	2024-05-18 10:16:57+00	\N	deathstep, dubstep, riddim, bass music
4292	59	3JWiDGQX2eTlFvKj3Yssj3	\N	Closed On Sunday	Kanye West	1qzcdqlwqtm8lnthmvh2a70p9	2024-05-25 13:55:03+00	\N	rap
4311	60	3d5rItXo00Q68H7gp4rykg	\N	Only Today	Basta, GUF	31pd6hnytykuevog22xwj5yn2qjy	2024-05-17 17:38:12+00	\N	hip hop
4310	60	3lE8RY6yZoGqqJeZS06u6J	\N	Где нас нет	Oxxxymiron	31pd6hnytykuevog22xwj5yn2qjy	2024-05-17 17:33:49+00	\N	rap
4326	61	4A2BNmLluHiLsLQA0j9ngs	\N	Margarita	CloudNone, Direct	1qzcdqlwqtm8lnthmvh2a70p9	2024-04-24 13:22:35+00	\N	electronic
4283	59	42O31gY8N28p4DAk7YYkeM	\N	Get Shaky (Macon's Remix)	The Ian Carey Project, Macon	1qzcdqlwqtm8lnthmvh2a70p9	2024-05-22 17:33:20+00	\N	hypertechno, techno
4316	60	4xmg82NG7pGPp0UQBJpwHr	\N	i don't dance	I Hate Myself Because	31ghi62vkgnlb4wqr6muaisx7ldi	2024-05-18 10:32:38+00	\N	emo
4273	58	4AxrlOlmlKducWdz18bLYB	\N	Sliced Tomatoes	Just Brothers	31ghi62vkgnlb4wqr6muaisx7ldi	2024-05-31 13:53:44+00	\N	northern soul
4303	60	4Co1OjIiGp0Fa5yr7rndy1	\N	Heart 111	yuri	1qzcdqlwqtm8lnthmvh2a70p9	2024-05-13 15:46:33+00	\N	j-pop
4291	59	4PPVHBwAiIqzxbfkL6EgsJ	\N	Hailstorms	Hugo	1qzcdqlwqtm8lnthmvh2a70p9	2024-05-25 13:53:05+00	\N	southern gothic
4332	61	4XZnnoFOCAUvRddaJSxyPp	\N	ЭМО	Wildways	313neyxbfwxtbi2t52gjvliqxisa	2024-04-26 23:19:57+00	\N	metalcore, post-hardcore
4290	59	4soZjBWp9Xxri3tkdnyEP5	\N	Catching Smoke	King Gizzard & The Lizard Wizard	31ghi62vkgnlb4wqr6muaisx7ldi	2024-05-25 12:05:48+00	\N	neo-psychedelic, psychedelic rock
4307	60	4xDwCYhobDehSBGUmd5H6Y	\N	FEEL NOTHING	The Plot In You	313neyxbfwxtbi2t52gjvliqxisa	2024-05-17 04:16:27+00	\N	metalcore
4288	59	52QCCDEWhPFw7a0AOqw1IW	\N	Песня про месть	Шым	31ghi62vkgnlb4wqr6muaisx7ldi	2024-05-25 12:02:20+00	\N	rap
4299	60	6PetYmvjKZBjiUYlnlAcn1	\N	this is what space feels like	JVKE	313neyxbfwxtbi2t52gjvliqxisa	2024-05-12 15:32:10+00	\N	electronic
4327	61	5eR6OS3joTAHJToyzehKfu	\N	Trouble’s Coming	Royal Blood	1qzcdqlwqtm8lnthmvh2a70p9	2024-04-24 13:26:50+00	\N	garage rock, rock
4274	58	5fiOYLI3NX8tJvqTASi9yw	\N	Artillery	Skazi, JETFIRE	313neyxbfwxtbi2t52gjvliqxisa	2024-06-03 09:00:10+00	\N	psytrance, trance, progressive trance
4331	61	5oB8lvHx6Ww4QC02EBUjRc	\N	Beyond the Pale	Imminence	313neyxbfwxtbi2t52gjvliqxisa	2024-04-26 04:21:03+00	\N	metalcore, metal
4282	59	6B8pYtoS3XHrc821hExWf6	\N	Tudo Vai Dar Certo	Natiruts, Amani Kush	1qzcdqlwqtm8lnthmvh2a70p9	2024-05-22 17:32:47+00	\N	reggae, mpb, roots reggae, reggae pop
4285	59	6FSCClIrk0Q1DhXnjUZWef	\N	Inkya Impulse	二口魔菜 Futakuchi Mana	313neyxbfwxtbi2t52gjvliqxisa	2024-05-22 23:34:18+00	\N	j-rock
4324	61	6slWOE0SO6HjBH0fNd13YB	\N	Skin and Bones	070 Shake	1qzcdqlwqtm8lnthmvh2a70p9	2024-04-24 10:20:27+00	\N	r&b
4300	60	6RObeP8IVb4X4nCLUCJ9Dx	\N	Second & Sebring	Of Mice & Men	313neyxbfwxtbi2t52gjvliqxisa	2024-05-12 15:32:13+00	\N	metalcore, post-hardcore, screamo, metal
4297	59	6uHzLhCAhDwp8owMGmH07f	\N	Nothing	Phill Loud	313neyxbfwxtbi2t52gjvliqxisa	2024-05-26 07:59:20+00	\N	indie
4284	59	7BRD7x5pt8Lqa1eGYC4dzj	\N	CHIHIRO	Billie Eilish	1qzcdqlwqtm8lnthmvh2a70p9	2024-05-22 17:34:08+00	\N	pop
4320	60	76XijXDDDUZI5P8PKQ0uUy	\N	Set Me Free	Sublab	1qzcdqlwqtm8lnthmvh2a70p9	2024-05-19 08:01:52+00	\N	chillstep, witch house
4323	61	0Z9MJLeqOzG1MxBSsHtYNR	\N	Мама бы...	Марлины	313neyxbfwxtbi2t52gjvliqxisa	2024-04-24 05:14:39+00	\N	pop
4387	63	07zFD4roTLWR2vHiKrO8Ip	\N	Melody Maker	The Kooks	31ghi62vkgnlb4wqr6muaisx7ldi	2024-04-05 12:59:30+00	\N	indie, indie rock
4335	61	0kS5HslhICWE9ASbOzyLxl	\N	В обмороке	Banev!	31ghi62vkgnlb4wqr6muaisx7ldi	2024-05-01 08:50:56+00	\N	rap
4364	62	0dZTEB9raQkSRtZkSzFx0h	\N	Death Wish (with Micah Martin)	RIOT, Micah Martin	313neyxbfwxtbi2t52gjvliqxisa	2024-04-15 10:45:54+00	\N	dubstep, deathstep, riddim
4334	61	11IvpUALm0Canz1N6JBGEJ	\N	Uyku	Son Feci Bisiklet	31ghi62vkgnlb4wqr6muaisx7ldi	2024-05-01 08:46:25+00	\N	indie
4369	62	0vhxITfBNsA3nBPbu7lRhP	\N	Seek Love (On The Beach)	Alok, Tazi, Samuele Sartini, Amanda Wilson, YORK	1qzcdqlwqtm8lnthmvh2a70p9	2024-04-15 12:39:52+00	\N	brazilian bass, electronic, slap house, electro house
4355	62	1KUWoSp6srOAAoezcdLOvz	\N	Bubblehead	Coubo	31ghi62vkgnlb4wqr6muaisx7ldi	2024-04-12 13:17:06+00	\N	electronic
4363	62	17tHDQDFZop8qnVd36M46N	\N	Dark Signs	Will Ramos, Nik Nocturnal	313neyxbfwxtbi2t52gjvliqxisa	2024-04-15 10:45:48+00	\N	deathcore, metalcore
4357	62	1DoFiO1x9P3Ls2LVI40qVj	\N	Don't Tell Me	Arcando	1qzcdqlwqtm8lnthmvh2a70p9	2024-04-14 17:15:26+00	\N	drum and bass
4356	62	1gIBHkEjBobQ2xSeh9zJ3b	\N	La bohème	Дора	1qzcdqlwqtm8lnthmvh2a70p9	2024-04-14 16:19:34+00	\N	folk
4360	62	20G0Ssv80XZ3qziTdMcd2Q	\N	Тайна третьей планеты	Братство Атома	313neyxbfwxtbi2t52gjvliqxisa	2024-04-15 10:45:39+00	\N	soundtrack
4393	63	1iOQmZULzzkDN1hQZNoDii	\N	オレンジ	7!!	1qzcdqlwqtm8lnthmvh2a70p9	2024-04-06 21:42:09+00	\N	anime, j-pop
4386	63	1jecO8NeYLsVWVptITz4c1	\N	Tú	maye	31ghi62vkgnlb4wqr6muaisx7ldi	2024-04-05 12:57:41+00	\N	latin indie, latin alternative
4372	62	3cXkBtO5htBKiM05H0PQ7F	\N	Aztec Death Whistle	MISSIO	1qzcdqlwqtm8lnthmvh2a70p9	2024-04-16 08:14:50+00	\N	alternative rock
4333	61	2Lumsra3kuU61wXkEKzKaK	\N	Disco	Surf Curse	31ghi62vkgnlb4wqr6muaisx7ldi	2024-05-01 08:43:14+00	\N	indie
4339	61	2XdcUAsMCuNMaWLmXIhdjW	\N	Dead Butterflies	Architects	31pd6hnytykuevog22xwj5yn2qjy	2024-05-02 07:34:03+00	\N	metalcore, djent, metal, mathcore, post-hardcore, deathcore
4376	63	2o0hVSbnkdvDDKKVNaUxnB	\N	La bohème	Charles Aznavour	1qzcdqlwqtm8lnthmvh2a70p9	2024-04-02 20:52:31+00	\N	chanson, variété française, french jazz
4385	63	2qtr6hH2mkhpV1yIY8i2la	\N	Paraíso	Monogem	31ghi62vkgnlb4wqr6muaisx7ldi	2024-04-05 12:57:11+00	\N	latin indie
4388	63	3d4Uf0RSlKsYQ78xNArvOv	\N	Forest of Cigarettes	Mòn	31ghi62vkgnlb4wqr6muaisx7ldi	2024-04-05 13:01:04+00	\N	shoegaze
4347	61	3zWIZUWyk7R6ZYQQ8ypcvl	\N	МЫ РАЗБИВАЕМСЯ	Zemfira	31pd6hnytykuevog22xwj5yn2qjy	2024-05-04 23:24:47+00	\N	pop
4374	63	3haoa5qBpUIqTfN474z4RX	\N	LEAVING ME	ROONIN, STRLGHT	1qzcdqlwqtm8lnthmvh2a70p9	2024-03-31 20:26:34+00	\N	phonk, drift phonk
4384	63	3l6779YqHSAtPR7cKhNP47	\N	Magnolias for Ever	Emma Peters, Leo Kodian	31pd6hnytykuevog22xwj5yn2qjy	2024-04-05 10:04:41+00	\N	french pop, french house
4343	61	3lPn81PFyKvXiyHhlkwkQ4	\N	Doomed	Bring Me The Horizon	313neyxbfwxtbi2t52gjvliqxisa	2024-05-02 14:40:18+00	\N	metalcore, emo, rock, screamo, post-hardcore
4390	63	41QD3JUCrI1H3SRolaBtln	\N	Я иду по городу	WASSSUP	31ghi62vkgnlb4wqr6muaisx7ldi	2024-04-05 13:03:14+00	\N	hip hop
4359	62	41z250UaqqUJuXCqlLwMoM	\N	Доширак	Екатерина Яшникова	313neyxbfwxtbi2t52gjvliqxisa	2024-04-15 10:45:35+00	\N	pop
4389	63	48lxT5qJF0yYyf2z4wB4xW	\N	Pedro	Jaxomy, Agatino Romero, Raffaella Carrà	31ghi62vkgnlb4wqr6muaisx7ldi	2024-04-05 13:02:06+00	\N	house
4338	61	4NOZ35Dhucr6UlVyLOtktd	\N	Dangerous	Kardinal Offishall, Akon	31pd6hnytykuevog22xwj5yn2qjy	2024-05-01 21:56:26+00	\N	r&b
4391	63	4hNR0rrdcxuxS4TwguWy7b	\N	sadplanet	SIXxFIGURES	313neyxbfwxtbi2t52gjvliqxisa	2024-04-05 17:47:23+00	\N	electronic
4380	63	4aB9rcFSPfZd9X41rfe7CS	\N	Killer	Tommy Saint	31pd6hnytykuevog22xwj5yn2qjy	2024-04-04 11:50:06+00	\N	dark r&b, uk r&b
4375	63	4y9cpHKde7rke5CtNF7P3f	\N	Сердце	passmurny	31pd6hnytykuevog22xwj5yn2qjy	2024-04-01 22:22:42+00	\N	hip hop
4362	62	4iAADOBedsspd11DUWrVQC	\N	Now We Are Free	Maor Levi, Elysian, Emma Hewitt, Ilan Bluestone	313neyxbfwxtbi2t52gjvliqxisa	2024-04-15 10:45:45+00	\N	trance, progressive trance, progressive house
4361	62	4va4ODr5SjX65A78o60dCc	\N	Отпусти	At The Ruins	313neyxbfwxtbi2t52gjvliqxisa	2024-04-15 10:45:41+00	\N	metalcore
4377	63	5eEgVC3k662YA6P6pcHnpP	\N	Kitoj planetoj	Matto, Ciūnys	1qzcdqlwqtm8lnthmvh2a70p9	2024-04-03 19:14:09+00	\N	folk
4342	61	5Af61V9TpYJEtXIwyHxuqs	\N	If You Love Me Now	Slushii	1qzcdqlwqtm8lnthmvh2a70p9	2024-05-02 13:41:28+00	\N	future bass
4346	61	5KReHDo8W8w9bKTY3KxPy3	\N	Let Her Go	Passenger	31pd6hnytykuevog22xwj5yn2qjy	2024-05-04 19:05:57+00	\N	folk pop
4366	62	5WQOAH4kOFb7wusGWiCLZG	\N	No Place Like Home	FLAKE	313neyxbfwxtbi2t52gjvliqxisa	2024-04-15 10:46:18+00	\N	shoegaze
4382	63	69yVorve3CSUgza89ZxLeS	\N	Solo noi	Toto Cutugno	31pd6hnytykuevog22xwj5yn2qjy	2024-04-04 20:04:52+00	\N	latin
4352	62	5s92i3a0fN5MWMlq1Zn9Nh	\N	Wanli万里	HYUKOH	31ghi62vkgnlb4wqr6muaisx7ldi	2024-04-12 13:13:50+00	\N	k-rock, k-ballad
4367	62	65VHUZPZKgaG4SJVRkBPzn	\N	Curse	Architects	313neyxbfwxtbi2t52gjvliqxisa	2024-04-15 10:46:21+00	\N	metalcore, djent, metal, mathcore, post-hardcore, deathcore
4351	62	67UG5eRm0wRjWI3rbX9l75	\N	Не тает иней	DenDerty	31ghi62vkgnlb4wqr6muaisx7ldi	2024-04-12 13:11:20+00	\N	witch house
4368	62	6WbnBnJNGxdNOwwNYI37O0	\N	Good Love - Reinier Zonneveld Remix	Hannah Laing, RoRo, Reinier Zonneveld	1qzcdqlwqtm8lnthmvh2a70p9	2024-04-15 12:18:26+00	\N	house
4345	61	6NTU7JpRFljZ8x2QDQ7pyr	\N	Makes Us Come Alive	Universal Production Music	1qzcdqlwqtm8lnthmvh2a70p9	2024-05-04 14:59:09+00	\N	christian jazz
4383	63	776AftMmFFAWUIEAb3lHhw	\N	ZITTI E BUONI	Måneskin	31pd6hnytykuevog22xwj5yn2qjy	2024-04-04 20:38:04+00	\N	rock
4392	63	6g2BiiVQqY5v1S4HIrM54F	\N	Tuyo (Narcos Theme) [Extended Version] - A Netflix Original Series Soundtrack	Rodrigo Amarante	31pd6hnytykuevog22xwj5yn2qjy	2024-04-06 17:32:59+00	\N	new mpb
4340	61	6gfUOprNMeD8amncMOSFl0	\N	Misery	Memphis May Fire	31pd6hnytykuevog22xwj5yn2qjy	2024-05-02 13:12:43+00	\N	metalcore, post-hardcore, screamo
4365	62	6zzJDk7dWyJNX4gyTLuMly	\N	Numb	Repiet	313neyxbfwxtbi2t52gjvliqxisa	2024-04-15 10:46:15+00	\N	stutter house
4350	62	70LxcXcJ6ugZzDl5UvSvR5	\N	Soaked Toad's Smoke	Zhaba	31ghi62vkgnlb4wqr6muaisx7ldi	2024-04-12 13:10:59+00	\N	stoner metal, sludge metal, stoner rock, drone
4353	62	75gPHy2tyXcYQ2tnsX3I2J	\N	Revenge	Yusei	31ghi62vkgnlb4wqr6muaisx7ldi	2024-04-12 13:14:52+00	\N	lo-fi
4379	63	0Z375dvneNK9D6Bc5JnjhF	\N	Leave	Kingfishr	31pd6hnytykuevog22xwj5yn2qjy	2024-04-03 21:59:23+00	\N	indie
4418	64	1lqDxWIWoeNQ0BjNjY85z7	\N	Где-то там	The Hatters, TRITIA	31pd6hnytykuevog22xwj5yn2qjy	2024-03-29 00:19:54+00	\N	indie
4451	65	1FzbOPWCZiNxnLjAhY1jAR	\N	In And Out Of Love	Armin van Buuren, Sharon Den Adel	31pd6hnytykuevog22xwj5yn2qjy	2024-03-23 11:02:30+00	\N	trance, progressive trance, progressive house, electronica, edm
4446	65	1IvkQIAPKKyF2FtVSeuv3F	\N	Whatever It Takes (feat. Toli Wild)	Abyss, Watching Me, Toli Wild	313neyxbfwxtbi2t52gjvliqxisa	2024-03-21 14:01:32+00	\N	post-hardcore, metalcore, melodic hardcore
4395	64	1Zp65ER4CfD0a7ylF87Z1F	\N	Training Season - Acoustic Version	Dua Lipa	31pd6hnytykuevog22xwj5yn2qjy	2024-03-24 13:27:12+00	\N	pop
4414	64	1rzlZcHjV4JqQtQgD3rC03	\N	Романс	Диктофон	31pd6hnytykuevog22xwj5yn2qjy	2024-03-27 13:03:45+00	\N	classical
4404	64	1zXv6MYOAyjgMA0iPypPkO	\N	Пожары	Xolidayboy	313neyxbfwxtbi2t52gjvliqxisa	2024-03-24 13:29:06+00	\N	rap
4425	65	2M7t0ioJnwB26A6eituILc	\N	I Hate This Part - Digital Dog Remix - Club Edit	The Pussycat Dolls	313neyxbfwxtbi2t52gjvliqxisa	2024-03-17 22:55:40+00	\N	pop
4445	65	2L1rEX7dDCa4a4SZTLzyMp	\N	Бабкибабкибабки	Wildways	313neyxbfwxtbi2t52gjvliqxisa	2024-03-21 14:00:03+00	\N	metalcore, post-hardcore
4410	64	2TBuD9xEn2o1RTLtegzAfB	\N	Дура	клуб любителей музыки	1qzcdqlwqtm8lnthmvh2a70p9	2024-03-25 19:00:03+00	\N	pop
4449	65	2xvNOftzz4VMyscM40yY35	\N	Crazy	Daniela Andrade	1qzcdqlwqtm8lnthmvh2a70p9	2024-03-22 13:30:31+00	\N	r&b
4444	65	2gsFRyKyll43mr06HPI1hT	\N	Другие	[AMATORY]	313neyxbfwxtbi2t52gjvliqxisa	2024-03-21 13:59:30+00	\N	metalcore
4450	65	2kwQfbbjuZWat5YKnVnOcy	\N	Easy	3LAU, XIRA	31pd6hnytykuevog22xwj5yn2qjy	2024-03-23 10:50:28+00	\N	edm
4398	64	3DoKepDy2hXhtWizxMszJS	\N	Поезда	Женя Трофимов, Комната культуры	313neyxbfwxtbi2t52gjvliqxisa	2024-03-24 13:28:13+00	\N	pop
4401	64	2zuNSUCK1skLbhwL56i0KC	\N	Love Me Not	Set for Tomorrow	313neyxbfwxtbi2t52gjvliqxisa	2024-03-24 13:28:43+00	\N	metalcore
4432	65	3MjUd5urM8tcA6mBrDtQkE	\N	We Lose Control - From "American Satan"	The Relentless	313neyxbfwxtbi2t52gjvliqxisa	2024-03-21 07:09:51+00	\N	soundtrack
4442	65	3JcvpTfI64SmXxUl7XUvQI	\N	Waltzing Back	No Vacation	31pd6hnytykuevog22xwj5yn2qjy	2024-03-21 11:35:34+00	\N	bedroom pop, dream pop
4431	65	3nbOdp5Ew7kdvDH7efDfY9	\N	Фото на память	The OM	313neyxbfwxtbi2t52gjvliqxisa	2024-03-20 23:22:13+00	\N	indie
4405	64	3NfrWuKVXOcO9ieVAKu1gm	\N	MAINICHI	MIYACHI	31ghi62vkgnlb4wqr6muaisx7ldi	2024-03-24 13:29:08+00	\N	j-rap, j-r&b
4416	64	3fonAuTvuI5KMcmnueLAPq	\N	Straight and Narrow	Sam Barber	31pd6hnytykuevog22xwj5yn2qjy	2024-03-28 10:01:05+00	\N	country
4408	64	4236VKkM5ZFpRMsWCFbQT6	\N	Rosa Dream	Multiverse, Atomic Heart	1qzcdqlwqtm8lnthmvh2a70p9	2024-03-25 15:01:38+00	\N	soundtrack
4400	64	4AFxg2imCuSf5ad2dCbCKF	\N	Чувства	Animal Jazz	313neyxbfwxtbi2t52gjvliqxisa	2024-03-24 13:28:39+00	\N	rock
4417	64	49ylH81Y53wUOlTHqXK1J2	\N	The Safety of Disbelief	Light The Torch	31pd6hnytykuevog22xwj5yn2qjy	2024-03-28 16:44:56+00	\N	metalcore, metal
4429	65	4cQrSREMqBSvJ8ZzBZjVb8	\N	Mile High (feat. Travis Scott & Metro Boomin)	James Blake, Travis Scott, Metro Boomin	31pd6hnytykuevog22xwj5yn2qjy	2024-03-19 15:15:49+00	\N	hip hop
4412	64	4EmH2iRucAgCOnhuJRotUi	\N	Drifting	Tiësto, Poppy Baskcomb	31pd6hnytykuevog22xwj5yn2qjy	2024-03-26 17:04:44+00	\N	edm, trance, big room, house
4436	65	4RkQzVNxEt6JwOXCWolXsr	\N	I'm a Kid	Jadu Heart	31ghi62vkgnlb4wqr6muaisx7ldi	2024-03-21 08:32:19+00	\N	indie soul
4424	65	4pEU0NT64oiem9lDT7nuJn	\N	Running In Circles	Dead Poet Society	31pd6hnytykuevog22xwj5yn2qjy	2024-03-17 14:01:41+00	\N	alternative rock
4413	64	4s3GDQG5G3b6S8RoEoG6HA	\N	Guantanama	Nizkiz	313neyxbfwxtbi2t52gjvliqxisa	2024-03-27 06:06:22+00	\N	latin
4439	65	4vgU9MGJwhgBEtlO8mMN49	\N	Like You Do	Joji	31ghi62vkgnlb4wqr6muaisx7ldi	2024-03-21 08:37:57+00	\N	r&b
4403	64	4taZ23hnXd59FeBaGhuapi	\N	Laserbeam - ÆON:MODE Remix	Ray Volpe, Blanke, ÆON:MODE	313neyxbfwxtbi2t52gjvliqxisa	2024-03-24 13:29:02+00	\N	dubstep, riddim, deathstep, melodic bass, bass music, edm
4422	64	51Grh1RyUDcMBbpuyUIUHI	\N	rises the moon	Liana Flores	31ghi62vkgnlb4wqr6muaisx7ldi	2024-03-31 06:49:38+00	\N	folk
4430	65	5M5rVhbmK4nlgLyVGAyEHf	\N	Вояджер-1	Noize MC	31pd6hnytykuevog22xwj5yn2qjy	2024-03-20 09:31:00+00	\N	rap
4402	64	580dIgtL1JbVTt5eY9o9w8	\N	SCARLET - Memories Reimagined	Her Last Sight	313neyxbfwxtbi2t52gjvliqxisa	2024-03-24 13:28:50+00	\N	metalcore
4415	64	58U2OeaIAkQ6scuGNVazuT	\N	Made in Romania	Ionut Cercel	1qzcdqlwqtm8lnthmvh2a70p9	2024-03-27 22:54:40+00	\N	manele
4407	64	6GBAVqwCeP46V04yEcHjTz	\N	Нокаут	БАЗАР, Обстоятельства	31pd6hnytykuevog22xwj5yn2qjy	2024-03-24 23:54:10+00	\N	rap
4396	64	6JIC3hbC28JZKZ8AlAqX8h	\N	Cold Heart - PNAU Remix	Elton John, Dua Lipa, PNAU	31pd6hnytykuevog22xwj5yn2qjy	2024-03-24 16:00:57+00	\N	house
4426	65	6usohdchdzW9oML7VC4Uhk	\N	Lose Control	Teddy Swims	313neyxbfwxtbi2t52gjvliqxisa	2024-03-18 14:14:31+00	\N	r&b
4434	65	6SeFPYWv9lIlSWanyEDYf5	\N	Losing My Life	Falling In Reverse	313neyxbfwxtbi2t52gjvliqxisa	2024-03-21 07:38:08+00	\N	emo, rap metal
4406	64	6bYhzxKWhBm3QP9EdhT1uK	\N	Delusional	Breaking In A Sequence	313neyxbfwxtbi2t52gjvliqxisa	2024-03-24 13:29:14+00	\N	nu metal
4448	65	6sFKNino4jGUjCeq0NBdp8	\N	Leel Lost (Reloaded)	Relanium, Deen West	1qzcdqlwqtm8lnthmvh2a70p9	2024-03-22 13:27:31+00	\N	future house, g-house
4435	65	7JrwRcbAj13sNPEGShBD9g	\N	Cosurmyne	Jungle	31ghi62vkgnlb4wqr6muaisx7ldi	2024-03-21 08:31:08+00	\N	drum and bass
4443	65	74qKLdiiTnXNqh2Co21RlJ	\N	Other Side	AVAION, BUNT.	313neyxbfwxtbi2t52gjvliqxisa	2024-03-21 13:55:11+00	\N	stutter house, deep house
4437	65	7brQHA2CgQpcMBiOlfiXYb	\N	Afraid	The Neighbourhood	31ghi62vkgnlb4wqr6muaisx7ldi	2024-03-21 08:35:44+00	\N	alternative rock
4399	64	7LLTI0Fq0p8y2sy4qspawY	\N	Вечно Молодой (Phonk Remix)	Lastfragment	313neyxbfwxtbi2t52gjvliqxisa	2024-03-24 13:28:18+00	\N	phonk, drift phonk
4397	64	7kAgV8AQVH2tr3AisKzwxh	\N	Девка из сна	netonem	313neyxbfwxtbi2t52gjvliqxisa	2024-03-24 13:28:04+00	\N	indie
4420	64	7pduiUjOatl9Adgne5usEb	\N	Мой ненаглядный	Tatiana Bulanova	31pd6hnytykuevog22xwj5yn2qjy	2024-03-29 20:16:40+00	\N	pop
4440	65	7uJO3vYc0QVxtE5vW8Pi0U	\N	Месяц	Palina	31ghi62vkgnlb4wqr6muaisx7ldi	2024-03-21 08:41:48+00	\N	pop
4409	64	7z2WUgi4NYyXD1odDaaQTQ	\N	Popstar shit.	The Caracal Project, Eugénie	1qzcdqlwqtm8lnthmvh2a70p9	2024-03-25 16:45:06+00	\N	drum and bass, liquid funk, drumstep
4438	65	1A3tuE6ti9qoZDwB3LB0t2	\N	I Think I Like When It Rains	WILLIS	31ghi62vkgnlb4wqr6muaisx7ldi	2024-03-21 08:36:46+00	\N	indie
4464	66	0Hxib9fV4wTcXQeW4HtoN5	\N	Piepi Piepi Papa Papa	GPF	313neyxbfwxtbi2t52gjvliqxisa	2024-03-11 14:17:52+00	\N	frenchcore, hardcore, speedcore, hardstyle, hardcore techno, gabber
4509	67	0sTlGEld0h8kIPZaKDYUf4	\N	Notion	The Rare Occasions	31ghi62vkgnlb4wqr6muaisx7ldi	2024-03-04 12:56:37+00	\N	indie
4511	67	13obDQRlMWHR7UVRyCYUld	\N	Prodigal Son	Rationale	31pd6hnytykuevog22xwj5yn2qjy	2024-03-04 20:47:34+00	\N	indie
4510	67	19i81uYQz4r2GRyLVvwGLM	\N	В очереди	hmyrov	31ghi62vkgnlb4wqr6muaisx7ldi	2024-03-04 13:00:01+00	\N	pop
4453	65	1nZHWDoDoP0Dtgup8jTW2u	\N	Пыяла	AIGEL	1qzcdqlwqtm8lnthmvh2a70p9	2024-03-23 12:53:19+00	\N	hip hop
4487	66	1BO9znQb8BbJ5W8KPAqgWE	\N	Everything I Do Is For You	Amira Elfeky	31pd6hnytykuevog22xwj5yn2qjy	2024-03-15 17:30:11+00	\N	shoegaze
4481	66	1MVqeIAwhD4T44AKVkIfic	\N	leavemealone	Fred again.., Baby Keem	31ghi62vkgnlb4wqr6muaisx7ldi	2024-03-13 14:28:20+00	\N	stutter house, house, edm
4470	66	2629kqdJQhPMqXfWz9akjF	\N	Dance Up	TumaniYO, MiyaGi & Endspiel	31pd6hnytykuevog22xwj5yn2qjy	2024-03-13 07:50:26+00	\N	hip hop
4462	66	2AogRMqARWyUP7VQ3gmSoY	\N	Can't Fight The Moonlight	LeAnn Rimes	1qzcdqlwqtm8lnthmvh2a70p9	2024-03-10 21:48:10+00	\N	pop
4506	67	2QtAqVz0MYUS9keo4oD0xx	\N	Стоял, курил	БАЗАР	31ghi62vkgnlb4wqr6muaisx7ldi	2024-03-04 12:49:16+00	\N	hip hop
4472	66	2axhadiWTdbV5NATnj5sWD	\N	Сказки	Husky	31ghi62vkgnlb4wqr6muaisx7ldi	2024-03-13 14:04:40+00	\N	rap
4484	66	2Y40huo5ewaKYxsFintYtF	\N	Heaven and Hell	Kanye West	31pd6hnytykuevog22xwj5yn2qjy	2024-03-15 09:00:01+00	\N	rap
4463	66	30lfe6fpEYbdw0LQUjrrA5	\N	Закрытый космос	Kasta, Хамиль, Змей	1qzcdqlwqtm8lnthmvh2a70p9	2024-03-11 01:00:41+00	\N	hip hop
4459	65	2jAaDaQ01dk74X4njfkXP3	\N	On My Mind - Purple Disco Machine Remix	Diplo, SIDEPIECE, Purple Disco Machine	31pd6hnytykuevog22xwj5yn2qjy	2024-03-23 23:14:52+00	\N	moombahton
4486	66	2liAurQDvBwqRfJCfLVkCQ	\N	Take the World	She Wants Revenge	31pd6hnytykuevog22xwj5yn2qjy	2024-03-15 17:15:46+00	\N	darkwave, gothic rock
4458	65	32vvqilBWPwxfux6VtcGjD	\N	Never Be Alone - Orchestral Acoustic	Becky Hill	1qzcdqlwqtm8lnthmvh2a70p9	2024-03-23 19:33:55+00	\N	downtempo
4460	65	3HDpCX0mHvIrKxeu2U2FZB	\N	Love	Mason Wright	1qzcdqlwqtm8lnthmvh2a70p9	2024-03-24 01:05:09+00	\N	pop
4489	66	3E9vgX9znf0o5m2IwKNCAj	\N	The Black	Imminence	1qzcdqlwqtm8lnthmvh2a70p9	2024-03-15 21:26:03+00	\N	metalcore, metal
4477	66	3jHdKaLCkuNEkWcLVmQPCX	\N	BEST INTEREST	Tyler, The Creator	31ghi62vkgnlb4wqr6muaisx7ldi	2024-03-13 14:10:16+00	\N	hip hop
4500	67	3kDbVPKLPjnzbQRLMJFk1L	\N	Rick James	Markul, ANIKV	1qzcdqlwqtm8lnthmvh2a70p9	2024-03-03 19:12:22+00	\N	rap
4493	66	3qdtOI4KHrYS4drA8PLajG	\N	Play	Justin Timberlake	31pd6hnytykuevog22xwj5yn2qjy	2024-03-16 08:34:17+00	\N	pop
4483	66	41I1iQyv0Z9afoWNVsn9td	\N	Surfer	LATEXFAUNA	31pd6hnytykuevog22xwj5yn2qjy	2024-03-14 14:04:08+00	\N	indie
4512	67	4J3I4jpAtNjsclcs99jzeF	\N	Cracker Island (feat. Thundercat)	Gorillaz, Thundercat	31ghi62vkgnlb4wqr6muaisx7ldi	2024-03-04 13:03:59+00	\N	alternative rock
4490	66	4QbCUutUlQDSBS4mtVOuZI	\N	Doomsday Pt. 2 (with Eminem)	Lyrical Lemonade, Eminem	31pd6hnytykuevog22xwj5yn2qjy	2024-03-15 23:26:09+00	\N	rap
4480	66	4SnuG111QPmgwRmlwhJ4Mg	\N	Hold Me	Lavern	31ghi62vkgnlb4wqr6muaisx7ldi	2024-03-13 14:26:33+00	\N	stutter house
4467	66	527D034h8WFtVDOBO6GAN5	\N	Последняя Любовь	MORGENSHTERN	31pd6hnytykuevog22xwj5yn2qjy	2024-03-11 16:18:11+00	\N	rap
4503	67	5ewsU50oLhaqC7GDR1gj0K	\N	Black Angel	Instrumental Core	313neyxbfwxtbi2t52gjvliqxisa	2024-03-04 01:01:15+00	\N	electronic
4471	66	56Vb42jIxIHavORUJhMY6D	\N	Loli Mou	Tobi King	1qzcdqlwqtm8lnthmvh2a70p9	2024-03-13 08:15:41+00	\N	disco polo
4485	66	5FkJHVudUByVjanCqFXRql	\N	After Dark	Mr.Kitty	31pd6hnytykuevog22xwj5yn2qjy	2024-03-15 09:00:34+00	\N	witch house, darkwave
4465	66	5Ihd9HrPvOADyVoonH9ZjB	\N	Un-Break My Heart	Toni Braxton	313neyxbfwxtbi2t52gjvliqxisa	2024-03-11 15:02:01+00	\N	r&b
4505	67	5YToBG3qALkdce8bCiY1UB	\N	holding on	Nevertel	313neyxbfwxtbi2t52gjvliqxisa	2024-03-04 07:56:19+00	\N	metalcore
4455	65	6pkh5va0Hv9YnQ3FXOt1Vj	\N	Listen to Your Heart	MiyaGi & Endspiel	31pd6hnytykuevog22xwj5yn2qjy	2024-03-23 16:39:01+00	\N	rap
4475	66	5hM5arv9KDbCHS0k9uqwjr	\N	Borderline	Tame Impala	31ghi62vkgnlb4wqr6muaisx7ldi	2024-03-13 14:09:17+00	\N	neo-psychedelic, indie
4494	66	6ijsUwucxrAnSmVj5xwiFT	\N	Exile - The Forgotten Remix	Virtual Riot, The Kids, The Forgotten	313neyxbfwxtbi2t52gjvliqxisa	2024-03-16 11:13:41+00	\N	dubstep, riddim, deathstep, bass music, future bass, edm, dub, drumstep
4474	66	7EBWacSQyCAnBSwFC7wECY	\N	Любопытно	Диктофон	31ghi62vkgnlb4wqr6muaisx7ldi	2024-03-13 14:06:52+00	\N	indie
4456	65	6yatVQEJpsUT3j5jXnEVui	\N	Герда	Lida	1qzcdqlwqtm8lnthmvh2a70p9	2024-03-23 17:22:47+00	\N	happy hardcore
4504	67	7aZDcmt34eouhqw29aMR91	\N	Skin and Bones	David Kushner	313neyxbfwxtbi2t52gjvliqxisa	2024-03-04 06:29:24+00	\N	indie
4473	66	7tHO94I3dqhkFXG9PvRYRG	\N	Август	Видеокассета Твоих Родителей	31ghi62vkgnlb4wqr6muaisx7ldi	2024-03-13 14:06:07+00	\N	indie
4461	66	7amAPVyKhR6tMjv5hkDQaE	\N	Working On It	Destroyers, FM-3	1qzcdqlwqtm8lnthmvh2a70p9	2024-03-10 17:49:50+00	\N	breakbeat, big beat, uk garage
4466	66	7rCHmESfvRcjqaU7My7ge8	\N	I'm Not Jesus - International Version	Apocalyptica, Corey Taylor	313neyxbfwxtbi2t52gjvliqxisa	2024-03-11 15:06:18+00	\N	symphonic metal
4478	66	7w87IxuO7BDcJ3YUqCyMTT	\N	Pumped Up Kicks	Foster The People	31ghi62vkgnlb4wqr6muaisx7ldi	2024-03-13 14:11:25+00	\N	indie
4476	66	7yNf9YjeO5JXUE3JEBgnYc	\N	Babydoll	Dominic Fike	31ghi62vkgnlb4wqr6muaisx7ldi	2024-03-13 14:09:46+00	\N	pop
4468	66	7zHe3QFT8s36Pa4bSkUHoE	\N	Круги на воде	Slot	313neyxbfwxtbi2t52gjvliqxisa	2024-03-12 05:23:43+00	\N	rock
4501	67	7zTf711oat80jqaki61LeJ	\N	Higher	Mike Mago, Leon Lour	1qzcdqlwqtm8lnthmvh2a70p9	2024-03-03 19:12:48+00	\N	future house
4535	68	0fv2KH6hac06J86hBUTcSf	\N	NEW MAGIC WAND	Tyler, The Creator	31ghi62vkgnlb4wqr6muaisx7ldi	2024-02-26 15:26:19+00	\N	rap
4518	67	0vbtURX4qv1l7besfwmnD8	\N	I Took A Pill In Ibiza - Seeb Remix	Mike Posner, Seeb	31pd6hnytykuevog22xwj5yn2qjy	2024-03-07 09:09:35+00	\N	house
4534	68	0oA9wBGDY4uyILLg4GymWP	\N	Tom's Diner	AnnenMayKantereit, Giant Rooks	31ghi62vkgnlb4wqr6muaisx7ldi	2024-02-26 15:25:04+00	\N	german indie, german pop, german indie pop
4539	68	12iNagB2Giw9Xwj1BdGbLq	\N	MOON MAN SHIT	Kid Cudi	31pd6hnytykuevog22xwj5yn2qjy	2024-02-28 13:25:49+00	\N	hip hop
4513	67	1XI6TNyuF5bFtvfUMGgyu7	\N	Лесник	Эпидемия, Смешарики	313neyxbfwxtbi2t52gjvliqxisa	2024-03-04 15:57:48+00	\N	soundtrack
4551	68	1HBygQA14S50u7foog4NRb	\N	Face Your Demons	Venjent	313neyxbfwxtbi2t52gjvliqxisa	2024-03-01 12:26:22+00	\N	drum and bass
4516	67	1JzH2IS7bVWpMkNIJqywaB	\N	Where Are You Now	Lost Frequencies, Calum Scott	31pd6hnytykuevog22xwj5yn2qjy	2024-03-05 14:47:33+00	\N	tropical house
4569	69	1hE8qC9NY9fWILjtLbEAKo	\N	Жить как я живу	Skryptonite	31pd6hnytykuevog22xwj5yn2qjy	2024-02-19 17:56:35+00	\N	rap
4530	68	1aOdoa5EDsjY7zwSVR1ah6	\N	Цветы	Wildways	313neyxbfwxtbi2t52gjvliqxisa	2024-02-25 16:08:32+00	\N	metalcore, post-hardcore
4517	67	2XKjhJbd57Jiqdy5SCZNWh	\N	Call my name	GRAHAM, Henrik	313neyxbfwxtbi2t52gjvliqxisa	2024-03-06 23:23:59+00	\N	electronic
4529	68	1rAzOr3zpUDRtN2zsqGHiG	\N	Friendly Fire	Linkin Park	313neyxbfwxtbi2t52gjvliqxisa	2024-02-25 16:02:32+00	\N	nu metal, rap metal, rock, alternative metal
4543	68	1x7Ts6pnwIwOOo0vSMNndW	\N	Her	Her	31pd6hnytykuevog22xwj5yn2qjy	2024-02-28 13:51:57+00	\N	french indie pop
4546	68	2tSOz2c3qqs8jOdlyMvHww	\N	мальчик	кис-кис	1qzcdqlwqtm8lnthmvh2a70p9	2024-02-28 19:08:09+00	\N	pop
4547	68	2kPFdhHw0dj8MRIp0X28uY	\N	Секс	Lida	1qzcdqlwqtm8lnthmvh2a70p9	2024-02-28 19:09:11+00	\N	happy hardcore
4563	69	2smib4Evo3UqyRdI2tYnNT	\N	Gave My Heart	Ali Bakgor	313neyxbfwxtbi2t52gjvliqxisa	2024-02-19 02:13:53+00	\N	melodic techno, deep house
4540	68	4mryAmjbNJS5KpBSpYfams	\N	Leave Forever	Hayes & Y	31pd6hnytykuevog22xwj5yn2qjy	2024-02-28 13:26:44+00	\N	pop
4519	67	3RMl80oxS9NLPFTgfma7zz	\N	Rapture	Tropics	31pd6hnytykuevog22xwj5yn2qjy	2024-03-07 09:39:00+00	\N	chillwave
4548	68	46sUbopiA2fh7rFo23r9YC	\N	I Know	Maor Levi	313neyxbfwxtbi2t52gjvliqxisa	2024-02-29 04:26:46+00	\N	trance, progressive trance, progressive house
4538	68	4ZEEcEMGjkWOfZNBcIB9yE	\N	War	Edwin Starr	313neyxbfwxtbi2t52gjvliqxisa	2024-02-28 06:04:09+00	\N	northern soul, motown, classic soul
4542	68	4lejz024CsCP6S5kPD6Upb	\N	Lovesick	Maroon 5	31pd6hnytykuevog22xwj5yn2qjy	2024-02-28 13:39:16+00	\N	pop
4528	68	4vjisL23cNSLcvtQgpFJEu	\N	Овощи	дуучимээ	31ghi62vkgnlb4wqr6muaisx7ldi	2024-02-25 14:30:33+00	\N	hip hop
4515	67	4qUe6Wx6E32tHpaJeFetY9	\N	Crossfade	HXVRMXN	313neyxbfwxtbi2t52gjvliqxisa	2024-03-04 23:26:52+00	\N	drift phonk, phonk
4566	69	4z1Q4M9FWDBP2NvpIshuVB	\N	Можешь лететь (Remastered)	Animal Jazz	313neyxbfwxtbi2t52gjvliqxisa	2024-02-19 13:46:50+00	\N	indie
4544	68	52eIcoLUM25zbQupAZYoFh	\N	redrum	21 Savage	31pd6hnytykuevog22xwj5yn2qjy	2024-02-28 17:29:23+00	\N	rap
4527	68	5FRamVnYaLvmu1IoD1OGSJ	\N	детский сад	другдиджея, Нотэбёрд	31ghi62vkgnlb4wqr6muaisx7ldi	2024-02-25 14:28:25+00	\N	electronic
4522	67	59WN2psjkt1tyaxjspN8fp	\N	Killing In The Name	Rage Against The Machine	31pd6hnytykuevog22xwj5yn2qjy	2024-03-07 12:57:40+00	\N	rap metal, rap rock, alternative metal, nu metal
4549	68	5Wu61zovtY5rqv2R1wlIix	\N	К утру	БАЗАР	31pd6hnytykuevog22xwj5yn2qjy	2024-02-29 13:56:05+00	\N	hip hop
4550	68	5lGgglkaWaFS5g0yRlqeV7	\N	Afterglow	Klangkarussell, GIVVEN	1qzcdqlwqtm8lnthmvh2a70p9	2024-03-01 10:22:25+00	\N	house
4545	68	5YwmHNBYYqtWWygM12P7Ig	\N	В твоих красивых глазах	ИБН	1qzcdqlwqtm8lnthmvh2a70p9	2024-02-28 18:58:18+00	\N	noise rock
4523	67	5qxOeTyWa0JAst5fqdrqgu	\N	Drown	Justin Timberlake	313neyxbfwxtbi2t52gjvliqxisa	2024-03-08 03:21:50+00	\N	pop
4536	68	607EA1HsuzrqqaPuxyNqpD	\N	Step	Vampire Weekend	31ghi62vkgnlb4wqr6muaisx7ldi	2024-02-26 15:34:05+00	\N	indie, baroque pop
4557	68	6REbwUNlppTfcnV4d4ZoZi	\N	Swimming Pools (Drank)	Kendrick Lamar	1qzcdqlwqtm8lnthmvh2a70p9	2024-03-03 12:00:20+00	\N	hip hop, west coast hip hop
4520	67	6b8OHSAXUjf62Yxebnw58d	\N	Были бы крылья	Merab Amzoevi	31pd6hnytykuevog22xwj5yn2qjy	2024-03-07 12:34:37+00	\N	r&b
4560	69	6tNQ70jh4OwmPGpYy6R2o9	\N	Beautiful Things	Benson Boone	313neyxbfwxtbi2t52gjvliqxisa	2024-02-19 02:12:49+00	\N	pop
4559	69	7fc332XA9cKqLgEpjMDXaP	\N	Break My Heart	GRAHAM	313neyxbfwxtbi2t52gjvliqxisa	2024-02-19 02:12:21+00	\N	pop
4521	67	7fcfNW0XxTWlwVlftzfDOR	\N	Walk	Pantera	31pd6hnytykuevog22xwj5yn2qjy	2024-03-07 12:56:11+00	\N	groove metal, metal, thrash metal, heavy metal
4599	69	0LQp6qJmYxqjd7qkMQDnqC	\N	Remember (Original Mix)	The Underdog Project	1qzcdqlwqtm8lnthmvh2a70p9	2024-02-22 19:37:32+00	\N	house
4587	69	1IsvXZXAV9EBC4hBKW6yDN	\N	Missing - Todd Terry Remix / Radio Edit	Everything But The Girl	1qzcdqlwqtm8lnthmvh2a70p9	2024-02-22 08:44:33+00	\N	house
4624	70	0u695M7KyzXaPIjpEbxOkB	\N	SICKO MODE - Skrillex Remix	Travis Scott, Skrillex	31pd6hnytykuevog22xwj5yn2qjy	2024-02-13 16:23:26+00	\N	rap
4604	70	10Q3ASy9okYt85040yV46c	\N	Shivering	ILLENIUM, Spiritbox	313neyxbfwxtbi2t52gjvliqxisa	2024-02-11 14:37:27+00	\N	melodic bass, future bass, edm
4580	69	1O8d2pWtBclzuY3FctBPVa	\N	Closer	Kings of Leon	31pd6hnytykuevog22xwj5yn2qjy	2024-02-20 14:34:11+00	\N	rock
4595	69	1OwStBU1hjXPPyL2XBQewF	\N	Forgiven	Sylver	1qzcdqlwqtm8lnthmvh2a70p9	2024-02-22 18:38:51+00	\N	eurodance
4629	70	2S5Ddttb7db90WNDde1UJx	\N	Home	Klangkarussell	31pd6hnytykuevog22xwj5yn2qjy	2024-02-14 15:59:22+00	\N	electronic
4597	69	1zvsxCmge9JnIZr6cSvWkk	\N	Right Now	Mary J. Blige	1qzcdqlwqtm8lnthmvh2a70p9	2024-02-22 18:54:17+00	\N	r&b
4622	70	2AsUIjkkqwLnv5vkiwkvsT	\N	Natural Born Killaz	Ice Cube, Dr. Dre	31pd6hnytykuevog22xwj5yn2qjy	2024-02-13 13:47:21+00	\N	old school hip hop, gangster rap, west coast hip hop, g-funk, hip hop
4614	70	2bDENJyfbxj0neGiXUFvIX	\N	Legendary	Welshly Arms	31pd6hnytykuevog22xwj5yn2qjy	2024-02-12 15:25:18+00	\N	rock
4582	69	2VxeLyX666F8uXCJ0dZF8B	\N	Shallow	Lady Gaga, Bradley Cooper	31pd6hnytykuevog22xwj5yn2qjy	2024-02-21 11:27:01+00	\N	art pop, pop
4627	70	2VymJtZMtr4O6wOvSpBuvy	\N	Fairytale Gone Bad - Accoustic Version	Sunrise Avenue	31pd6hnytykuevog22xwj5yn2qjy	2024-02-14 13:41:18+00	\N	finnish pop
4626	70	2eiazrw7Z16JcmmsRfQbUJ	\N	Madara	roseboi	313neyxbfwxtbi2t52gjvliqxisa	2024-02-14 01:12:37+00	\N	electronic
4593	69	2yt4u3bb6K33Nd1w4srff9	\N	Shine	Zvonkiy	1qzcdqlwqtm8lnthmvh2a70p9	2024-02-22 18:26:55+00	\N	pop
4579	69	2nZ7Cvk7RIdnG3KvihJd5F	\N	Wasted	Kasabian	31pd6hnytykuevog22xwj5yn2qjy	2024-02-20 14:13:41+00	\N	britpop, indie, indie rock
4606	70	2vk63a0DpsEDiCG4k0mjCF	\N	BANG YOUR HEAD	DJ DIESEL, Hairitage, Shaquille O'Neal	313neyxbfwxtbi2t52gjvliqxisa	2024-02-11 14:37:53+00	\N	dubstep, riddim, deathstep
4586	69	3CeCwYWvdfXbZLXFhBrbnf	\N	Love Story (Taylor’s Version)	Taylor Swift	1qzcdqlwqtm8lnthmvh2a70p9	2024-02-21 23:07:19+00	\N	pop
4601	69	3E7GoNxQocZzPjudfa2vFV	\N	Фокусы	GUF, SLIMUS	31pd6hnytykuevog22xwj5yn2qjy	2024-02-23 22:31:53+00	\N	rap
4631	70	3MjAdvSBLbj70fwiQnEFNP	\N	Серебро	Merab Amzoevi	31pd6hnytykuevog22xwj5yn2qjy	2024-02-14 20:20:05+00	\N	pop
4609	70	3bS1DYVMpJbMusBlDN2MUh	\N	Rose Colored Lenses	Unlike Pluto	313neyxbfwxtbi2t52gjvliqxisa	2024-02-11 14:38:40+00	\N	electronic
4610	70	3PGRdlUoWnj8NHmbA5xTYS	\N	Dangerous	Depeche Mode	1qzcdqlwqtm8lnthmvh2a70p9	2024-02-11 17:59:39+00	\N	new wave, synthpop, darkwave
4583	69	3YR2b3Rq9XjkwBVHEt75eW	\N	Straight Outta Line - Live	Godsmack	31pd6hnytykuevog22xwj5yn2qjy	2024-02-21 14:07:21+00	\N	alternative metal, nu metal, hard rock, rap metal, metal
4634	70	3sTubVxWHAjrS1bdUrVaeQ	\N	ДАЧНАЯ ВОЛНА	Antoha MC	1qzcdqlwqtm8lnthmvh2a70p9	2024-02-15 07:41:22+00	\N	rap
4625	70	48vIfHaK7by6x0T6ucpODL	\N	make you mine	Madison Beer	31pd6hnytykuevog22xwj5yn2qjy	2024-02-13 23:40:11+00	\N	pop
4594	69	4f9CqFuDwKvOHX78D2EvZv	\N	Всё ещё вернётся	Leonid Agutin	1qzcdqlwqtm8lnthmvh2a70p9	2024-02-22 18:34:12+00	\N	pop
4607	70	4ZPHBFQAvJX6IKsknurJDW	\N	Seaside - RED VERSION	Hyper Potions, CHOMPO	313neyxbfwxtbi2t52gjvliqxisa	2024-02-11 14:38:28+00	\N	future bass
4605	70	5b8TXX2rT4BmF16oaP8aSX	\N	Daydream	The Tech Thieves, Besomorph	313neyxbfwxtbi2t52gjvliqxisa	2024-02-11 14:37:37+00	\N	electronic
4589	69	4uUG5RXrOk84mYEfFvj3cK	\N	I'm Good (Blue)	David Guetta, Bebe Rexha	31pd6hnytykuevog22xwj5yn2qjy	2024-02-22 15:01:59+00	\N	edm
4598	69	55DfugJIh1351fCiwO2we2	\N	La Tormenta De Arena	Dorian	1qzcdqlwqtm8lnthmvh2a70p9	2024-02-22 19:08:46+00	\N	indie
4585	69	5l6hpyTGBK0LAAxgPnqTQL	\N	Look After You	The Fray	1qzcdqlwqtm8lnthmvh2a70p9	2024-02-21 22:58:15+00	\N	alternative rock
4596	69	5dQAOJuw12LEcMV0KTJIIR	\N	Break Away	MUZZ, Priority One	1qzcdqlwqtm8lnthmvh2a70p9	2024-02-22 18:40:36+00	\N	drum and bass, drumstep, dubstep
4613	70	6Qi0Wls2EaolwPMPMxfe5f	\N	Sonnentanz - Sun Don't Shine	Klangkarussell, Will Heard	31pd6hnytykuevog22xwj5yn2qjy	2024-02-12 15:09:10+00	\N	house
4633	70	6r30oJ0bFMqLypUtRoYsD8	\N	Пронзай	MiyaGi & Endspiel	313neyxbfwxtbi2t52gjvliqxisa	2024-02-15 00:32:25+00	\N	rap
4581	69	6v4ABPB255HDSWyIj3S9Wn	\N	Lovers In A Past Life (with Rag'n'Bone Man)	Calvin Harris, Rag'n'Bone Man	1qzcdqlwqtm8lnthmvh2a70p9	2024-02-20 21:51:53+00	\N	edm
4588	69	73tXOEqTow62wTYLl50Xii	\N	Wild Youngster (feat. ScHoolboy Q)	NEZ, ScHoolboy Q	31pd6hnytykuevog22xwj5yn2qjy	2024-02-22 10:59:10+00	\N	hip hop
4628	70	76W0Dj05PArGaHDNDgio8A	\N	Angel	Mattafix	31pd6hnytykuevog22xwj5yn2qjy	2024-02-14 13:51:30+00	\N	r&b
4611	70	7AVyve7cFYTd51ha5i9kE2	\N	Down Under (feat. Colin Hay)	Luude, Colin Hay	31pd6hnytykuevog22xwj5yn2qjy	2024-02-12 14:55:11+00	\N	drum and bass
4590	69	7aKWgpecgLEqisWcXPElDl	\N	Never There	CAKE	1qzcdqlwqtm8lnthmvh2a70p9	2024-02-22 18:09:59+00	\N	alternative rock
4612	70	7ffOpolrzSYw8BUcT6Gmc1	\N	solace&stillness	Judgement	313neyxbfwxtbi2t52gjvliqxisa	2024-02-12 15:08:37+00	\N	post-hardcore
4603	69	7vEkX5ctStkJ0k6OcYP5lf	\N	TO THE FLOWERS	While She Sleeps	1qzcdqlwqtm8lnthmvh2a70p9	2024-02-25 13:37:19+00	\N	metalcore, metal, post-hardcore
4690	72	0Cez33GqDU7Pw5rqOVUPpU	\N	unravel	Ado	1qzcdqlwqtm8lnthmvh2a70p9	2024-02-01 12:45:02+00	\N	j-pop, anime, vocaloid, j-rock
4692	72	0cIgRv4Ew48c2r2yixOR1K	\N	My Favourite Game (feat. The Cardigans)	Samstone, Aktive, The Cardigans	1qzcdqlwqtm8lnthmvh2a70p9	2024-02-01 12:50:21+00	\N	bassline, drum and bass, bass house
4672	72	0kdqcbwei4MDWFEX5f33yG	\N	Bling-Bang-Bang-Born	Creepy Nuts	1qzcdqlwqtm8lnthmvh2a70p9	2024-01-26 22:08:31+00	\N	anime, j-pop, j-rap
4675	72	0o8PAzsSLDa4MVQJixGVty	\N	Summer On You (feat. Wulf)	Sam Feldt, Lucas & Steve, Wulf	313neyxbfwxtbi2t52gjvliqxisa	2024-01-28 13:46:21+00	\N	tropical house
4640	70	0yCOoelohpXq6XEJbVX2Ci	\N	Self Destructor	Chevelle	31pd6hnytykuevog22xwj5yn2qjy	2024-02-15 12:19:40+00	\N	alternative metal, nu metal, post-grunge
4661	71	18I6HAbavMhof1geaOLy8N	\N	Snake	Modestep	313neyxbfwxtbi2t52gjvliqxisa	2024-02-08 10:54:24+00	\N	dubstep, riddim, dub, drum and bass, deathstep, drumstep
4654	71	1NeLwFETswx8Fzxl2AFl91	\N	Something About Us	Daft Punk	31pd6hnytykuevog22xwj5yn2qjy	2024-02-07 11:24:18+00	\N	french house, electronic, electro
4683	72	1OGkB06pBNqk4UKUIadR4X	\N	Tops Drop	Fat Pat	31pd6hnytykuevog22xwj5yn2qjy	2024-01-28 15:41:12+00	\N	southern hip hop
4680	72	2374M0fQpWi3dLnB54qaLX	\N	Africa	TOTO	31pd6hnytykuevog22xwj5yn2qjy	2024-01-28 15:33:50+00	\N	yacht rock, soft rock
4676	72	2Fwgtd3DinOGi6reuGugR6	\N	Invaders Must Die	The Prodigy	313neyxbfwxtbi2t52gjvliqxisa	2024-01-28 13:58:35+00	\N	big beat, breakbeat
4655	71	2e1WR9PYEAyuu9k5hNHHI1	\N	Castle In The Snow	The Avener, Kadebostany	1qzcdqlwqtm8lnthmvh2a70p9	2024-02-07 11:26:14+00	\N	electronic
4645	71	2Yz2Z1ENB85nYrK3Rg2qxO	\N	First Fires	Bonobo, Grey Reverend	1qzcdqlwqtm8lnthmvh2a70p9	2024-02-04 10:10:26+00	\N	trip hop, downtempo, nu jazz, electronic
4653	71	3HtazJXet39mz8SqZwm5NP	\N	11:11	Dinosaur Pile-Up	31pd6hnytykuevog22xwj5yn2qjy	2024-02-07 11:24:02+00	\N	alternative rock
4652	71	2e2kDeICBMJOayDi7bsfLS	\N	sequoia	Pensees, Øneheart	1qzcdqlwqtm8lnthmvh2a70p9	2024-02-07 05:28:19+00	\N	chillstep
4665	71	2y8USOrYuvaz4BqN9guAt4	\N	Cut	Duskus	1qzcdqlwqtm8lnthmvh2a70p9	2024-02-08 11:39:24+00	\N	stutter house, future bass
4677	72	39ki02XRiCpXJMGKU8CqDJ	\N	Wolf Totem (feat. Jacoby Shaddix of Papa Roach)	The HU, Jacoby Shaddix	313neyxbfwxtbi2t52gjvliqxisa	2024-01-28 14:05:07+00	\N	folk metal
4687	72	3DxDNZNMA2H9hnWeblvRgL	\N	Hey Ya	Sleep Token	1qzcdqlwqtm8lnthmvh2a70p9	2024-01-31 21:11:16+00	\N	progressive metal, metalcore
4651	71	3tNMdL4qjzNHfo7rlVMESK	\N	HONEY (ARE U COMING?)	Måneskin	1qzcdqlwqtm8lnthmvh2a70p9	2024-02-05 17:23:08+00	\N	rock
4658	71	3aykPW16OZVdGekcpeYEH1	\N	Avalon	$uicideboy$	31pd6hnytykuevog22xwj5yn2qjy	2024-02-07 12:35:14+00	\N	emo rap, horrorcore, cloud rap, trap metal, underground hip hop
4681	72	4Bqv7DwSQaBSXWklUo2Whh	\N	Fear of Falling Asleep - Fwar Remix	TENDER, Fwar	31pd6hnytykuevog22xwj5yn2qjy	2024-01-28 15:36:31+00	\N	electronic
4666	71	3p4hRhMcb6ch8OLtATMaLw	\N	Cry	Cigarettes After Sex	1qzcdqlwqtm8lnthmvh2a70p9	2024-02-08 11:43:29+00	\N	dream pop
4694	72	4TPzn1tHoa186Nu2wb68r0	\N	Emptiness	One True God, Roniit	1qzcdqlwqtm8lnthmvh2a70p9	2024-02-01 12:54:57+00	\N	electronic
4664	71	4ZklLyx2Dfw0HamIb62Grv	\N	Ethereal (Slowed)	Txmy	1qzcdqlwqtm8lnthmvh2a70p9	2024-02-08 11:25:41+00	\N	downtempo
4685	72	55YFzaB2iRtAdMwMY0Wzme	\N	Terminal 0	Hayes & Y	31pd6hnytykuevog22xwj5yn2qjy	2024-01-31 12:30:41+00	\N	electronic
4656	71	609F8MNgjbcqrG4dhlerMu	\N	6 in the Morning	TENDER	31pd6hnytykuevog22xwj5yn2qjy	2024-02-07 12:00:50+00	\N	indie
4686	72	4nOA58XLjVbRG9bHfbgyms	\N	Hey Ya!	LEOWI, Lucky Luke	1qzcdqlwqtm8lnthmvh2a70p9	2024-01-31 21:10:12+00	\N	drum and bass
4679	72	6FMqQd93nGosukceX72We4	\N	Melt	TENDER	31pd6hnytykuevog22xwj5yn2qjy	2024-01-28 15:33:26+00	\N	indie
4693	72	5ECvVPe91SglewaRngg3jF	\N	Made for you	STRLGHT	1qzcdqlwqtm8lnthmvh2a70p9	2024-02-01 12:54:29+00	\N	phonk
4671	72	5HkvwkP7q01ArLWx4vTzKV	\N	ego talkin - A COLORS SHOW	Saint Harison, COLORS	1qzcdqlwqtm8lnthmvh2a70p9	2024-01-26 21:15:24+00	\N	uk r&b
4641	70	5cRDn5aGMLvWsldoRmOOz0	\N	Solar System	Sub Focus	31pd6hnytykuevog22xwj5yn2qjy	2024-02-15 12:25:37+00	\N	drum and bass, liquid funk
4638	70	6GB9xzNHL1ItpnEBHzplAe	\N	Одинокая луна	Lika Star	1qzcdqlwqtm8lnthmvh2a70p9	2024-02-15 11:43:34+00	\N	pop
4668	71	6AAaBTwek6tqw9PsRYVLf0	\N	Vibe 2	MAXPVNK	1qzcdqlwqtm8lnthmvh2a70p9	2024-02-11 12:19:19+00	\N	phonk, brazilian phonk
4637	70	6gi7qsHSH2JWZsTRHndxqm	\N	Rain (from The Suicide Squad)	grandson, Jessie Reyez	1qzcdqlwqtm8lnthmvh2a70p9	2024-02-15 11:12:55+00	\N	rock
4657	71	6Oq4fiDzKaFMU89dTvM24u	\N	Audacity (feat. Headie One)	Stormzy, Headie One	31pd6hnytykuevog22xwj5yn2qjy	2024-02-07 12:04:08+00	\N	grime, uk grime, uk drill
4663	71	729oeqO3kCDJqnT4ObIf91	\N	EXIT	Ronja Malena, defyer	1qzcdqlwqtm8lnthmvh2a70p9	2024-02-08 11:25:15+00	\N	electronic
4688	72	7Gk8icymiW50sDfFbWLoVG	\N	Oh No :: He Said What?	Nothing But Thieves	313neyxbfwxtbi2t52gjvliqxisa	2024-01-31 23:25:19+00	\N	alternative rock
4674	72	6qPDwNS6lO6fDSHFtz41a2	\N	Satisfy	NERO	313neyxbfwxtbi2t52gjvliqxisa	2024-01-28 12:57:18+00	\N	dubstep, dub
4642	70	7MtVPRGtZl6rPjMfLoI3Lh	\N	Fuck it I love you	Lana Del Rey	1qzcdqlwqtm8lnthmvh2a70p9	2024-02-15 15:14:07+00	\N	pop
4678	72	7yIGRf80h3Kwi4GfwJUiQl	\N	Shine On	R.I.O.	31pd6hnytykuevog22xwj5yn2qjy	2024-01-28 15:33:14+00	\N	house
4660	71	7N3fhKcOZj1bj2YISj5JKA	\N	Дагон	Korol i Shut	313neyxbfwxtbi2t52gjvliqxisa	2024-02-08 10:53:27+00	\N	horror punk
4636	70	2GAO7dwi3YXGaABCUX3N4p	\N	Personal Jesus - Ph Elektro Mix	G&G, PH Electro	1qzcdqlwqtm8lnthmvh2a70p9	2024-02-15 09:21:53+00	\N	electronic
4719	74	0OuvMbIdvi9d2Ucsk1poS0	\N	Battling My Demons	Jeris Johnson, BOI WHAT	313neyxbfwxtbi2t52gjvliqxisa	2024-01-19 03:07:02+00	\N	metalcore
4718	74	0GWNtMohuYUEHVZ40tcnHF	\N	SPECIALZ	King Gnu	1qzcdqlwqtm8lnthmvh2a70p9	2024-01-18 15:39:24+00	\N	j-pop, anime, j-rock
4753	77	1FkMs8KRv5h14bQrfD2t3v	\N	Аномалия	Тося Чайкина	1qzcdqlwqtm8lnthmvh2a70p9	2023-11-23 11:55:50+00	\N	alternative rock
4755	77	0dYD2Z4SHcYdefhgSWfKmJ	\N	Life Of The Party	General Levy, DJ Rap	313neyxbfwxtbi2t52gjvliqxisa	2023-11-23 23:09:44+00	\N	jungle, ragga, drum and bass, uk garage
4735	75	0kF6MdXhjQeYhZ2kogCIsx	\N	She Came II Give It II U (feat. Nicki Minaj)	USHER, Nicki Minaj	313neyxbfwxtbi2t52gjvliqxisa	2024-01-13 14:03:56+00	\N	r&b
4738	76	12fXkI2VEpXy1xohgnOQlS	\N	Shabaka	Adrenalize, Sickddellz	313neyxbfwxtbi2t52gjvliqxisa	2023-12-18 13:47:09+00	\N	hardstyle, frenchcore
4740	76	1DWG77sh5FBbsDU9WBywuw	\N	Broken Hearted	4URA, Josiah Nichols	1qzcdqlwqtm8lnthmvh2a70p9	2023-12-18 16:48:14+00	\N	melodic bass, edm trap, future bass
4749	77	1db6yzZU19PMajT7OKAIwI	\N	Наедине	The OM, Ulukmanapo	313neyxbfwxtbi2t52gjvliqxisa	2023-11-21 01:32:52+00	\N	pop
4744	76	1H4Y9uW4N0LsxJUz0VnaPJ	\N	Just Pretend	Bad Omens	313neyxbfwxtbi2t52gjvliqxisa	2023-12-19 12:35:01+00	\N	metalcore
4710	73	1VyRpTEE3InYTwUGcjsHJm	\N	YOU AND ME	k?d	1qzcdqlwqtm8lnthmvh2a70p9	2024-01-22 21:02:01+00	\N	future bass, melodic bass
4743	76	2BC5kV2nzTzdOV8zEh1TXm	\N	Накануне тепла	Обе-Рек	313neyxbfwxtbi2t52gjvliqxisa	2023-12-19 12:34:19+00	\N	rock
4750	77	1h6XqUq9RURHS8OcDigK2T	\N	Advanced Nightcore	dj Joov3yn, Eva Music	1qzcdqlwqtm8lnthmvh2a70p9	2023-11-22 08:36:04+00	\N	hardstyle, frenchcore, nightcore
4727	75	1hMv6P9dltDeaWa43cDGQo	\N	Are You With Me	Lost Frequencies	1qzcdqlwqtm8lnthmvh2a70p9	2024-01-09 12:18:44+00	\N	tropical house
4751	77	1xL1eqxpu599UwF79xgQBH	\N	Foolish Fish	DROELOE	1qzcdqlwqtm8lnthmvh2a70p9	2023-11-23 11:32:07+00	\N	future bass
4714	74	23exJGva4crP8jrwx7gGZX	\N	Catchfire (Sun Sun Sun) (feat. Anna Leyne) - EDX's Miami Sunset Remix	Spada, Anna Leyne	1qzcdqlwqtm8lnthmvh2a70p9	2024-01-15 08:54:54+00	\N	melodic house, melodic techno
4726	75	3RbNcjVnQixKa1sULcwd2K	\N	Losing Interest	Stract, Shiloh Dynasty	1qzcdqlwqtm8lnthmvh2a70p9	2024-01-09 12:18:44+00	\N	emo
4733	75	2KslE17cAJNHTsI2MI0jb2	\N	Standing Next to You	Jung Kook	1qzcdqlwqtm8lnthmvh2a70p9	2024-01-10 18:06:29+00	\N	k-pop
4707	73	2OWv3lRR8PtOVuHWzQNRs2	\N	ROMPE LA DOMPE	Peso Pluma, Junior H, Oscar Maydon	1qzcdqlwqtm8lnthmvh2a70p9	2024-01-22 20:44:37+00	\N	corrido, corridos tumbados, corridos bélicos, música mexicana, sierreño, sad sierreño, banda
4723	75	2OYtcqflvzQwh3cMPmTHs4	\N	There’s Fear In Letting Go	I Prevail	1qzcdqlwqtm8lnthmvh2a70p9	2024-01-08 14:52:51+00	\N	metalcore, metal
4741	76	2a7tWwfJeOmiQB0AryaKB3	\N	Out of Love	Oliver Heldens, WeiBird	1qzcdqlwqtm8lnthmvh2a70p9	2023-12-18 16:48:51+00	\N	future house, house
4713	73	2bbeNsFmjZqdoDhjLsKNWe	\N	Bailamos	Enrique Iglesias	313neyxbfwxtbi2t52gjvliqxisa	2024-01-23 23:41:20+00	\N	latin pop, latin
4695	72	2jAuiYdZhKfrHg9zX2C5pu	\N	Machines	Modestep	313neyxbfwxtbi2t52gjvliqxisa	2024-02-02 05:25:04+00	\N	dubstep, riddim, dub, drum and bass, deathstep, drumstep
4717	74	307iMiCYAKX6sUG7P4UKWt	\N	See Tình	Hoàng Thùy Linh	1qzcdqlwqtm8lnthmvh2a70p9	2024-01-19 14:06:16+00	\N	v-pop, vinahouse, vietnamese hip hop, vietnam indie
4730	75	3A7a2DoyGxKtcq0BHFXikE	\N	I Can't Stop	ONEIL, Aize	1qzcdqlwqtm8lnthmvh2a70p9	2024-01-09 15:05:46+00	\N	slap house, g-house
4702	73	3rUGC1vUpkDG9CZFHMur1t	\N	greedy	Tate McRae	1qzcdqlwqtm8lnthmvh2a70p9	2024-01-22 20:21:46+00	\N	pop
4703	73	3vkCueOmm7xQDoJ17W1Pm3	\N	My Love Mine All Mine	Mitski	1qzcdqlwqtm8lnthmvh2a70p9	2024-01-22 20:22:11+00	\N	indie
4720	74	42qNWdLKCI41S4uzfamhFM	\N	Duvet	bôa	1qzcdqlwqtm8lnthmvh2a70p9	2024-01-19 14:33:44+00	\N	shoegaze
4698	73	431dLa3HnVrcW6cVdKWe1h	\N	Overglow	Adam Lambert	1qzcdqlwqtm8lnthmvh2a70p9	2024-01-22 20:11:40+00	\N	pop
4706	73	4EWfyPDwqBVWMBfzgvrI9y	\N	Not Enough	One True God, EDDIE	1qzcdqlwqtm8lnthmvh2a70p9	2024-01-22 20:40:10+00	\N	pop
4729	75	4EivmOT13NMpNSfTKn9p4s	\N	Like That (feat. Gucci Mane)	Doja Cat, Gucci Mane	1qzcdqlwqtm8lnthmvh2a70p9	2024-01-09 15:04:01+00	\N	rap
4725	75	4LDuFh8tES3xOVYRHhUADG	\N	Cardigan Loop	OURGRND	1qzcdqlwqtm8lnthmvh2a70p9	2024-01-09 12:18:44+00	\N	electronic
4712	73	5V0uJx2j8QrRW0zCifZIT4	\N	1love	Eldzhey	1qzcdqlwqtm8lnthmvh2a70p9	2024-01-22 21:07:26+00	\N	pop
4700	73	4GmxAkE4CBTHHxXPHjYkp7	\N	No Lies	Pascal Junior	1qzcdqlwqtm8lnthmvh2a70p9	2024-01-22 20:14:17+00	\N	deep house
4708	73	5eEgVC3k662YA6P6pcHnpP	\N	Kitoj planetoj	Matto, Ciūnys	1qzcdqlwqtm8lnthmvh2a70p9	2024-01-22 20:52:50+00	\N	folk
4697	73	4OplhQTx2HFvi2PZrNIxCM	\N	Бабочки - Radio Edit	Elena Temnikova	1qzcdqlwqtm8lnthmvh2a70p9	2024-01-22 20:06:11+00	\N	europop
4745	76	4QhnNyKDsAkXPwHkSnuc89	\N	Eve, Psyche & The Bluebeard’s wife	LE SSERAFIM	1qzcdqlwqtm8lnthmvh2a70p9	2023-12-19 16:00:10+00	\N	k-pop
4737	75	4Xo0c4AtfUUuprVEKzyNYW	\N	Redemption	RIOT	313neyxbfwxtbi2t52gjvliqxisa	2024-01-14 06:19:33+00	\N	dubstep, deathstep, riddim
4731	75	52hQY9AntPqOQM46N9BnfC	\N	Amazing	INNA	1qzcdqlwqtm8lnthmvh2a70p9	2024-01-09 21:58:59+00	\N	europop
4734	75	71RFqS8oxudlOEUv5rNuHE	\N	Вся моя жизнь	Luverance	1qzcdqlwqtm8lnthmvh2a70p9	2024-01-12 11:34:18+00	\N	pop
4696	73	5gB2IrxOCX2j9bMnHKP38i	\N	Life is a Highway	Rascal Flatts	1qzcdqlwqtm8lnthmvh2a70p9	2024-01-20 23:04:25+00	\N	country
4747	76	5wH0qTIhsK8aSKWs6IAY61	\N	In & Out	Nathan C	1qzcdqlwqtm8lnthmvh2a70p9	2023-12-21 07:52:41+00	\N	deep house
4709	73	62ZAFyVwbc9f2M8qCW1qJr	\N	MURDER PLOT	Kordhell	1qzcdqlwqtm8lnthmvh2a70p9	2024-01-22 20:58:42+00	\N	phonk, drift phonk
4754	77	6u1PsWWXElxb836ElkyQh1	\N	Jheez Louise	Soulecta	1qzcdqlwqtm8lnthmvh2a70p9	2023-11-23 12:07:41+00	\N	uk garage, bassline, uk funky
4711	73	7DXBItTPwL8OpsbXdj58Fl	\N	Bobby Sox	Green Day	1qzcdqlwqtm8lnthmvh2a70p9	2024-01-22 21:03:05+00	\N	punk, pop punk
4742	76	7lwXbmqhk82uEC6n74hr6f	\N	All I Want for Christmas Is You	Our Last Night	313neyxbfwxtbi2t52gjvliqxisa	2023-12-19 12:31:34+00	\N	post-hardcore, metalcore
4722	75	7yz5IAgaJSmEVgKP0GHXJU	\N	Farewell II Flesh	Ice Nine Kills	1qzcdqlwqtm8lnthmvh2a70p9	2024-01-08 14:51:34+00	\N	metalcore, metal
4732	75	0E7EohFQ83z7H4yAqeHjEs	\N	It Won't Last	Blacktop Mojo	313neyxbfwxtbi2t52gjvliqxisa	2024-01-10 12:43:30+00	\N	rock
4815	79	05XkogU63hk3AVdrXv6rDY	\N	Girl Like U	Fixed withGlue, Mougleta	1qzcdqlwqtm8lnthmvh2a70p9	2023-11-05 00:37:29+00	\N	hypertechno
4801	79	0W4N0KzHKWQp2Wn1Mf6uMa	\N	We Got the Moves	Electric Callboy	313neyxbfwxtbi2t52gjvliqxisa	2023-10-31 05:18:25+00	\N	metalcore, metal
4771	78	18PVp3A6v25L7XacAhDpKx	\N	бери и беги	Zivert	1qzcdqlwqtm8lnthmvh2a70p9	2023-11-06 17:06:52+00	\N	pop
4806	79	1M6SgXogPl6Clo6jBoLIiI	\N	Outlaw - Melodic Techno Mix	Intelligency	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-31 12:58:20+00	\N	house
4794	79	1FpkbWY8G5wFRZCJ8nmnaZ	\N	SOMNIUM	REA4E, maingaus	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-30 21:26:20+00	\N	drift phonk, phonk
4808	79	1KJzlX849qCMfYWKOI7STr	\N	Milkshake	SMACK	1qzcdqlwqtm8lnthmvh2a70p9	2023-11-01 06:40:36+00	\N	bass house, future house
4791	79	1krvil2tPd33KxY2kDpY3e	\N	Slow Mo	Armich, Skryptonite	313neyxbfwxtbi2t52gjvliqxisa	2023-10-30 11:16:23+00	\N	rap
4799	79	1b1U08Eqbx8f0QYyPTzqcU	\N	Same Old Song	Vibe Chemistry, HARLEE	313neyxbfwxtbi2t52gjvliqxisa	2023-10-31 05:15:38+00	\N	drum and bass, liquid funk
4757	77	1e5BGmPO3HG6uppYmCzQny	\N	FLASHBACK	Nikitata	1qzcdqlwqtm8lnthmvh2a70p9	2023-11-24 00:16:19+00	\N	drift phonk, phonk
4769	78	1kNQaLVnjVjczLjuf1aTah	\N	Ночь	АДЛИН	1qzcdqlwqtm8lnthmvh2a70p9	2023-11-06 16:48:18+00	\N	phonk, drift phonk
4764	77	24c9nKM59EY6ewBFsUqlbj	\N	Очень-очень	ARTIK & ASTI	1qzcdqlwqtm8lnthmvh2a70p9	2023-12-09 19:30:43+00	\N	pop
4763	77	21pusgGQghtpXEphhzmXrI	\N	Trapped	Dead by April	1qzcdqlwqtm8lnthmvh2a70p9	2023-12-07 08:30:23+00	\N	metalcore
4762	77	35KOd9cqJ5Mp8ltVDnzFFR	\N	Lights Go Down	Mike Candys	1qzcdqlwqtm8lnthmvh2a70p9	2023-12-03 18:00:51+00	\N	house
4759	77	3IrOKmwNGtOHt3uP9VnHUT	\N	не успел сказать	Guntor	1qzcdqlwqtm8lnthmvh2a70p9	2023-11-25 11:39:07+00	\N	phonk
4816	79	3I56dGSUvEYL96kmdCbaNx	\N	Give It To Me	Swanky Tunes, Veronica Bravo, J R	1qzcdqlwqtm8lnthmvh2a70p9	2023-11-05 00:38:14+00	\N	electro house, future house
4770	78	3KAHkivOxoBLPeWMiPwYjO	\N	7-DS	Grey, AWAY	1qzcdqlwqtm8lnthmvh2a70p9	2023-11-06 16:53:52+00	\N	downtempo
4761	77	3oUEzTAoOxqZHN4xiqTGqJ	\N	Bécane - A COLORS SHOW	Yamê, COLORS	1qzcdqlwqtm8lnthmvh2a70p9	2023-11-30 17:57:50+00	\N	french rap
4766	78	3tYxhPqkioZEV5el3DJxLQ	\N	Youngest Daughter	Superheaven	313neyxbfwxtbi2t52gjvliqxisa	2023-11-06 01:12:09+00	\N	shoegaze, post-grunge
4812	79	41bGn6u78I8eNZg86tx3vp	\N	Москва любит...	Skryptonite	313neyxbfwxtbi2t52gjvliqxisa	2023-11-03 03:47:30+00	\N	hip hop
4775	78	4B5tfdeQwonYnNqpZgHzd0	\N	Прости	passmurny	1qzcdqlwqtm8lnthmvh2a70p9	2023-11-07 08:52:27+00	\N	emo
4814	79	4KRrFJM2twdM5QFVELRZ5u	\N	Street Lights (Nanana)	David Ritt	1qzcdqlwqtm8lnthmvh2a70p9	2023-11-05 00:35:17+00	\N	house
4790	79	4Mqfhqtb5WmondLWYsCCrz	\N	The Boys Are Back In Town	Yung Gravy, Pouya, Ramirez, TrippyThaKid	313neyxbfwxtbi2t52gjvliqxisa	2023-10-30 11:15:59+00	\N	hip hop
4779	78	4NT01PexISJjFoIRBsAtUa	\N	Thunderstorm	Zoo Brazil, Moon, Wolf	313neyxbfwxtbi2t52gjvliqxisa	2023-11-08 04:32:17+00	\N	electronic
4805	79	4pAi6HM3FN0c1Z3J2BbrrS	\N	Этажи	Дорогой Дневник	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-31 12:54:37+00	\N	pop
4777	78	4TlSKekhYvakCCbaCt1VSn	\N	LETO	THE DAWLESS, Kristina Si, Гольд	1qzcdqlwqtm8lnthmvh2a70p9	2023-11-07 18:36:39+00	\N	breakbeat
4804	79	5Md2RPXhoqHb6vVDmsC5qA	\N	В моей голове	INSTASAMKA	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-31 12:21:59+00	\N	rap
4760	77	5PrMGr0iDVedvYZnRULnxO	\N	Быть Дауном	Loqiemean	1qzcdqlwqtm8lnthmvh2a70p9	2023-11-26 18:07:06+00	\N	rap
4787	79	5w4XPMyvehdEJdtU4ZU67B	\N	Outside	breakkaway	313neyxbfwxtbi2t52gjvliqxisa	2023-10-29 22:55:03+00	\N	electronic
4793	79	5ULEKBOe4h869Ti6R3rQKf	\N	Lovesong	Scott Bradlee's Postmodern Jukebox, Emma Smith	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-30 21:21:06+00	\N	swing music, jazz pop, electro swing
4776	78	6GGgckeyAB0FIMepdZsaU3	\N	Why did you do it	Izzamuzzic, TRAKEΛ	1qzcdqlwqtm8lnthmvh2a70p9	2023-11-07 09:19:03+00	\N	trap
4817	79	6Dy8UR9dhacqq6BJlumXN1	\N	Waste My Time	DJ Zinc, HEIGHTS	1qzcdqlwqtm8lnthmvh2a70p9	2023-11-05 00:43:22+00	\N	drum and bass, bassline, jungle, uk garage, bass house
4773	78	6MU77vhAm2S3e1IVs8OdrT	\N	No Tomorrow	MITYA	1qzcdqlwqtm8lnthmvh2a70p9	2023-11-06 18:02:48+00	\N	pop
4792	79	6ZG7EV2sV2M1MI9XxANAdF	\N	A Different Kind of Blues	IAMJJ, Baker Grace	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-30 21:18:35+00	\N	jazz
4807	79	6adYsNgHIHxZHud625fwxD	\N	Сейчас	Armich	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-31 20:37:53+00	\N	electronic
4774	78	6mtBaHc5msOGaUzYguKXZH	\N	БЕРЕГОМ	ЯАVЬ	1qzcdqlwqtm8lnthmvh2a70p9	2023-11-06 18:36:41+00	\N	indie
4802	79	7MaHUMJbxWh3hlXXYosRS4	\N	SPOGADY - Mix	LOBODA	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-31 10:25:42+00	\N	pop
4788	79	6tXqByNxqYPuWBeZZG4DVq	\N	Equivalent Exchange	Clayton King	313neyxbfwxtbi2t52gjvliqxisa	2023-10-30 06:18:20+00	\N	djent
4772	78	7lLvyMx4KFDixMBJ94bcAJ	\N	Get Shaky - Radio Edit	Ian Carey Project	1qzcdqlwqtm8lnthmvh2a70p9	2023-11-06 17:07:45+00	\N	house
4789	79	7oIKXyJtz8W32LjORWShTt	\N	Blind	Sable	313neyxbfwxtbi2t52gjvliqxisa	2023-10-30 06:44:08+00	\N	indie
4796	79	7pWnuc6iN21SPplpgvIlW7	\N	Скинь Котиков (Turbosh Remix)	Mirèle, Turbosh	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-30 21:34:45+00	\N	house
4803	79	0g3Dtg108GpFsUzyaUTTf3	\N	Сердце	Nelly Mes	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-31 12:19:43+00	\N	pop
4824	79	08yMOmydumplen59qUD4zf	\N	L	015B, youra	1qzcdqlwqtm8lnthmvh2a70p9	2023-11-05 22:03:56+00	\N	k-ballad, k-rock
4847	80	0OCFIEsSrmKueOiPK6S3xq	\N	Pepper	Flowdan, Lil Baby, Skrillex	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-27 17:34:41+00	\N	drum and bass, grime, uk garage
4833	80	0gya05XRh3NORYyex8PQrB	\N	Only You	BLURRYFXCE	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-22 21:49:35+00	\N	electronic
4850	81	0lnoY5X5ddnN3xMl802YpE	\N	Санта Лючия	Quest Pistols Show	313neyxbfwxtbi2t52gjvliqxisa	2023-10-16 02:41:23+00	\N	pop
4858	81	0sWniVm3HUdyxClGcyJEUM	\N	Rush	IMANU, Zeds Dead	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-16 22:11:55+00	\N	drum and bass, drumstep
4825	79	1q6Dya4rXWagxdceVg99eG	\N	FLM	ROMES	1qzcdqlwqtm8lnthmvh2a70p9	2023-11-05 22:03:56+00	\N	indie
4879	82	2QX7XQ8CT5qhbLvPAyXqoz	\N	Redlight - Radio Edit	Ian Carey	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-09 08:42:38+00	\N	house
4828	80	2Xkn3nqjHGo2I1aQWrPU3o	\N	Закат	The OM	313neyxbfwxtbi2t52gjvliqxisa	2023-10-22 14:42:14+00	\N	indie
4846	80	2Dp5Rqruog8SR6x7UtlIpY	\N	9mm	Memphis Cult, Groove Dealers, SPLYXER	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-25 12:52:12+00	\N	phonk, drift phonk
4845	80	2lSstxaztMfq6GNEMTTyCN	\N	Песня о любви (Которой не было)	Nepara	313neyxbfwxtbi2t52gjvliqxisa	2023-10-25 00:43:36+00	\N	pop
4851	81	2SD2zj8W5zKMdjCCJFF0vQ	\N	Wasteland	Seether	313neyxbfwxtbi2t52gjvliqxisa	2023-10-16 14:12:41+00	\N	post-grunge, alternative metal, rock
4844	80	30d0YcXyQSZQcc2dHdcRhh	\N	Вахтерам	Boombox	313neyxbfwxtbi2t52gjvliqxisa	2023-10-24 19:19:26+00	\N	rock
4862	81	36wLGbqIfs6wlEKq80oHns	\N	Царица	ANNA ASTI	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-19 09:03:20+00	\N	pop
4843	80	38cnRVX0CLahZzqlaif75b	\N	My Beloved Monster	The Broadway Singers,Choir & Orchestra	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-24 11:36:32+00	\N	soundtrack
4877	82	30liQIiqGf8OJFvFhwKkoZ	\N	Dominate - EPROM Remix	Space Laces, Eprom	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-09 08:40:57+00	\N	dubstep, riddim, deathstep, bass music, bass house, edm, dub
4832	80	39pMuJ3ShxDqb7bBIAXSYG	\N	Exil	Hiboky	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-22 21:49:35+00	\N	electronic
4853	81	3IXaKETuw0YXauBqQXbflk	\N	Ковры - Izzamuzzic Remix	TAYÖKA, Skryptonite, Izzamuzzic	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-16 20:31:09+00	\N	hip hop
4834	80	39JofJHEtg8I4fSyo7Imft	\N	B.O.T.A. (Baddest Of Them All) - Edit	Eliza Rose, Interplanetary Criminal	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-22 21:49:35+00	\N	house
4868	81	3Co9QY7WBNKoS44Nsk93r6	\N	DOMINATION	Kayzo, Sullivan King, Papa Roach	313neyxbfwxtbi2t52gjvliqxisa	2023-10-21 04:23:39+00	\N	dubstep, deathstep, riddim, edm
4836	80	3eIcBO6xjfT1xSmXP1fmFf	\N	Lost on you (Sped Up) - Remix	Music Factory	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-22 21:49:35+00	\N	pop
4822	79	3Iz0PKRyYseR4eoIM3mjRN	\N	Пропасть	The Korea	1qzcdqlwqtm8lnthmvh2a70p9	2023-11-05 22:03:56+00	\N	djent, progressive metal, metalcore
4823	79	3jJKrxnKOAtrw8zZJ3vbTV	\N	The Game	REYKO	1qzcdqlwqtm8lnthmvh2a70p9	2023-11-05 22:03:56+00	\N	electronic
4829	80	4MFLdAiHJv7zDOEbD2P2az	\N	Tell Me The Truth	Two Feet	313neyxbfwxtbi2t52gjvliqxisa	2023-10-22 14:43:49+00	\N	alternative rock
4863	81	3kct249XI6ZvMujsbALGdY	\N	FU4EVR	Attila	313neyxbfwxtbi2t52gjvliqxisa	2023-10-19 13:21:29+00	\N	deathcore, metalcore, rap metal, metal, screamo
4820	79	4trx1d5g0Kysltsk3uMC47	\N	Spiral - Remix	Kaela, SOFI TUKKER	1qzcdqlwqtm8lnthmvh2a70p9	2023-11-05 22:03:56+00	\N	electronic
4873	82	5e3RYBlWsiLIfATwQsQfnH	\N	Не улетай	Merab Amzoevi	313neyxbfwxtbi2t52gjvliqxisa	2023-10-09 02:42:36+00	\N	pop
4876	82	4TxZCE5SQEpPkHv20S4zMa	\N	Sacredly	Manila Killa, Linney	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-09 08:39:55+00	\N	future bass
4856	81	4bqDgEc3V9o0gle8mvgCgN	\N	Capable of love	PinkPantheress	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-16 21:59:58+00	\N	bedroom pop
4841	80	4hkZMpR9ptEQLqlIorFPeN	\N	Losing You	Dead by April	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-23 20:32:30+00	\N	metalcore
4854	81	5ieNNVMbuqi602ACxrwqAb	\N	Цунами	Гости Гаррисона	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-16 20:44:17+00	\N	rock
4859	81	5QOBT97OmYCZo1W5u7tRrB	\N	ten	Fred again.., Jozzy	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-16 22:12:22+00	\N	stutter house, house, edm
4821	79	6LREFtAefeqdTNdBAdmd99	\N	Heart of a Dancer	The Happy Fits	1qzcdqlwqtm8lnthmvh2a70p9	2023-11-05 22:03:56+00	\N	indie
4835	80	6QeYSvYqYUsfBzsApbjDHO	\N	Cigarettes out the Window	TV Girl	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-22 21:49:35+00	\N	indie
4819	79	6HtjJ09kCJbaQSrazLVEGr	\N	Heard It Like This	ACRAZE, Joey Valence & Brae	313neyxbfwxtbi2t52gjvliqxisa	2023-11-05 15:11:18+00	\N	tech house
4831	80	6VwhJRDeAUuSnNhyyqrifx	\N	Neverland	RAM, KOMMO, Noize MC	313neyxbfwxtbi2t52gjvliqxisa	2023-10-22 14:46:29+00	\N	rap
4860	81	6tk1LRABEXt2zygYj3jmPt	\N	RAVEN	Grey, Virtual Riot	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-16 22:21:22+00	\N	dubstep
4837	80	7w5AOd6HrDIHewHfpABEss	\N	Wicked Game	Chris Isaak	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-22 21:49:35+00	\N	rock
4866	81	6emZMVNvIxW57fhxPlyxLp	\N	Pump It	Electric Callboy	313neyxbfwxtbi2t52gjvliqxisa	2023-10-19 13:23:16+00	\N	metalcore, metal
4830	80	7edN1zsBhEfrO2OJhhIPw4	\N	Spell It Out	You Me At Six	313neyxbfwxtbi2t52gjvliqxisa	2023-10-22 14:44:07+00	\N	pop punk
4852	81	7oJPmo2YL566okOf1RQcCp	\N	luv(drunk)	Conro	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-16 17:46:44+00	\N	future bass
4875	82	7pU9qp93eWPCbwNbyPUVhM	\N	Back 2 Basics	Rome in Silver	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-09 08:36:35+00	\N	future bass
4838	80	0UQJ3UiyzbGsj4Rbfs0utS	\N	Kiss	SEREBRO	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-22 21:49:35+00	\N	pop
4885	82	0Z0565Zzxw8N8XlMPLIMNK	\N	Омут	MARUSHOVA	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-09 09:18:50+00	\N	pop
4907	83	0LzidBf7cUsnZnG34OUPSF	\N	Mosquito	PinkPantheress	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-04 19:22:14+00	\N	bedroom pop
4898	82	1VGzxJnVQND7Cg5H5wGj14	\N	YEAH RIGHT	Joji	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-14 16:53:37+00	\N	pop
4928	84	0gsTWFdIpTZUlw19Jb4Us6	\N	Для тоски тут места нет	Grizzly Knows No Remorse	313neyxbfwxtbi2t52gjvliqxisa	2023-09-26 12:51:24+00	\N	melodic hardcore
4914	83	0lTvhA48di9K9ep3HqRDrP	\N	Atlas	Mark Villa	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-05 11:44:42+00	\N	future house
4901	83	0p4IaGVXgk7cjhnjRa56o7	\N	Silence	ONEIL, Giorgio Gee, Sara Phillips, KANVISE	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-04 19:01:39+00	\N	slap house, g-house
4910	83	1Fbng31OXEiZCm1IYpoCvh	\N	Lovin’ Me - Live Studio Ver. OT4	FIFTY FIFTY	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-04 19:28:33+00	\N	k-pop
4923	84	1GeKP56LiSW6jAYyDoXjA9	\N	NEW_WORLD	Code: Pandorum, Wasiu	1qzcdqlwqtm8lnthmvh2a70p9	2023-09-26 11:02:09+00	\N	deathstep, dubstep, riddim, bass music
4939	84	1Uifdytv882RtTn6Gr4xAA	\N	Chokehold	Sleep Token	313neyxbfwxtbi2t52gjvliqxisa	2023-10-02 07:09:20+00	\N	progressive metal, metalcore
4896	82	1gyOMzgUD3pT6hYFxWWSxD	\N	She	cutted files	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-11 14:54:01+00	\N	electronic
4888	82	1XL71zPZ4xI63xphOSrd75	\N	Bandoleros	Don Omar, Tego Calderón	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-09 09:22:14+00	\N	reggaeton, urbano latino
4924	84	1cPPZzOaT32t4JMYjac5aU	\N	BUBBLES	Oshi	1qzcdqlwqtm8lnthmvh2a70p9	2023-09-26 11:09:36+00	\N	future bass
4915	83	1jue5QeGJWJPEQiQafWllV	\N	Over You	Inpetto	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-05 11:54:37+00	\N	future house, electro house
4892	82	1snNAXmmPXCn0dkF9DaPWw	\N	You & Me - Flume Remix	Disclosure, Eliza Doolittle, Flume	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-09 09:23:49+00	\N	house
4909	83	2iyQb2QFVZdZiunxRkk9Wx	\N	Past Lives - sped up	sapientdream, Slushii	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-04 19:25:41+00	\N	future bass
4932	84	2RhKxrhti1jd1Krzh968Cb	\N	Intoxicated - Radio Edit	Martin Solveig, Good Times Ahead	313neyxbfwxtbi2t52gjvliqxisa	2023-09-26 14:09:45+00	\N	french house
4906	83	2kdRdVrK6iIfo9qIZCxgJR	\N	Pegasus	Mountain	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-04 19:05:54+00	\N	drum and bass, liquid funk
4929	84	487iwobWkzgc12M3K7rvRV	\N	Берегом	Gruppa Skryptonite, ЯАVЬ	313neyxbfwxtbi2t52gjvliqxisa	2023-09-26 12:51:39+00	\N	hip hop
4930	84	39vKG9SPBYREBY8dhjuT7e	\N	Бег	Ермак!	313neyxbfwxtbi2t52gjvliqxisa	2023-09-26 12:51:53+00	\N	post-hardcore
4890	82	3MOECVkNshqHYTPt5DZcdN	\N	Five More Hours	Deorro, Chris Brown	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-09 09:22:52+00	\N	melbourne bounce, electro house
4904	83	3aNxfCcd9EohIxKmcQv1zn	\N	Eternity	Timmy Trumpet, KSHMR, Bassjackers	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-04 19:04:10+00	\N	melbourne bounce, big room
4894	82	3avYqdwHKEq8beXbeWCKqJ	\N	Last Friday Night (T.G.I.F.)	Katy Perry	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-09 09:24:40+00	\N	pop
4912	83	3zptIHCyfvKTS8Wnt1p6hI	\N	Days Before Grace	ZHU	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-04 19:47:07+00	\N	edm
4913	83	43aktSsHN3Pgu0dzw3BS5W	\N	Memory Bank	Dyro, Conro	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-04 19:55:55+00	\N	electro house, big room, edm
4934	84	4EfLrGnot3wYGfVkwDGX1m	\N	Какого	БЫДЛОЦЫКЛ	313neyxbfwxtbi2t52gjvliqxisa	2023-09-27 07:25:51+00	\N	punk
4938	84	4sebUbjqbcgDSwG6PbSGI0	\N	Come a Little Closer	Cage The Elephant	313neyxbfwxtbi2t52gjvliqxisa	2023-09-29 06:14:41+00	\N	alternative rock
4905	83	4JoSZjy556dgNPfcW3T2Xv	\N	F Minor Simulator	MUZZ	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-04 19:05:33+00	\N	drum and bass, drumstep, dubstep
4925	84	4cJJVxs9tMBNsH9yP2d20s	\N	Kababo	Pablo Fierro, Atmos Blaq	1qzcdqlwqtm8lnthmvh2a70p9	2023-09-26 11:10:10+00	\N	afro house, afro tech, tribal house, latin house, deep house, organic house
4937	84	4yNk9iz9WVJikRFle3XEvn	\N	golden hour	JVKE	313neyxbfwxtbi2t52gjvliqxisa	2023-09-27 23:11:39+00	\N	pop
4916	83	4x7lYEyEcf0zyKCDcJDzD4	\N	Follow You Anywhere	Cosmic Gate, Nathan Nicholson	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-05 12:17:03+00	\N	trance, progressive trance
4918	83	53Ssvy5Rww0BPTtOw375zW	\N	Sleeptalk	Dayseeker	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-05 21:06:32+00	\N	metalcore, post-hardcore
4908	83	5AvbixdcGe6TOwfte5lB3A	\N	Calling For You	Venjent, Oktae	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-04 19:22:55+00	\N	drum and bass
4940	84	5V3EXnYq2cw6tuZsy7PuIb	\N	Королева	Каролина	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-02 16:45:34+00	\N	pop
4927	84	5XS3lOIRi2goJIcKMwEnOE	\N	Lose Your Head - CamelPhat Remix	London Grammar, CamelPhat	1qzcdqlwqtm8lnthmvh2a70p9	2023-09-26 11:19:19+00	\N	house
4936	84	6HkLE4NBxzqkpzo4N5xOTi	\N	Подарю	BRANYA	1qzcdqlwqtm8lnthmvh2a70p9	2023-09-27 09:56:21+00	\N	pop
4884	82	5bLnab0c8Y9gVLDnLKdsfF	\N	Another Chance - Don Diablo Chill Mix	Big Pineapple, Don Diablo	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-09 09:07:29+00	\N	future house
4886	82	5ka2ajep9OAvU5Sgduhiex	\N	Applause	Lady Gaga	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-09 09:20:50+00	\N	art pop, pop
4911	83	5wJdTLZ9B1VwAv4TSDOzeq	\N	Talk	Going Deeper, POLINA	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-04 19:29:37+00	\N	future house, deep house
4917	83	6ABHErMkKctWN1uTBnyU5s	\N	Riziki	Pippi Ciez, Idd Aziz	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-05 17:48:54+00	\N	afro house, afro tech, organic house, tribal house
4891	82	6NncjnSD7JLEetWb9KqMRY	\N	I Wanna Love You	Akon, Snoop Dogg	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-09 09:23:17+00	\N	r&b
4893	82	6R0GRYk2vs2XuBVemYK5YZ	\N	Ultimate	Denzel Curry	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-09 09:24:20+00	\N	rap
4903	83	7o6QMEWHa18PqCruNrKxPa	\N	Я помню (Woo)	FEDUK, Biicla	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-04 19:03:56+00	\N	electronic
4897	82	6q5M4lviydCEB4zZ6uYM9s	\N	Bullet Train	HVDES, Joni Fatora	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-11 21:47:36+00	\N	deathstep, dubstep
4900	83	0GoJGQUbK1MrRzYoQZzgjI	\N	Делай добро	AK-47	1qzcdqlwqtm8lnthmvh2a70p9	2023-10-03 18:39:48+00	\N	rap
4977	87	0NuU0NSvpW2KDqyUYAiuqN	\N	Точка	Bolshevseh	1qzcdqlwqtm8lnthmvh2a70p9	2023-08-03 11:43:52+00	\N	pop
4971	87	0bmQ5H9mHFzRnJ4ZntylFg	\N	Somewhere (feat. Gus Dapperton)	Surf Mesa, Gus Dapperton	1qzcdqlwqtm8lnthmvh2a70p9	2023-07-28 07:39:45+00	\N	electronic
4995	88	0uNlsRmW2hrU5UKtBMZE7A	\N	IVL	MACAN, SCIRENA	1qzcdqlwqtm8lnthmvh2a70p9	2023-07-18 20:03:46+00	\N	electronic
4942	85	0Q6vVLxQ6gl6NFMQka3Q9X	\N	BADDER	Angrybaby	313neyxbfwxtbi2t52gjvliqxisa	2023-09-17 23:46:08+00	\N	stutter house
4956	85	1mBtrVS6hLeqcVecvpAqBJ	\N	lose it all	Sam Tompkins	1qzcdqlwqtm8lnthmvh2a70p9	2023-09-24 19:25:39+00	\N	pop
4958	86	0h2ZSu1j6YFsGj85eSyrI4	\N	Ground Shake	Crankdat, Bandlez	313neyxbfwxtbi2t52gjvliqxisa	2023-08-29 06:34:13+00	\N	dubstep, riddim, edm, deathstep, bass house
4945	85	1olCzMxaeiQKNO64ssWVGr	\N	Talk About	Rain Radio, DJ Craig Gorman	1qzcdqlwqtm8lnthmvh2a70p9	2023-09-20 19:19:44+00	\N	house
4960	86	1JxAQqHMOHBscJlTCL3m8y	\N	You Found Me	Our Last Night	313neyxbfwxtbi2t52gjvliqxisa	2023-08-31 14:58:33+00	\N	post-hardcore, metalcore
4998	88	1dFkD1JfRMzwO6hwUsE8aS	\N	Spectrum	Zedd, Matthew Koma	1qzcdqlwqtm8lnthmvh2a70p9	2023-07-18 21:54:32+00	\N	edm
4949	85	29Hs0AdqnVUoPe3llVZ2fZ	\N	Stand In Line	Sevek, Future Class, RYVM	313neyxbfwxtbi2t52gjvliqxisa	2023-09-23 01:13:04+00	\N	electronic
4980	87	2DHlUa91RQv4dwXdsKLRrt	\N	Sun	Diotic	1qzcdqlwqtm8lnthmvh2a70p9	2023-08-05 14:32:33+00	\N	electronic
4974	87	2HNeMETowwHKIuSefhXi8r	\N	DARKSIDE	AKADO	1qzcdqlwqtm8lnthmvh2a70p9	2023-07-31 09:52:26+00	\N	electronic
5000	88	3WmHVMkH9zkzEvEQE53IXe	\N	Slow Down - Harvo Remix	CuBox, NDMZ, harvo	1qzcdqlwqtm8lnthmvh2a70p9	2023-07-19 12:35:39+00	\N	house
4964	86	2Gt7fjNlx901pPRkvBiNBZ	\N	Take Me Back To Eden	Sleep Token	313neyxbfwxtbi2t52gjvliqxisa	2023-08-31 14:59:00+00	\N	progressive metal, metalcore
4954	85	3gIqmWiOC8BI0iN2KvOIxN	\N	傀儡謡_怨恨みて散る	西田和枝社中	1qzcdqlwqtm8lnthmvh2a70p9	2023-09-23 08:42:58+00	\N	anime
4990	87	2VIqtXdmYXXmeErgJSwfv0	\N	Feels Like - Nezhdan Remix	Zhoneus Deep, Nezhdan	1qzcdqlwqtm8lnthmvh2a70p9	2023-08-15 07:47:53+00	\N	deep house
4991	87	2XtWeW8EPug4y2Z3e4zHr3	\N	Wonder Where You Are	Da Buzz	1qzcdqlwqtm8lnthmvh2a70p9	2023-08-15 07:50:04+00	\N	eurodance, europop, swedish pop
4946	85	2hU9S9x1uciKpOS5BqWqeq	\N	Bullet Boy (Vox) - 2006 Digital Remaster	Massive Attack	1qzcdqlwqtm8lnthmvh2a70p9	2023-09-20 20:22:00+00	\N	trip hop, downtempo
4943	85	32fmwlkq7srmOAb5N0vdyj	\N	Echo	RSCL, Repiet, Julia Kleijn	313neyxbfwxtbi2t52gjvliqxisa	2023-09-17 23:47:26+00	\N	stutter house, house
4948	85	3I2fSFoM1QZsyTIWApi1sR	\N	Krazy	VASSY	313neyxbfwxtbi2t52gjvliqxisa	2023-09-23 01:12:20+00	\N	electronica
4968	86	3PsQcSCxyOm5l96rQfEjVA	\N	Balling - LÄUFF Remix	Vibe Chemistry, LÄUFF	313neyxbfwxtbi2t52gjvliqxisa	2023-09-15 13:37:22+00	\N	drum and bass, liquid funk
4973	87	3VWFowqaGcjOmzVKhErJcK	\N	Unspoken - Dance with the Dead Remix - Edit	The Dead Daisies, Dance With the Dead	1qzcdqlwqtm8lnthmvh2a70p9	2023-07-31 09:51:50+00	\N	hard rock
4992	87	3WEkP073qFPRdswFYJPBT7	\N	The Light - Damaged Goods Remix	Tchami, Damaged Goods	1qzcdqlwqtm8lnthmvh2a70p9	2023-08-15 07:51:55+00	\N	future house, bass house, g-house, house
4952	85	3mUN3ODbYMtF34rk68aAuX	\N	Summer In Love	THAT KIND	313neyxbfwxtbi2t52gjvliqxisa	2023-09-23 03:05:26+00	\N	pop
4941	85	3pmr55igD9GfvMICXV85i5	\N	Mami	JAMIK	1qzcdqlwqtm8lnthmvh2a70p9	2023-09-19 18:31:56+00	\N	pop
4985	87	4D1eVq5AUILwjg3tAe7o6M	\N	On My Own	Jaden, Kid Cudi	1qzcdqlwqtm8lnthmvh2a70p9	2023-08-15 06:03:23+00	\N	hip hop
4951	85	4SArfYG88J75TwixvfACPF	\N	Let A Little Light In - RobbieG Remix	Everyone You Know, RobbieG	313neyxbfwxtbi2t52gjvliqxisa	2023-09-23 02:57:19+00	\N	electronic
4979	87	43NE8RR5PF8OXxcvMBG3WN	\N	Yǔ	Catching Flies	1qzcdqlwqtm8lnthmvh2a70p9	2023-08-04 10:28:19+00	\N	downtempo
4963	86	45PTrr4FJEnZjWVr280Sm5	\N	Эпизод VII: Разбуди меня	Ермак!, Affinage	313neyxbfwxtbi2t52gjvliqxisa	2023-08-31 14:58:56+00	\N	post-hardcore
4987	87	4X9UECZ0FHmGeXi66i9Y33	\N	Не Любовь	Marakesh	1qzcdqlwqtm8lnthmvh2a70p9	2023-08-15 07:26:17+00	\N	pop
4947	85	4JHg4nNYUJQ5HULcCmI18R	\N	What You Know	Two Door Cinema Club	1qzcdqlwqtm8lnthmvh2a70p9	2023-09-21 05:27:43+00	\N	indie, indie rock
4986	87	4y4spB9m0Q6026KfkAvy9Q	\N	Lonely (with benny blanco)	Justin Bieber, benny blanco	1qzcdqlwqtm8lnthmvh2a70p9	2023-08-15 06:04:42+00	\N	pop
4965	86	4UxVI8QFrw0yBJX8ZwItbc	\N	Ветром стать	Wildways	313neyxbfwxtbi2t52gjvliqxisa	2023-08-31 15:01:47+00	\N	metalcore, post-hardcore
4984	87	5m9Oa79lqWTRxTmHjbxOX3	\N	P	Jaden	1qzcdqlwqtm8lnthmvh2a70p9	2023-08-15 06:02:12+00	\N	rap
4997	88	4bT2zLVv2T4GiK9q9KtI0v	\N	Stay The Night - Featuring Hayley Williams Of Paramore	Zedd, Hayley Williams	1qzcdqlwqtm8lnthmvh2a70p9	2023-07-18 21:53:31+00	\N	edm
4975	87	4wIOMZhMekKeDs0jRIbTxb	\N	Gotta Get Thru This - D'N'D Radio Edit	Daniel Bedingfield, D'N'D Productions	1qzcdqlwqtm8lnthmvh2a70p9	2023-07-31 10:33:37+00	\N	uk garage
4959	86	62RGkq5msTT3NP780ZNGFt	\N	Серебро и ртуть	Зимавсегда, Аффинаж	313neyxbfwxtbi2t52gjvliqxisa	2023-08-31 14:58:27+00	\N	indie
4988	87	5gusADrGCRfFSewILLmGP6	\N	Prettiest Virgin	Agar Agar	1qzcdqlwqtm8lnthmvh2a70p9	2023-08-15 07:34:08+00	\N	french indie pop
4962	86	7kD1wSkvrDaX2e8Rizn3KJ	\N	Нью-Йорк - Soft Version	Affinage	313neyxbfwxtbi2t52gjvliqxisa	2023-08-31 14:58:44+00	\N	downtempo
4996	88	60wwxj6Dd9NJlirf84wr2c	\N	Clarity	Zedd, Foxes	1qzcdqlwqtm8lnthmvh2a70p9	2023-07-18 21:53:21+00	\N	edm
4982	87	7wQlEPz7M6TvqkuCFma4yc	\N	Now I'm The Fool	Angelina Jordan	1qzcdqlwqtm8lnthmvh2a70p9	2023-08-11 19:12:28+00	\N	r&b
4989	87	6EPmqY5JvwbWhX1SmydclT	\N	Looking Down From The Edge	blessthefall	1qzcdqlwqtm8lnthmvh2a70p9	2023-08-15 07:42:58+00	\N	metalcore, post-hardcore, screamo
4967	86	6qTkdXCGh1AiGmP8aWAI9g	\N	Judas	Magellan Starchild, John B, The Young Punx	313neyxbfwxtbi2t52gjvliqxisa	2023-09-01 06:11:50+00	\N	drum and bass
4961	86	6tRneEcItwpSxBtqgem5Dr	\N	THE DEATH OF PEACE OF MIND	Bad Omens	313neyxbfwxtbi2t52gjvliqxisa	2023-08-31 14:58:40+00	\N	metalcore
4994	88	7GUJUmtwppLsmuAzBnFWYa	\N	Renegade	Aaryan Shah	1qzcdqlwqtm8lnthmvh2a70p9	2023-07-17 10:13:53+00	\N	dark r&b
4953	85	7nbuGxQ7TfJXb9OgH3xJEr	\N	Forget It	Matroda	313neyxbfwxtbi2t52gjvliqxisa	2023-09-23 03:26:19+00	\N	bass house, tech house, g-house, house, electro house
4978	87	7qUk9cccoWEwEaZQzIac98	\N	reason8	Gosha	1qzcdqlwqtm8lnthmvh2a70p9	2023-08-04 10:26:17+00	\N	deep house
4957	85	0GTuyzPTs2G0wqFD1trSOw	\N	Phone	MEDUZA, Sam Tompkins, Em Beihold	1qzcdqlwqtm8lnthmvh2a70p9	2023-09-24 19:28:50+00	\N	house
5037	90	0LjTqBwFKfblqnuuDCH2Sw	\N	Flat Beat - Radio Edit	Mr. Oizo	1qzcdqlwqtm8lnthmvh2a70p9	2023-07-04 09:21:32+00	\N	french house
5025	89	0LszuTLIa14PGJYSYmmJbh	\N	Still Here	Fox Stevenson	313neyxbfwxtbi2t52gjvliqxisa	2023-07-13 12:06:04+00	\N	drum and bass, dubstep, drumstep
5014	89	0kxVhuTPJMtAP3dj9Q7tuG	\N	One Ting	Phibes	313neyxbfwxtbi2t52gjvliqxisa	2023-07-10 02:03:00+00	\N	drum and bass, bassline, bass house, jungle
5017	89	1VJ4iz2VkOZLLvPx1oSGio	\N	Woah	Memblem	1qzcdqlwqtm8lnthmvh2a70p9	2023-07-12 15:46:41+00	\N	phonk
5031	90	17LAsrJETGWz5exZbrIPYo	\N	Uletai	Krasa Rosa	1qzcdqlwqtm8lnthmvh2a70p9	2023-07-03 17:23:33+00	\N	organic house, melodic house, progressive house
5047	90	1eivMnftGIAIeTDUfTssVX	\N	Welcome to the DCC	Nothing But Thieves	313neyxbfwxtbi2t52gjvliqxisa	2023-07-08 01:12:02+00	\N	alternative rock
5016	89	1R9TSAApxJX05C45ulFhQ7	\N	Warmth	Lethr	1qzcdqlwqtm8lnthmvh2a70p9	2023-07-12 15:45:59+00	\N	future bass
5026	89	1RcKEwbDLoLLkwCng0DzZq	\N	Signal	Rezz, Grabbitz	313neyxbfwxtbi2t52gjvliqxisa	2023-07-13 12:23:29+00	\N	edm, dubstep
5035	90	1ipv1KT6Bfs557nOMuPsIJ	\N	Ok Roswell	For Breakfast	1qzcdqlwqtm8lnthmvh2a70p9	2023-07-04 09:06:41+00	\N	indie
5033	90	2bA4qBF3S30cH0SS5imQQh	\N	Like This	MAGNUS	1qzcdqlwqtm8lnthmvh2a70p9	2023-07-04 08:39:16+00	\N	house
5060	91	2g3Rz00IoWB5ZZKk5Cf5Ss	\N	Black & White	Free Flow Flava	1qzcdqlwqtm8lnthmvh2a70p9	2023-06-25 19:53:00+00	\N	hip hop
5058	91	1sURUh8IehzWWp4udnhMpj	\N	Butterfly Effect - VIP	Koven	1qzcdqlwqtm8lnthmvh2a70p9	2023-06-25 19:31:15+00	\N	drum and bass, liquid funk, drumstep, chillstep
5018	89	2KTpfjsaVpuT6Zlf1icOW0	\N	14th Cannon	Koven	1qzcdqlwqtm8lnthmvh2a70p9	2023-07-12 20:33:33+00	\N	drum and bass, liquid funk, drumstep, chillstep
5034	90	2ML36GkVssb1x7VLGWgUYo	\N	Coltrane	Eades	1qzcdqlwqtm8lnthmvh2a70p9	2023-07-04 09:00:50+00	\N	post-punk
5050	90	2gxnxS35i6psXdWb2wNHkE	\N	Katana	Lead Horizon	313neyxbfwxtbi2t52gjvliqxisa	2023-07-09 10:56:38+00	\N	metal
5012	88	3HAL8zLf2kvd9o8pzapMyR	\N	Parachute	Matthew Koma	1qzcdqlwqtm8lnthmvh2a70p9	2023-07-23 13:04:56+00	\N	pop
5052	90	3JLgiop9jcsgYG070rsE9s	\N	Take Ü There (feat. Kiesza) - Tchami Remix	Jack Ü, Skrillex, Diplo, Kiesza, Tchami	1qzcdqlwqtm8lnthmvh2a70p9	2023-07-09 12:34:03+00	\N	dubstep
5022	89	2jI4MUnMNPEPqUhSOUsvDf	\N	La Fournaise (feat. josh pan)	IMANU, The Caracal Project, josh pan	1qzcdqlwqtm8lnthmvh2a70p9	2023-07-12 20:53:45+00	\N	drum and bass, drumstep
5057	91	2jVx9xpoypGbdrTlK4jJTS	\N	Lose Control	Bare Up	1qzcdqlwqtm8lnthmvh2a70p9	2023-06-25 19:22:43+00	\N	drum and bass
5009	88	2nQyEHecmmt0WE43mOsScr	\N	Back To Me	Krakota, Fred V, Tudor	1qzcdqlwqtm8lnthmvh2a70p9	2023-07-21 11:53:10+00	\N	drum and bass, liquid funk
5054	91	2pgDBO0ZAgvye7joSmdDm8	\N	SAD GIRLZ LUV MONEY	Amaarae, MOLIY	1qzcdqlwqtm8lnthmvh2a70p9	2023-06-25 18:59:28+00	\N	alté, afrobeats, afro r&b
5042	90	2pqFghgcLFEnrfkVoYqJBl	\N	Shelter	Flowidus	313neyxbfwxtbi2t52gjvliqxisa	2023-07-05 23:25:08+00	\N	drum and bass, liquid funk
5038	90	3ARm0Eqq7CcBWZxWlTmRLH	\N	Hun	Mr. Oizo	1qzcdqlwqtm8lnthmvh2a70p9	2023-07-04 09:24:27+00	\N	french house
5002	88	3ZuGuAoslldTYU4utXyDEW	\N	Gotta Go	Falling Decibyls	1qzcdqlwqtm8lnthmvh2a70p9	2023-07-20 10:20:18+00	\N	rock
5046	90	4SykS8RWkF6eK6xeua7XLP	\N	Monsters	James Blunt	1qzcdqlwqtm8lnthmvh2a70p9	2023-07-07 19:04:49+00	\N	pop
5040	90	3LakWxXfyJkveLGXV0n4yT	\N	Sirene	Kohen, RUSHÖ	313neyxbfwxtbi2t52gjvliqxisa	2023-07-05 15:02:34+00	\N	brazilian bass, electronic
5028	89	3QAIxklkjjApJX9hD6fDVb	\N	Not the same	Samantha Mogwe	1qzcdqlwqtm8lnthmvh2a70p9	2023-07-16 11:48:11+00	\N	afro soul
5062	91	4qKNAi3XOvdjmGvrHA9jNl	\N	Чудо	Affinage	313neyxbfwxtbi2t52gjvliqxisa	2023-06-26 12:54:14+00	\N	pop
5045	90	3nOg31lPxRYK0Y0o1XoAf0	\N	JSYK	Pauline Herr	1qzcdqlwqtm8lnthmvh2a70p9	2023-07-06 06:36:36+00	\N	future bass, melodic bass
5003	88	5AGqNhMSKRQeBYow4LkXRV	\N	Désolée (Paris/Paname) - PARØ Remix	SHANGUY, PARØ	1qzcdqlwqtm8lnthmvh2a70p9	2023-07-20 10:23:25+00	\N	electronic
5011	88	5iwkNrw0txyI7kx59ip9JT	\N	Flows	Chris TheOdian	1qzcdqlwqtm8lnthmvh2a70p9	2023-07-21 19:22:07+00	\N	hip hop
5015	89	59eGliCQ66gx1Bg9YxMJuz	\N	Planet E - Skee Mask Remix	Wladimir M., Skee Mask	1qzcdqlwqtm8lnthmvh2a70p9	2023-07-12 15:43:06+00	\N	breakbeat
5005	88	6Pwn8J1A2JrxzDiHMxLz3k	\N	Ready	Zip Zip Through The Night	1qzcdqlwqtm8lnthmvh2a70p9	2023-07-20 12:40:13+00	\N	electronic
5001	88	5h814ILMj31mmADyVsdeh0	\N	Think	Venjent	313neyxbfwxtbi2t52gjvliqxisa	2023-07-19 22:56:56+00	\N	drum and bass
5044	90	6U93jRV9dWOPtdqsQSDeUy	\N	fool me once	nightlife	313neyxbfwxtbi2t52gjvliqxisa	2023-07-06 03:20:26+00	\N	downtempo
5039	90	5qNwntdO5v6uFrR4P7gBLP	\N	falling down	théos	313neyxbfwxtbi2t52gjvliqxisa	2023-07-04 22:54:24+00	\N	dark ambient
5043	90	5tX0DIjtn9oUzPf1wrtYcz	\N	Your Pain	Koven	313neyxbfwxtbi2t52gjvliqxisa	2023-07-05 23:27:03+00	\N	drum and bass, liquid funk, drumstep, chillstep
5019	89	6DfESv6z9PPLo1RhbzlVIb	\N	All We Needed	Koven	1qzcdqlwqtm8lnthmvh2a70p9	2023-07-12 20:51:48+00	\N	drum and bass, liquid funk, drumstep, chillstep
5049	90	6Jpzso3AbDhLsA2lpSjkVH	\N	Crash	The Bloody Beetroots, Jason Aalon Butler	313neyxbfwxtbi2t52gjvliqxisa	2023-07-09 08:28:56+00	\N	electro house
5048	90	6mg5L3jQ96AfEtIJ1pTXKe	\N	Chicki	Said Energizer	1qzcdqlwqtm8lnthmvh2a70p9	2023-07-08 18:57:31+00	\N	electronic
5059	91	6rH6a6xRZ9SU1aWo8ntr4n	\N	Your Blood	Nothing But Thieves	1qzcdqlwqtm8lnthmvh2a70p9	2023-06-25 19:46:23+00	\N	alternative rock
5055	91	6VRRu9NewkmX12BMCvCJQ1	\N	BACKBONE	DROELOE, Nevve	1qzcdqlwqtm8lnthmvh2a70p9	2023-06-25 19:11:45+00	\N	future bass
5020	89	6eV7tM9kx9zPFOxoO7vkDc	\N	The lights on your face.	The Caracal Project	1qzcdqlwqtm8lnthmvh2a70p9	2023-07-12 20:52:55+00	\N	drum and bass, liquid funk, drumstep
5032	90	74ezY3rQddxQCPwRmMHkZm	\N	Rihanna	Azizi Gibson	1qzcdqlwqtm8lnthmvh2a70p9	2023-07-03 17:31:07+00	\N	hip hop
5007	88	6mo88PgAWke0VsVbFmABoT	\N	TROUBLEMAKER	F.O.O.L	1qzcdqlwqtm8lnthmvh2a70p9	2023-07-21 11:34:06+00	\N	synthwave
5013	89	7GaXAknKJeuzXm5LVI4Qjd	\N	Try	Mandy Harvey	1qzcdqlwqtm8lnthmvh2a70p9	2023-07-09 16:57:55+00	\N	pop
5036	90	7haaDMp101E6QaYbbgfkEY	\N	I Got The Feeling	Brixton Chamber Orchestra	1qzcdqlwqtm8lnthmvh2a70p9	2023-07-04 09:07:49+00	\N	classical
5056	91	76AYOdnKWcSLviCsKDXyS1	\N	Sick Like Me	In This Moment	1qzcdqlwqtm8lnthmvh2a70p9	2023-06-25 19:15:15+00	\N	metal
5024	89	7KibjIxYJsdP9UGjjMUEn6	\N	Libre	Habstrakt, IMANU	1qzcdqlwqtm8lnthmvh2a70p9	2023-07-12 21:10:14+00	\N	bass house, g-house, dubstep, bassline
5004	88	16Cn3glUv9usZKmSepH6XG	\N	I'll Been Waiting - Radio Edit	Dear David	1qzcdqlwqtm8lnthmvh2a70p9	2023-07-20 10:39:11+00	\N	pop
5088	92	0GXcaInd0GoTg6vUBlXYpW	\N	Stereocoma	Thomas Mraz, Oxxxymiron	1qzcdqlwqtm8lnthmvh2a70p9	2023-06-25 15:49:44+00	\N	rap
5094	92	0CjJJrpnQCpQMsT4nzezII	\N	Halo	Pendulum, Bullet For My Valentine	1qzcdqlwqtm8lnthmvh2a70p9	2023-06-25 17:18:36+00	\N	drum and bass, dubstep
5080	91	0Cv7pfVZT1KjaqpylUsYQH	\N	Vertigo	Curbi, PollyAnna	1qzcdqlwqtm8lnthmvh2a70p9	2023-07-02 14:08:06+00	\N	future house, bass house
5099	92	0wbDgMuAoy7O7pL3a69uZx	\N	Give It To Me	Timbaland, Justin Timberlake, Nelly Furtado	1qzcdqlwqtm8lnthmvh2a70p9	2023-06-25 17:28:02+00	\N	hip hop
5070	91	0bhRroouFZ25OrNUcnKTMS	\N	Good Times Bad Times - Document One Remix	Camo & Krooked, Document One	313neyxbfwxtbi2t52gjvliqxisa	2023-06-30 16:46:34+00	\N	drum and bass, liquid funk, drumstep, dubstep
5067	91	0u0oY2WuHC8B22p5nF8qsU	\N	When I Talk	deadmau5, Kaskade, Elderbrook, Kx5	1qzcdqlwqtm8lnthmvh2a70p9	2023-06-29 07:55:35+00	\N	edm, progressive house, dubstep
5090	92	1ACFweuuvf6MHtptObgreR	\N	Giving Me	Jazzy	1qzcdqlwqtm8lnthmvh2a70p9	2023-06-25 16:39:53+00	\N	jazz
5065	91	1S8P1AfWgcpmZ5FrM98UpA	\N	Boomerang - Live	Yebba	1qzcdqlwqtm8lnthmvh2a70p9	2023-06-26 14:07:01+00	\N	r&b
5092	92	1DmW5Ep6ywYwxc2HMT5BG6	\N	Tattoo	Loreen	1qzcdqlwqtm8lnthmvh2a70p9	2023-06-25 16:41:26+00	\N	europop
5087	92	1f6FGeObxehgFr9AkH02U2	\N	Мятный	Markul, FEDUK	1qzcdqlwqtm8lnthmvh2a70p9	2023-06-25 15:32:02+00	\N	rap
5077	91	1WkzL4XjkAY76sasIUdU6l	\N	Wildfire	Natascha Polké	1qzcdqlwqtm8lnthmvh2a70p9	2023-07-02 13:55:42+00	\N	melodic house, deep house
5085	92	1yrQI5Ycgi7xU9P4i98NXL	\N	Отпускай	Три дня дождя	1qzcdqlwqtm8lnthmvh2a70p9	2023-06-25 15:20:13+00	\N	rock
5063	91	2BXkaiqV2F2HNdrvR4JvMz	\N	Можешь лететь	Аффинаж, Animal Jazz	313neyxbfwxtbi2t52gjvliqxisa	2023-06-26 12:59:59+00	\N	folk
5066	91	2UWnZrXLXIyfMgNvJr2KUa	\N	By Any Means	Jorja Smith	1qzcdqlwqtm8lnthmvh2a70p9	2023-06-26 15:19:55+00	\N	r&b
5073	91	2Gwf93mmShALO75w5K3DG0	\N	Oxygen - Franky Wah Remix	Gorgon City, Aura James, Franky Wah	1qzcdqlwqtm8lnthmvh2a70p9	2023-07-02 11:28:42+00	\N	house
5072	91	2LxdNADWier3MKTei8FbOY	\N	I Was Made For Lovin' You (feat. Nile Rodgers & House Gospel Choir)	Oliver Heldens, Nile Rodgers, House Gospel Choir	1qzcdqlwqtm8lnthmvh2a70p9	2023-07-02 11:20:55+00	\N	future house, house
5064	91	454I78HEySdcHE8fcVabTb	\N	Amsterdam	Nothing But Thieves	1qzcdqlwqtm8lnthmvh2a70p9	2023-06-26 13:56:54+00	\N	alternative rock
5103	92	2igwFfvr1OAGX9SKDCPBwO	\N	Empire State Of Mind	JAŸ-Z, Alicia Keys	1qzcdqlwqtm8lnthmvh2a70p9	2023-06-25 17:29:54+00	\N	hip hop, east coast hip hop, rap
5079	91	36iU4gfHhUbjwk88kZAwgW	\N	THREE IN THE MORNING	k?d, Cecilia Gault	1qzcdqlwqtm8lnthmvh2a70p9	2023-07-02 14:07:46+00	\N	future bass, melodic bass
5082	92	3qQbCzHBycnDpGskqOWY0E	\N	Ella Baila Sola	Eslabon Armado, Peso Pluma	1qzcdqlwqtm8lnthmvh2a70p9	2023-06-25 15:08:40+00	\N	corridos tumbados, sad sierreño, corrido, sierreño, música mexicana, corridos bélicos
5093	92	42LSQpK6JdGjqRttkxIoy1	\N	Gonna Be Good	Madeon	1qzcdqlwqtm8lnthmvh2a70p9	2023-06-25 17:18:33+00	\N	edm, french house
5100	92	4scpF6J5uMBvoh6sFB7EL1	\N	No Type	Rae Sremmurd	1qzcdqlwqtm8lnthmvh2a70p9	2023-06-25 17:28:30+00	\N	hip hop
5081	91	4Iw6e5hL3ynmUNV2tgClHL	\N	Chasing Clouds	Bad Computer, Danyka Nadeau	1qzcdqlwqtm8lnthmvh2a70p9	2023-07-02 14:29:06+00	\N	rally house
5102	92	4WWp3b9Hp4qFMOSncUjAQV	\N	Here She Comes Again	Röyksopp, Jamie Irrepressible	1qzcdqlwqtm8lnthmvh2a70p9	2023-06-25 17:28:58+00	\N	downtempo, electronica, trip hop
5095	92	4Yt2sewnvBtcj6qsh5rIkg	\N	Knockout	Dirty Palm	1qzcdqlwqtm8lnthmvh2a70p9	2023-06-25 17:19:25+00	\N	melbourne bounce, future house, bass house, bounce
5096	92	5NQqC3ksi3gBo0s2G9qhIL	\N	La Puta Ama (EDDIE Remix)	The Funk Hunters, LŪN, EDDIE	1qzcdqlwqtm8lnthmvh2a70p9	2023-06-25 17:20:07+00	\N	house
5084	92	4t6HBEh6WtSRagG3PiRwVE	\N	Я тебя тоже	Wildways, Mary Gu	1qzcdqlwqtm8lnthmvh2a70p9	2023-06-25 15:17:52+00	\N	metalcore, post-hardcore
5071	91	5H7NVUGfw8fstj1LWJ0wXo	\N	How Long Have You Been Away?	kryptogram	1qzcdqlwqtm8lnthmvh2a70p9	2023-07-02 11:05:26+00	\N	disco house, funky house
5083	92	5x8z33A0Tl115EJFVhebm2	\N	Control	Castle, Endspiel	1qzcdqlwqtm8lnthmvh2a70p9	2023-06-25 15:10:54+00	\N	electronic
5068	91	5Rmbyd3gL7IweiOy6AsBkd	\N	Reeces Pieces	Zero	1qzcdqlwqtm8lnthmvh2a70p9	2023-06-30 15:15:43+00	\N	bassline, uk garage, bass house, drum and bass
5091	92	5eTaQYBE1yrActixMAeLcZ	\N	Miracle (with Ellie Goulding)	Calvin Harris, Ellie Goulding	1qzcdqlwqtm8lnthmvh2a70p9	2023-06-25 16:40:16+00	\N	edm
5074	91	5num0Pphk7MKONGzvWXNNj	\N	Talk	BB Cooper	1qzcdqlwqtm8lnthmvh2a70p9	2023-07-02 11:37:11+00	\N	dark r&b
5101	92	6NncjnSD7JLEetWb9KqMRY	\N	I Wanna Love You	Akon, Snoop Dogg	1qzcdqlwqtm8lnthmvh2a70p9	2023-06-25 17:28:32+00	\N	r&b
5097	92	6WRRi9XsJ8K495McNBYgZl	\N	You Make Me Feel (Mighty Real)	Adam Lambert, Sigala	1qzcdqlwqtm8lnthmvh2a70p9	2023-06-25 17:22:53+00	\N	pop
5078	91	6OL6VUdv2DA4jyrk7rDOFL	\N	NEW GROUND	Juelz, KILLY, KILLY AI	1qzcdqlwqtm8lnthmvh2a70p9	2023-07-02 13:57:42+00	\N	edm trap, future bass
5069	91	71IjhbDK0oLN0coG0NIJtO	\N	Only If	Night Tales	313neyxbfwxtbi2t52gjvliqxisa	2023-06-30 16:11:59+00	\N	electronic
5104	92	6oSP5MHC4cNX0OXERIp8l5	\N	In These Shadows	Fytch, Carmen Forbes	1qzcdqlwqtm8lnthmvh2a70p9	2023-06-25 17:31:25+00	\N	dubstep, future bass
5089	92	6tAKikIvnoWfUeZrfkopLL	\N	Friesenjung	Ski Aggu, Joost, Otto Waalkes	1qzcdqlwqtm8lnthmvh2a70p9	2023-06-25 16:34:40+00	\N	german indie, german hip hop, german indie pop
5098	92	7epuzAuOHuPaL6CU0mPIBP	\N	Future is bright	Therr Maitz	1qzcdqlwqtm8lnthmvh2a70p9	2023-06-25 17:25:17+00	\N	electronic
5075	91	7o2jAl6Dn9aAEsSI15cwH5	\N	West Coast	Adam Lambert	1qzcdqlwqtm8lnthmvh2a70p9	2023-07-02 11:40:07+00	\N	pop
5086	92	7sEh4k8OdFJz9DF9JwAFWy	\N	Станция	Smoky Mo, GUF, DJ Cave, Lil Kate	1qzcdqlwqtm8lnthmvh2a70p9	2023-06-25 15:29:22+00	\N	hip hop
5076	91	7pgj6tSDzpL73tzrUaW4TP	\N	Watchtower	The Devil Wears Prada	1qzcdqlwqtm8lnthmvh2a70p9	2023-07-02 11:41:40+00	\N	metalcore, post-hardcore, screamo, deathcore, metal
5105	92	025vNWwy1w58qHrJnNH9ro	\N	Девушка мечты	Кирилл Нефтерев	1qzcdqlwqtm8lnthmvh2a70p9	2024-10-06 12:14:09+00	\N	pop
31	2	4oBKssLTIGrXWZwyWYTqbN	\N	Barajatr	dudeontheguitar, dododowson	31ghi62vkgnlb4wqr6muaisx7ldi	2026-03-31 11:36:08+00	Трек "Barajatr" был создан в рамках эксперимента по сочетанию разных музыкальных стилей, и заметно, как в нем переплетаются элементы фолка и электронной музыки. 🎶 \n\nИнтересно, что для записи вокала использовали необычные техники, включая запись звуков природы, что придает треку уникальную атмосферу. 🌿 \n\nКроме того, dudeontheguitar и dododowson впервые встретились на музыкальном фестивале и решили объединить свои силы, чтобы создать что-то действительно оригинальное. Это сотрудничество стало началом их дружбы и совместных проектов! 🤝	indie
33	2	0I5kavrL6aUxqMVYdtrReQ	\N	Late at Night	Mind Against, HUMAN404, Anakim	31ghi62vkgnlb4wqr6muaisx7ldi	2026-03-31 11:36:10+00	Этот трек "Late at Night" — настоящий коллаборационный шедевр! 🎶 Mind Against и HUMAN404 объединили свои силы с Anakim, чтобы создать атмосферный трек, который идеально вписывается в ночные вечеринки.\n\nИнтересно, что сам процесс создания музыки проходил в разных студиях, и ребята работали над каждой частью отдельно, что добавило уникальности и свежести к звучанию! ✨\n\nТрек уже успел покорить чарты электронной музыки и даже стал хитом на некоторых крупных фестивалях. Это идеальное сочетание мелодии и ритма делает его настоящим фаворитом среди диджеев! 🎉	melodic techno, melodic house, techno, minimal techno
11	2	5XwicpPg1U7Pwi6uvVFl8y	\N	Golden Hoop (NEUS Remix)	NEUS, Ольга Восконьян, БИО, Atomic Heart	1qzcdqlwqtm8lnthmvh2a70p9	2026-03-17 10:10:33+00	Трек "Golden Hoop" в ремиксе NEUS стал настоящим хитом благодаря своей динамичной электронике и оригинальному сочетанию стилей. 🎶\n\nИнтересно, что Ольга Восконьян, участвующая в записи, сама по образованию художник и часто использует свои музыкальные проекты, чтобы выразить свои визуальные идеи. 💡\n\nЭтот ремикс стал популярен благодаря тому, что его можно услышать в игре Atomic Heart, что добавило ему дополнительный уровень популярности среди геймеров и музыкантов. 🎮✨	electronic
3968	49	3RiPr603aXAoi4GHyXx0uy	\N	Hymn for the Weekend	Coldplay	31433d6i5sfekboj5hr2fjtnwe7u	2024-09-29 10:19:47+00	\N	rock
12	2	19iJj3pCMwGxrA6pltPat3	\N	GOOD STUFF - KARINA Solo	aespa	1qzcdqlwqtm8lnthmvh2a70p9	2026-03-18 04:56:23+00	"GOOD STUFF" стал хитом благодаря своей яркой мелодии и энергичному ритму, который идеально подходит для танцев. 💃\n\nИнтересно, что aespa активно экспериментируют с концепциями виртуальной реальности, и в этом треке они продолжают развивать свою уникальную вселенную, где виртуальные персонажи взаимодействуют с реальными музыкантами.\n\nПлюс, "GOOD STUFF" стал одним из самых быстро набирающих популярность треков группы, что подтверждает их растущее влияние на K-pop сцену! 🚀	k-pop
18	2	6l9rm6oaHmFO46bTtIr1ip	\N	NOBODY	Aarne, Toxi$, Big Baby Tape	1qzcdqlwqtm8lnthmvh2a70p9	2026-03-18 06:48:40+00	Трек "NOBODY" стал настоящим хитом благодаря уникальному смешению стилей, в котором можно услышать элементы как трэпа, так и мелодичного рэпа. 🎶\n\nПри записи этой песни Aarne, Toxi$ и Big Baby Tape использовали интересный подход: каждый из них записывал свои партии отдельно, и только потом все это свели в одно целое. Это дало возможность каждому проявить свою индивидуальность! 💥\n\nИнтересно, что Big Baby Tape в своей карьере уже успел поработать с большинством популярных исполнителей СНГ, и "NOBODY" только укрепил его статус в музыкальной индустрии. 🔥	rap
5106	2	3ODXRUPL44f04cCacwiCLC	\N	i	Kendrick Lamar	31ghi62vkgnlb4wqr6muaisx7ldi	2026-03-31 15:19:09+00	Трек "i" от Кендрика Ламара был выпущен в 2014 году как первый сингл с его альбома "To Pimp a Butterfly". Интересно, что он вдохновлен фразой "I love myself", которая стала своего рода мантрой для многих поклонников.\n\nПесня была записана в сотрудничестве с продюсером Sounwave, и в ней использован сэмпл из "Woman" группы The Roots, что придает треку особый groove и атмосферу.\n\nИ, кстати, "i" стал первым треком Кендрика, который попал в топ-40 Billboard Hot 100, что подчеркивает его коммерческий успех и влияние на хип-хоп сцену. 🎶	hip hop, west coast hip hop
16	2	3VPbLAcnSdFBkQ08ndgK7P	\N	Dark and Quiet Skies	Oceans in Silhouette, DAKØTA	1qzcdqlwqtm8lnthmvh2a70p9	2026-03-18 05:14:12+00	"Dark and Quiet Skies" — это совместная работа двух артистов, и на самом деле это звучит как волшебное сочетание, которое уводит в мир меланхолии и нежности. 🌌\n\nDAKØTA, один из участников, изначально записывал музыку как способ справиться с личными переживаниями, и этот трек стал для него важным этапом в музыкальной карьере. 🎶\n\nИнтересно, что название трека отсылает к идее внутреннего мира художника, а также к тому, что даже в темноте и тишине можно найти красоту — это мощный месседж для всех, кто слушает! ✨	metalcore
17	2	48Z9ixFIkuzJMATvfFJHIz	\N	intro	Peso Pluma, Tito Double P	1qzcdqlwqtm8lnthmvh2a70p9	2026-03-18 05:54:06+00	Трек "Intro" стал настоящим хитом в мире латинской музыки, и это не случайно — Peso Pluma и Tito Double P привнесли в него уникальный стиль, смешав традиционный звук с современными ритмами. \n\nИнтересный факт: Peso Pluma быстро завоевал популярность благодаря своим провокационным текстам и смелым экспериментам со звуком, что сделало его одним из самых обсуждаемых исполнителей на латинской сцене! 💥\n\nА вот еще забавная деталь: в первой версии трека была строка, которая вызывала столько споров, что пришлось её изменить перед финальным релизом. Теперь это одна из самых запоминающихся фраз! 🎤	corrido, corridos tumbados, corridos bélicos, música mexicana, sierreño, sad sierreño, banda
21	2	4JQMbQK6139mYC1osRQK0b	\N	All For You	Atreyu	313neyxbfwxtbi2t52gjvliqxisa	2026-03-24 12:32:46+00	Трек "All For You" от Atreyu стал настоящим гимном для фанатов пост-хардкора, и его мощный звук запомнился многим. 💥\n\nИнтересно, что песня была написана в период, когда у группы возникли творческие разногласия, но они смогли объединиться и создать что-то уникальное! 🎸\n\nКроме того, "All For You" стал одним из хитов, который помог Atreyu выйти на новую аудиторию, и часто звучал на рок-фестивалях, собирая толпы поклонников. 🤘	metalcore, screamo
15	2	4MxHutRACnfl9vW2xt2qlp	\N	Checks Up	Enei, Limmz	1qzcdqlwqtm8lnthmvh2a70p9	2026-03-18 05:14:11+00	"Checks Up" — это коллаборация Enei и Limmz, и она стала настоящим хитом среди любителей дранджи! 🎶\n\nИнтересно, что Enei изначально был известен как продюсер, а в "Checks Up" он впервые появился в роли вокалиста, что стало приятным сюрпризом для фанатов! \n\nТакже стоит отметить, что трек был создан в режиме онлайн во время карантина, когда многие артисты искали новые способы взаимодействия и создания музыки, поэтому это своего рода символ времени. 🌍✨	drum and bass, liquid funk, jungle
3995	49	0So2sgVa8aJiARPl2P29u2	\N	Pope Is a Rockstar	SALES	31433d6i5sfekboj5hr2fjtnwe7u	2024-09-29 10:20:41+00	\N	bedroom pop
4553	68	0krgGDO44sCWRVM506VuPJ	\N	Серпантин	Markul	31433d6i5sfekboj5hr2fjtnwe7u	2024-03-02 18:43:12+00	\N	hip hop
4778	78	1TOBYH7YalbblKJ7M8ufRx	\N	HOLD TIGHT	33 Below, Chrystel	31433d6i5sfekboj5hr2fjtnwe7u	2023-11-07 19:06:51+00	\N	stutter house, uk garage, bassline
4427	65	1uUtk0jTexGwkvaZsl5tyO	\N	give me hope	Øneheart	31433d6i5sfekboj5hr2fjtnwe7u	2024-03-18 17:52:52+00	\N	dark ambient, ambient
34	2	4QUxlbwlSBYiaTT27A5MEj	\N	In This Bih'	Chris Lorenzo, Kah-Lo	31ghi62vkgnlb4wqr6muaisx7ldi	2026-03-31 11:36:12+00	"In This Bih'" — это настоящий хит, который стал вирусным благодаря своей зажигательной мелодии и простому, но запоминающемуся тексту. 🎶\n\nКрис Лоренцо и Ках-Ло познакомились, когда Лоренцо искал вокалистку для своего нового трека. Их сотрудничество оказалось настолько удачным, что с тех пор они продолжают работать вместе! 🙌\n\nЭтот трек стал настоящим гимном для вечеринок, и даже попал в чарты многих стран, что дало ему статус "летнего хита" 2018 года. ☀️	bass house, bassline, house, tech house, g-house
28	2	4spQAFMDiuu8gyYany9Ldk	\N	Inside The Hollow	SION	313neyxbfwxtbi2t52gjvliqxisa	2026-03-24 12:34:44+00	"Inside The Hollow" — это одна из самых эмоциональных композиций SION, основанная на личных переживаниях участников группы. 🎶 \n\nИнтересно, что SION — это проект, созданный гитаристом и вокалистом, который раньше выступал в известных металлических командах, и этот трек стал их дебютом в новом звучании. \n\nНа записи трека использовались необычные инструменты, что добавляет ему уникальности. Например, они экспериментировали с эффектами и звуками, вдохновляясь звуковыми ландшафтами из своих любимых фильмов. 🎥	metalcore
10	2	5ynJ4vxlXDXOp8y5e92ZZH	\N	Suave Amor	Flame Runner	1qzcdqlwqtm8lnthmvh2a70p9	2026-03-17 08:35:51+00	"Suave Amor" был записан в рамках сотрудничества Flame Runner с известным продюсером, который ранее работал с такими артистами, как Shakira и Juanes. 🎶\n\nЭтот трек стал настоящим хитом и даже попал в топ чартов сразу в нескольких странах, благодаря запоминающемуся ритму и мелодии, которая остается в голове надолго! 🎤\n\nСлышали, что "Suave Amor" вдохновлен классическими латиноамериканскими балладами? Flame Runner смешал старые добрые традиции с современным звучанием, что и сделало трек таким притягательным! 🌟	phonk, brazilian phonk
29	2	62WghXe4ZEhaydOF1E1S8v	\N	Aura	ONI, Howard Jones, Josh Gilbert	313neyxbfwxtbi2t52gjvliqxisa	2026-03-24 12:34:47+00	Трек "Aura" — это коллаборация трех уникальных артистов: ONI, Howard Jones и Josh Gilbert, которые смешивают свои стили, создавая освежающее звучание! 🎶\n\nЗабавно, но Howard Jones, известный своей электронной музыкой с 80-х, в "Aura" решил добавить современные элементы, что делает его звучание актуальным и молодежным! \n\nИнтересный факт: Josh Gilbert, помимо своей сольной карьеры, также известен как басист в группе As I Lay Dying, так что в этом треке можно услышать влияние металла, смешанного с электроникой! 🤘	djent, progressive metal, metalcore
20	2	6mc1PcrUrDP2ry6ayrqt4V	\N	Hungover On A Tuesday	Dredg	1qzcdqlwqtm8lnthmvh2a70p9	2026-03-23 21:44:07+00	Этот трек с альбома "El Cielo" вышел в 2002 году и стал настоящим хитом среди поклонников альтернативного рока. 🎸\n\nИнтересный факт: название "Hungover On A Tuesday" на самом деле отражает чувство, когда кажется, что жизнь проходит мимо, и это ощущение было вдохновлено личными переживаниями участников группы. \n\nКроме того, Dredg часто экспериментирует с жанрами, и в этом треке можно услышать влияние прогрессивного рока и амбиента, что делает его звучание необычным и запоминающимся. 🌌	progressive rock, art rock
27	2	7HuRaEOilu5WzB4EDOuEAV	\N	Paranoid	Mystic Prophecy	313neyxbfwxtbi2t52gjvliqxisa	2026-03-24 12:34:39+00	Трек "Paranoid" от Mystic Prophecy стал настоящим хитом в метал-сообществе и часто используется на концертах как мощный заводной номер. 🤘\n\nИнтересно, что песня вдохновлена классическим трэшем, но в ней слышны элементы пауэр-метала, что делает её уникальной для слушателей разных жанров. 🎸\n\nСам альбом, в который входит этот трек, был записан в условиях ограниченного времени, что только добавило драйва и энергии в звучание. 🕒	power metal, speed metal, heavy metal, metal
24	2	7KLFCXhioKvErGSF0qD1Ag	\N	Die For You	From Ashes to New	313neyxbfwxtbi2t52gjvliqxisa	2026-03-24 12:33:59+00	"Die For You" от From Ashes to New — это не просто песня, а настоящая история о борьбе с внутренними демонами. Интересно, что эта группа сочетает в своем звучании хардкор и хип-хоп, что делает их музыку уникальной! 🎸\n\nПесня стала настоящим хитом в мире альтернативной музыки и даже попала в чарты Billboard, что говорит о её огромной популярности среди слушателей. 📈\n\nКроме того, From Ashes to New известны своими мощными текстами, и "Die For You" не исключение — они часто затрагивают темы самоидентификации и борьбы со своими страхами, что делает их песни особенно резонирующими для молодежи. 💪	rap rock, rap metal, metalcore
4576	69	2CFl2JZVw74jVO5LTyiim3	\N	Strangers (feat. Kenya Grace) - Sped Up	sped up + nightcore, Kenya Grace	31433d6i5sfekboj5hr2fjtnwe7u	2024-02-20 08:01:54+00	\N	electronic
4721	74	2zNe1uQywAJdv0TcM7SDgS	\N	stellar (Sped Up)	.diedlonely, énouement	31433d6i5sfekboj5hr2fjtnwe7u	2024-01-20 04:33:49+00	\N	dark ambient, ambient
4571	69	2XynYulas10Wmef4Gqrxw9	\N	Hate.	ThxSoMch	31433d6i5sfekboj5hr2fjtnwe7u	2024-02-20 07:11:08+00	\N	emo
4615	70	40iHwasC0kEK8fgaEfQReF	\N	Destroy Myself Just For You	Montell Fish	31433d6i5sfekboj5hr2fjtnwe7u	2024-02-13 01:48:37+00	\N	christian lo-fi
26	2	093rTY512ehJJ2K2nMmRko	\N	Neurotic Psychosis	Vendetta Bloom	313neyxbfwxtbi2t52gjvliqxisa	2026-03-24 12:34:24+00	"Neurotic Psychosis" — это настоящий психоделический коктейль, который был создан в домашней студии Vendetta Bloom, где он использовал необычные звуковые эффекты, чтобы передать состояние сумасшествия 🎧.\n\nПри написании трека Vendetta вдохновлялся своими собственными переживаниями и моментами стресса, что делает его особенно близким для слушателей, которые когда-либо испытывали подобные ощущения 🌪️.\n\nИнтересный факт: сам трек стал хитом в underground-сцене, благодаря вирусным видео в социальных сетях, где люди пытались повторить его ритмы и мелодии с помощью нестандартных инструментов, таких как кухонные принадлежности 🍳!	metalcore
19	2	14qNHvX8h6HoynFuV0RxWS	\N	Far Away (feat. A$AP Rocky)	Yebba, A$AP Rocky	31ghi62vkgnlb4wqr6muaisx7ldi	2026-03-18 16:58:55+00	Yebba написала "Far Away" после того, как пережила тяжелый период в своей жизни, и трек стал для нее своего рода терапией. 🎤\n\nA$AP Rocky добавил свои куплеты уже после завершения основной части песни — его строки идеально вписались в концепцию и усилили эмоциональное воздействие. 🔥\n\nИнтересно, что Yebba ранее работала с такими артистами, как Drake и Ed Sheeran, но этот трек стал её первым большим сольным успехом. 🌟	r&b
13	2	1izz8IdjjrLYsn5xdqxs9y	\N	We Are The World - Remastered	U.S.A. For Africa, Al Jarreau, Anita Pointer, Bette Midler, Billy Joel, Bob Dylan, Bob Geldof, Bruce Springsteen, Cyndi Lauper, Dan Aykroyd, Daryl Hall, Diana Ross, Dionne Warwick, Harry Belafonte, Huey Lewis & The News, Jackie Jackson, James Ingram, Jeffrey Osborne, John Oates, June Pointer	1qzcdqlwqtm8lnthmvh2a70p9	2026-03-18 05:00:35+00	Этот трек был записан в 1985 году как благотворительная инициатива, чтобы собрать деньги для борьбы с голодом в Эфиопии. 🎤\n\nИнтересно, что в записи участвовали 45 знаменитостей, и её продюсерами были такие иконы, как Майкл Джексон и Лайонел Ричи. \n\n"We Are The World" стала одним из самых продаваемых синглов в истории, собрав более 60 миллионов долларов для помощи нуждающимся. 💰🌍	pop
32	2	1xrnIqOGEz5iu179fXB8m8	\N	Mezzaluna	TÄRA	31ghi62vkgnlb4wqr6muaisx7ldi	2026-03-31 11:36:09+00	Трек "Mezzaluna" от TÄRA — это интересное сочетание электронной и этнической музыки, что делает его уникальным в современном звучании. 🎶\n\nКогда TÄRA записывали этот трек, они вдохновлялись древними ритмами и мелодиями, что позволяет музыке звучать как мост между прошлым и настоящим. 🌍\n\n"Mezzaluna" стала настоящим хитом на платформах стриминга и даже попала в несколько популярных плейлистов, что привело к росту популярности группы за пределами их родной страны! 🚀	electronic
22	2	20C1WJvhvpR2wGUHNAwMVL	\N	Guilt By Association	Normandie	313neyxbfwxtbi2t52gjvliqxisa	2026-03-24 12:32:51+00	Трек "Guilt By Association" от Normandie стал настоящим гимном для тех, кто переживает сложные отношения — в нем отлично переданы чувства разочарования и борьбы. 🎧\n\nИнтересно, что группа записала этот трек в период, когда они активно экспериментировали со звуком, смешивая элементы поп-панка и пост-хардкора, что сделало их стиль уникальным. 🌟\n\nТакже, в одном из интервью участники группы рассказали, что вдохновение для песни пришло после долгих обсуждений о том, как общественное мнение влияет на личные выборы, что отражает актуальные темы современности. 💬	alternative rock
36	2	36E9WXEHcKSDWQNMKHiDkX	\N	YAYAYA	Dyce	31ghi62vkgnlb4wqr6muaisx7ldi	2026-03-31 11:36:20+00	Трек "YAYAYA" от Dyce стал настоящим вирусом в TikTok, благодаря зажигательному ритму и catchy припеву, который легко запоминается! 🎶\n\nИнтересно, что Dyce записал этот трек всего за один день, вдохновившись летним настроением и желанием поднять людям настроение. ☀️\n\nКроме того, "YAYAYA" стал хитом среди диджеев на европейских вечеринках, где его часто используют в сетах для разогрева публики! 🎉	pop
23	2	4lIN5l57LDzzyqKDADGpDN	\N	PHASES	SCATTERBRAIN	313neyxbfwxtbi2t52gjvliqxisa	2026-03-24 12:33:35+00	"PHASES" от SCATTERBRAIN был записан в 1993 году и стал настоящим хитом благодаря своему необычному смешению стилей — от панка до альтернативы. 🎸\n\nИнтересный момент: во время записи вокалист группы пытался поймать атмосферу живого концерта, поэтому многие его партии были записаны в одной комнате с участниками, чтобы передать энергию публики. 🔥\n\nКстати, этот трек часто использовался в различных шоу и фильмах, так что его можно услышать в самых неожиданных местах! 🎬	electronic
4447	65	4D4kvHsVOh0Ibhrkt1exVJ	\N	angel lies	limedisx., Silent.	31433d6i5sfekboj5hr2fjtnwe7u	2024-03-21 19:24:30+00	\N	lo-fi house, electroclash, witch house
4818	79	4EUQvVJ8fT1WCCxISFxMKW	\N	Frozen Heart	ominix	31433d6i5sfekboj5hr2fjtnwe7u	2023-11-05 09:26:09+00	\N	electroclash, witch house
4811	79	5R5A00FjJeEJLM876OjBth	\N	30For30	BONES, GREAF	31433d6i5sfekboj5hr2fjtnwe7u	2023-11-02 19:35:05+00	\N	cloud rap, emo rap, horrorcore, trap metal, underground hip hop
4469	66	5Adb2KuEfFYuOMi18uMd5A	\N	Может ты вернёшься	Kara Deri	31433d6i5sfekboj5hr2fjtnwe7u	2024-03-13 06:36:12+00	\N	pop
3972	49	69uxyAqqPIsUyTO8txoP2M	\N	Adventure of a Lifetime	Coldplay	31433d6i5sfekboj5hr2fjtnwe7u	2024-09-29 10:19:55+00	\N	rock
3947	48	7icHQ0UDRFe98tfvI0yyhL	\N	Prayer in C - Robin Schulz Radio Edit	Lilly Wood and The Prick, Robin Schulz	31433d6i5sfekboj5hr2fjtnwe7u	2024-09-28 16:32:52+00	\N	french indie pop
3985	49	7JkZDPNcF5mJ0Vx2QXO582	\N	Половина моя	MiyaGi & Endspiel	31433d6i5sfekboj5hr2fjtnwe7u	2024-09-29 10:20:22+00	\N	rap
4573	69	7betDZRl5LfZWAgt2NC5qx	\N	Spaceship (Slowed)	ricoworld	31433d6i5sfekboj5hr2fjtnwe7u	2024-02-20 07:23:12+00	\N	downtempo
4001	49	00RLNHc2jkEjUoCUlFgPVT	\N	welcome and goodbye	Dream, Ivory	31433d6i5sfekboj5hr2fjtnwe7u	2024-09-29 10:20:53+00	\N	r&b
3977	49	09CtPGIpYB4BrO8qb1RGsF	\N	Sorry	Justin Bieber	31433d6i5sfekboj5hr2fjtnwe7u	2024-09-29 10:20:04+00	\N	pop
3964	49	2oQh2s9ZM1Pp0EDViQsOq8	\N	Sub pielea mea - Midi Culture Remix	Carla's Dreams, Midi Culture	31433d6i5sfekboj5hr2fjtnwe7u	2024-09-29 10:19:38+00	\N	electronic
3963	49	3cfOd4CMv2snFaKAnMdnvK	\N	All Star	Smash Mouth	31433d6i5sfekboj5hr2fjtnwe7u	2024-09-29 10:19:35+00	\N	rock
3965	49	5tf1VVWniHgryyumXyJM7w	\N	Sugar (feat. Francesco Yates)	Robin Schulz, Francesco Yates	31433d6i5sfekboj5hr2fjtnwe7u	2024-09-29 10:19:41+00	\N	tropical house
3982	49	0UQJ3UiyzbGsj4Rbfs0utS	\N	Kiss	SEREBRO	31433d6i5sfekboj5hr2fjtnwe7u	2024-09-29 10:20:16+00	\N	pop
3983	49	0V8Q2u0yxJ9yURkjblmPU9	\N	Мой кайф	PHARAOH	31433d6i5sfekboj5hr2fjtnwe7u	2024-09-29 10:20:18+00	\N	rap
3975	49	0f9Pc2HV3qACVrrayGLHOS	\N	4 утра	Misha Marvin, Timati	31433d6i5sfekboj5hr2fjtnwe7u	2024-09-29 10:20:01+00	\N	r&b
3993	49	0i2lbW33Ig9b4udnIBVQs8	\N	Novella	IVAN VALEEV	31433d6i5sfekboj5hr2fjtnwe7u	2024-09-29 10:20:38+00	\N	electronic
3973	49	0zL9dieoCcjBWV01y73Cj1	\N	Faded	ZHU	31433d6i5sfekboj5hr2fjtnwe7u	2024-09-29 10:19:56+00	\N	edm
4002	49	1XBYiRV30ykHw5f4wm6qEn	\N	NIGHTS LIKE THIS	The Kid LAROI	31433d6i5sfekboj5hr2fjtnwe7u	2024-09-29 10:20:55+00	\N	pop
3970	49	1Mys1gf9SkMBAVGGxpkJ7d	\N	Reality	Lost Frequencies, Janieck	31433d6i5sfekboj5hr2fjtnwe7u	2024-09-29 10:19:51+00	\N	tropical house
3988	49	26XaOsDMbl0e1cVKYfkz6w	\N	Falling	Trevor Daniel	31433d6i5sfekboj5hr2fjtnwe7u	2024-09-29 10:20:28+00	\N	pop
3998	49	2XrQe3WObY31U0qcnnfcI2	\N	WESPN	Sheck Wes	31433d6i5sfekboj5hr2fjtnwe7u	2024-09-29 10:20:47+00	\N	hip hop
3974	49	2cMPBRVDmZL48phGwYWXPE	\N	Лирика	Sektor Gaza	31433d6i5sfekboj5hr2fjtnwe7u	2024-09-29 10:19:59+00	\N	punk
3981	49	2hxNNlZHxgda03EdP8in65	\N	Когда исчезнет Слово	МОТ	31433d6i5sfekboj5hr2fjtnwe7u	2024-09-29 10:20:15+00	\N	pop
3980	49	2xGmwfWItYrn7oqxWEdm1h	\N	Романс	PIZZA	31433d6i5sfekboj5hr2fjtnwe7u	2024-09-29 10:20:12+00	\N	pop
3996	49	2ksyzVfU0WJoBpu8otr4pz	\N	METAMORPHOSIS	INTERWORLD	31433d6i5sfekboj5hr2fjtnwe7u	2024-09-29 10:20:44+00	\N	phonk, drift phonk, brazilian phonk
3999	49	40TZnaw4eDPChJNHw2Swf3	\N	Let U Go	lucidbeatz	31433d6i5sfekboj5hr2fjtnwe7u	2024-09-29 10:20:49+00	\N	electronic
4000	49	3oByO94xgLnworeBgkCsGo	\N	Wish	Diplo, Trippie Redd	31433d6i5sfekboj5hr2fjtnwe7u	2024-09-29 10:20:51+00	\N	moombahton
3976	49	41hTesS5yOrC6VNJhao13J	\N	92 дня	МОТ	31433d6i5sfekboj5hr2fjtnwe7u	2024-09-29 10:20:03+00	\N	pop
3989	49	4Kbk0hidFxdtOa7fX4IuE8	\N	Перепутала	SEREBRO	31433d6i5sfekboj5hr2fjtnwe7u	2024-09-29 10:20:30+00	\N	pop
3971	49	4255amV4enzl28KAn16rUO	\N	Are You With Me	Lost Frequencies	31433d6i5sfekboj5hr2fjtnwe7u	2024-09-29 10:19:53+00	\N	tropical house
3978	49	4l8swd8oFNh8ebsK3NY1bn	\N	Это всё она	Sergey Lazarev	31433d6i5sfekboj5hr2fjtnwe7u	2024-09-29 10:20:06+00	\N	pop
3990	49	4vFxfU6pyRfAHUvTnWJkLu	\N	Танцуй	MORGENSHTERN	31433d6i5sfekboj5hr2fjtnwe7u	2024-09-29 10:20:33+00	\N	rap
3979	49	551l3WSPbohzxQGHhTVm0q	\N	Капкан	МОТ	31433d6i5sfekboj5hr2fjtnwe7u	2024-09-29 10:20:08+00	\N	pop
3991	49	5Adb2KuEfFYuOMi18uMd5A	\N	Может ты вернёшься	Kara Deri	31433d6i5sfekboj5hr2fjtnwe7u	2024-09-29 10:20:34+00	\N	pop
3994	49	5PqTTnAaxqOTLhUrupzMqJ	\N	Зацепила	VERBEE	31433d6i5sfekboj5hr2fjtnwe7u	2024-09-29 10:20:40+00	\N	rap
3967	49	5ngEoEew3XmBNQO1cD9x2O	\N	To Let Myself Go	The Avener, Ane Brun	31433d6i5sfekboj5hr2fjtnwe7u	2024-09-29 10:19:46+00	\N	downtempo
3984	49	5cF0dROlMOK5uNZtivgu50	\N	Attention	Charlie Puth	31433d6i5sfekboj5hr2fjtnwe7u	2024-09-29 10:20:20+00	\N	soft pop
3969	49	76hfruVvmfQbw0eYn1nmeC	\N	Cake By The Ocean	DNCE	31433d6i5sfekboj5hr2fjtnwe7u	2024-09-29 10:19:48+00	\N	pop
3992	49	7JBQPFOBszYYGk4lUIfmfA	\N	На луне	PHARAOH	31433d6i5sfekboj5hr2fjtnwe7u	2024-09-29 10:20:36+00	\N	rap
3986	49	7a78yps1jTKGGGDpLlgThd	\N	Оптимист	Max Korzh	31433d6i5sfekboj5hr2fjtnwe7u	2024-09-29 10:20:24+00	\N	hip hop
3966	49	7w5AOd6HrDIHewHfpABEss	\N	Wicked Game	Chris Isaak	31433d6i5sfekboj5hr2fjtnwe7u	2024-09-29 10:19:44+00	\N	rock
3997	49	7pbg3ABlAZv2NiIdKbBBFm	\N	Up Up And Away	Juice WRLD	31433d6i5sfekboj5hr2fjtnwe7u	2024-09-29 10:20:45+00	\N	melodic rap, emo rap
4482	66	0vaP8wk0E59FzwCLkiKaQm	\N	The Less I Know The Better	Tame Impala	31433d6i5sfekboj5hr2fjtnwe7u	2024-03-14 09:29:25+00	\N	neo-psychedelic, indie
4479	66	2UrOzJAbJj3GfIonnNVXez	\N	apogee	skyfall beats	31433d6i5sfekboj5hr2fjtnwe7u	2024-03-13 14:12:06+00	\N	witch house
4491	66	4oaXIw98ZAHdDWhvq423uy	\N	Я Тебя Не Отдам	Yoshino	31433d6i5sfekboj5hr2fjtnwe7u	2024-03-16 05:15:30+00	\N	anime
4497	66	4XAilWzhZM0uyR4vtERfHi	\N	i was only temporary (Slowed + Reverb)	my head is empty	31433d6i5sfekboj5hr2fjtnwe7u	2024-03-16 18:26:52+00	\N	dark ambient, ambient
4492	66	7Gq3SA19zbr1Kr1Q54fQPG	\N	Let Me Go	Emiran Young	31433d6i5sfekboj5hr2fjtnwe7u	2024-03-16 05:19:06+00	\N	hardstyle
4555	68	1xbOdb9kv5YKBIzJSrKNEy	\N	Stop Waiting	Cigarettes After Sex	31433d6i5sfekboj5hr2fjtnwe7u	2024-03-03 09:51:48+00	\N	dream pop
4556	68	285pBltuF7vW8TeWk8hdRR	\N	Lucid Dreams	Juice WRLD	31433d6i5sfekboj5hr2fjtnwe7u	2024-03-03 10:06:36+00	\N	melodic rap, emo rap
4526	67	440DONUaYDRuHmNKMJcz0R	\N	✻H+3+ЯД✻7luCJIo0T6...	vyrval	31433d6i5sfekboj5hr2fjtnwe7u	2024-03-09 17:44:18+00	\N	phonk
4532	68	5LD8lrWm983s9QuFERsRJb	\N	last summer - sped up	ooes	31433d6i5sfekboj5hr2fjtnwe7u	2024-02-26 10:15:38+00	\N	pop
4575	69	5K9tfeoiztw94dyWzF39jq	\N	moment	Vierre Cloud	31433d6i5sfekboj5hr2fjtnwe7u	2024-02-20 07:55:23+00	\N	breakcore
4570	69	5kyOPpbF2cITvHty4nBZE6	\N	Fireflies (Sped Up)	Spaceouters	31433d6i5sfekboj5hr2fjtnwe7u	2024-02-20 06:58:23+00	\N	dark ambient, chillstep
4554	68	6OzcCZPOIaC3kcdkO3cA6y	\N	EVERYDAY ANYONE (DATURA Remix)	NOMINAL, DATURA	31433d6i5sfekboj5hr2fjtnwe7u	2024-03-02 18:52:10+00	\N	electronic
4524	67	6ZdyuuBShTPcezUOK2G97a	\N	Stay Focused	Jvdxn	31433d6i5sfekboj5hr2fjtnwe7u	2024-03-08 11:51:03+00	\N	electronic
4568	69	6et5HwX6nTYddg7hDGAxug	\N	ONE CALL	Rich Amiri	31433d6i5sfekboj5hr2fjtnwe7u	2024-02-19 15:21:50+00	\N	rage rap
4514	67	6iaSML1PIYq936g62BDtBq	\N	Robbery	Juice WRLD	31433d6i5sfekboj5hr2fjtnwe7u	2024-03-04 19:33:24+00	\N	melodic rap, emo rap
4537	68	6ycY6bvWa2kHTcVrR5HhCr	\N	meant to be	volatic	31433d6i5sfekboj5hr2fjtnwe7u	2024-02-27 08:24:28+00	\N	electronic
4572	69	7cqYgIcCoGAbbEreOZPhX6	\N	The Other Side	longlost, Bonjr	31433d6i5sfekboj5hr2fjtnwe7u	2024-02-20 07:18:00+00	\N	indie
4574	69	7pp2CWJWYYQL8Pon7T8EsF	\N	Kiss You in My Arms	mxngpe	31433d6i5sfekboj5hr2fjtnwe7u	2024-02-20 07:36:38+00	\N	r&b
4552	68	0V8Q2u0yxJ9yURkjblmPU9	\N	Мой кайф	PHARAOH	31433d6i5sfekboj5hr2fjtnwe7u	2024-03-02 18:43:03+00	\N	rap
4618	70	1ItVxunpyqZWeqyH7fLPS6	\N	Memo Boy (brian is the most beautiful) - REMIX	143Pey, Patrick Bateman, Walter White	31433d6i5sfekboj5hr2fjtnwe7u	2024-02-13 07:58:29+00	\N	electronic
4591	69	1ZDXxJ2FyEfkwIQUNruAmK	\N	театр	Owlneverdie	31433d6i5sfekboj5hr2fjtnwe7u	2024-02-22 18:13:36+00	\N	indie
4619	70	2cNK3bGwB1lKVc0fy9b6M4	\N	The Heavens	EXNLXDE	31433d6i5sfekboj5hr2fjtnwe7u	2024-02-13 08:07:38+00	\N	phonk
4578	69	2cSdAkzAf2T4j4aLvx4LLz	\N	Baby Girl	Disco Lines	31433d6i5sfekboj5hr2fjtnwe7u	2024-02-20 08:09:51+00	\N	stutter house
4621	70	47wPtbdOgF45SN3lPlLxFT	\N	passing time	Meridian	31433d6i5sfekboj5hr2fjtnwe7u	2024-02-13 08:12:22+00	\N	stutter house
4617	70	6OfdYicqb81dajVyhd8Lcq	\N	Emptiness	Immoral Freak	31433d6i5sfekboj5hr2fjtnwe7u	2024-02-13 07:55:48+00	\N	metal
4620	70	6UPWpKFmVwebHCgT5JmbNG	\N	So Low	Cloke, Shiloh Dynasty	31433d6i5sfekboj5hr2fjtnwe7u	2024-02-13 08:11:55+00	\N	downtempo
4616	70	6wQR6kyW7dC4tg3uS1J53N	\N	Save Yourself	Ahkil	31433d6i5sfekboj5hr2fjtnwe7u	2024-02-13 07:51:51+00	\N	r&b
4577	69	04SSxcKDNjAkTvPeT0UUMN	\N	Give It To Me	Henrik	31433d6i5sfekboj5hr2fjtnwe7u	2024-02-20 08:03:43+00	\N	electronic
4667	71	07aCgdri8PPDdAE051LuZN	\N	angel	SXULTAPE VISION	31433d6i5sfekboj5hr2fjtnwe7u	2024-02-09 17:58:41+00	\N	drift phonk, phonk, witch house
4649	71	0b6qwNkDNGL79duIAspPtk	\N	I'm so lucky! - Hardstyle	Lucky Twice, Tik Tok Trends, sped up + slowed	31433d6i5sfekboj5hr2fjtnwe7u	2024-02-05 03:49:54+00	\N	nightcore, europop
4646	71	1WLxg0luWS1uLNCsHSQ7Dg	\N	Neon Nights	lucidmusic, daydreams!	31433d6i5sfekboj5hr2fjtnwe7u	2024-02-04 15:10:06+00	\N	synthwave
4669	72	4FSg7aHsASSaFgskTYPCor	\N	November	Toxi$	31433d6i5sfekboj5hr2fjtnwe7u	2024-01-26 10:36:49+00	\N	rap
4647	71	5wgQdqVROXxYDwFIFi8eZ8	\N	Daydream	Narvent, Pxlish Beatz	31433d6i5sfekboj5hr2fjtnwe7u	2024-02-04 15:18:57+00	\N	synthwave, phonk
4689	72	6fujklziTHa8uoM5OQSfIo	\N	Black Beatles	Rae Sremmurd, Gucci Mane	31433d6i5sfekboj5hr2fjtnwe7u	2024-02-01 02:47:55+00	\N	hip hop
4648	71	7m9OqQk4RVRkw9JJdeAw96	\N	Jocelyn Flores	XXXTENTACION	31433d6i5sfekboj5hr2fjtnwe7u	2024-02-04 18:39:42+00	\N	emo rap
4736	75	0yc6Gst2xkRu0eMLeRMGCX	\N	Apocalypse	Cigarettes After Sex	31433d6i5sfekboj5hr2fjtnwe7u	2024-01-13 23:17:26+00	\N	dream pop
4781	78	1XYc5rKRlOk94IUJZr27Yu	\N	Walking on a Dream	Du0	31433d6i5sfekboj5hr2fjtnwe7u	2023-11-09 13:59:47+00	\N	electronic
4813	79	2FdyFBXscE7lMgAcZ48pVU	\N	Tokyo Rain (Slowed + Reverb)	Yavomag, Rubikdice, Chilx	31433d6i5sfekboj5hr2fjtnwe7u	2023-11-03 11:58:07+00	\N	drift phonk, phonk
4783	78	2zha2IX1bEL4rCK8cS7PBe	\N	There For You	Manil, outset island	31433d6i5sfekboj5hr2fjtnwe7u	2023-11-11 10:32:50+00	\N	stutter house
4782	78	33iv4ikGd0KboI6xNPL80i	\N	Dark Side Of The Moon	suisside	31433d6i5sfekboj5hr2fjtnwe7u	2023-11-09 19:29:29+00	\N	emo rap
4784	78	3D2aELdAZMSExPGcac7szB	\N	Melancholy	SAY3AM, Lowx	31433d6i5sfekboj5hr2fjtnwe7u	2023-11-11 19:10:55+00	\N	phonk, drift phonk
4809	79	40TZnaw4eDPChJNHw2Swf3	\N	Let U Go	lucidbeatz	31433d6i5sfekboj5hr2fjtnwe7u	2023-11-01 14:24:01+00	\N	electronic
4758	77	5QOBT97OmYCZo1W5u7tRrB	\N	ten	Fred again.., Jozzy	31433d6i5sfekboj5hr2fjtnwe7u	2023-11-25 06:27:35+00	\N	stutter house, house, edm
4768	78	6dj6mwfnLiCp20cslQEcOE	\N	Gone (sped up)	lucidbeatz, Ardeycat	31433d6i5sfekboj5hr2fjtnwe7u	2023-11-06 13:40:19+00	\N	electronic
4785	78	7EiZI6JVHllARrX9PUvAdX	\N	Low Life (feat. The Weeknd)	Future, The Weeknd	31433d6i5sfekboj5hr2fjtnwe7u	2023-11-13 18:59:20+00	\N	rap
4870	81	1Wi6fIQbFqvkfaW66qo4kq	\N	Say Yes To Heaven x Shootout	Julien Marchal, Izzamuzzic, RACH	31433d6i5sfekboj5hr2fjtnwe7u	2023-10-21 11:19:54+00	\N	electronic
4869	81	0sk88NvXYCsVStLjbVxMJe	\N	Amnesia	SAY3AM, GERXMVP	31433d6i5sfekboj5hr2fjtnwe7u	2023-10-21 11:19:42+00	\N	phonk, drift phonk
4848	80	1kW3wDjYM7xJMkHjGfzHVN	\N	Nomad	blueberry, Leenucch	31433d6i5sfekboj5hr2fjtnwe7u	2023-10-29 10:37:39+00	\N	drift phonk, phonk
4827	79	33iv4ikGd0KboI6xNPL80i	\N	Dark Side Of The Moon	suisside	31433d6i5sfekboj5hr2fjtnwe7u	2023-11-09 19:29:38+00	\N	emo rap
4871	81	3cuzNdc76mSmqud3HtoJWB	\N	Лифт	PIZZA	31433d6i5sfekboj5hr2fjtnwe7u	2023-10-22 13:06:49+00	\N	rock
4872	82	3pr2J4VXb5h8WhCu4ljify	\N	Секрет	The Limba	31433d6i5sfekboj5hr2fjtnwe7u	2023-10-08 16:08:35+00	\N	alternative rock
4849	80	5xYC48nOppVemY6U5GRGTb	\N	Memories (feat. Kid Cudi)	David Guetta, Kid Cudi	31433d6i5sfekboj5hr2fjtnwe7u	2023-10-29 10:38:56+00	\N	edm
4922	83	2Et07PK8WqRDho5uHV0jnD	\N	Softcore - Speed	Ren	31433d6i5sfekboj5hr2fjtnwe7u	2023-10-07 16:20:33+00	\N	electronic
4921	83	2fDvxV1N7SxQYbWNrN7YJl	\N	JUDAS	SAY3AM	31433d6i5sfekboj5hr2fjtnwe7u	2023-10-07 16:18:21+00	\N	phonk, drift phonk
4899	82	2ygaEtRIboUzHcsKMxdReW	\N	are you falling in love? (moment)	yzuzyw	31433d6i5sfekboj5hr2fjtnwe7u	2023-10-14 17:03:41+00	\N	electronic
4920	83	5EIzNPUfb9OLjnZbKOU2o0	\N	Forever	ilyTOMMY	31433d6i5sfekboj5hr2fjtnwe7u	2023-10-07 16:14:56+00	\N	pop
4919	83	7ItZPW34p9g5hEBCRw5GOK	\N	Yours	EVILDXER	31433d6i5sfekboj5hr2fjtnwe7u	2023-10-07 16:04:23+00	\N	brazilian phonk, phonk
\.


--
-- Data for Name: playlists; Type: TABLE DATA; Schema: public; Owner: maspotify
--

COPY public.playlists (id, spotify_id, name, number, url, status, is_thematic, track_count, created_at, invite_url) FROM stdin;
4	6RsVvDXyb6jqbpj6dHUv0e	TURDOM#90 25/03/2026	90	https://open.spotify.com/playlist/6RsVvDXyb6jqbpj6dHUv0e	listened	f	40	2026-03-31 14:35:52.449124+00	\N
5	7o7pxDALziGuYK37UIQpar	TURDOM#89 11/03/2026	89	https://open.spotify.com/playlist/7o7pxDALziGuYK37UIQpar	listened	f	14	2026-03-31 14:35:53.32337+00	\N
6	7MKlbLktHdXAOukQJEq7cc	TURDOM#88 04/03/2026	88	https://open.spotify.com/playlist/7MKlbLktHdXAOukQJEq7cc	listened	f	26	2026-03-31 14:35:53.99735+00	\N
7	2sQDdGdcYga1nTy4KD8rsl	TURDOM#87 25/02/2026	87	https://open.spotify.com/playlist/2sQDdGdcYga1nTy4KD8rsl	listened	f	21	2026-03-31 14:35:54.883695+00	\N
8	539C7XRafYTVzK9K9XMyKw	TURDOM#86 11/02/2026	86	https://open.spotify.com/playlist/539C7XRafYTVzK9K9XMyKw	listened	f	30	2026-03-31 14:35:55.571143+00	\N
9	7rCUlntTgw8hdqawcDgrDw	TURDOM#85 04/02/2026	85	https://open.spotify.com/playlist/7rCUlntTgw8hdqawcDgrDw	listened	f	28	2026-03-31 14:35:56.32088+00	\N
10	34Bt33bcG3kprPtD1uChl6	TURDOM#84 20/01/2026	84	https://open.spotify.com/playlist/34Bt33bcG3kprPtD1uChl6	listened	f	32	2026-03-31 14:35:57.008496+00	\N
12	78ISAGIIuBWpErokjTnN9t	TURDOM#82 17/12/2025	82	https://open.spotify.com/playlist/78ISAGIIuBWpErokjTnN9t	listened	f	33	2026-03-31 14:35:58.749764+00	\N
13	4LL1jcqj8bcchB1p0nfeG1	TURDOM#81 12/12/2025	81	https://open.spotify.com/playlist/4LL1jcqj8bcchB1p0nfeG1	listened	f	28	2026-03-31 14:35:59.514978+00	\N
15	54XujMDCQFk58u672kJ2wh	TURDOM#79 28/11/2025	79	https://open.spotify.com/playlist/54XujMDCQFk58u672kJ2wh	listened	f	20	2026-03-31 14:36:00.947559+00	\N
16	1XBrcNpG78F4RA2qnoVX4m	TURDOM#78 21/11/2025	78	https://open.spotify.com/playlist/1XBrcNpG78F4RA2qnoVX4m	listened	f	30	2026-03-31 14:36:01.565834+00	\N
17	1p7diQPd1CDD8l1Iy4mhS3	TURDOM#77 14/11/2025	77	https://open.spotify.com/playlist/1p7diQPd1CDD8l1Iy4mhS3	listened	f	40	2026-03-31 14:36:02.336431+00	\N
18	00eRTuTDtpMI9p5xLzVjVu	TURDOM#76 07/11/2025	76	https://open.spotify.com/playlist/00eRTuTDtpMI9p5xLzVjVu	listened	f	21	2026-03-31 14:36:03.076456+00	\N
19	1212GL6wxymkzzVycGGrdQ	TURDOM#75 01/11/2025	75	https://open.spotify.com/playlist/1212GL6wxymkzzVycGGrdQ	listened	f	25	2026-03-31 14:36:03.744485+00	\N
20	56W1LV3wpjL8Bk2ycX8gVy	TURDOM#74 24/10/2025	74	https://open.spotify.com/playlist/56W1LV3wpjL8Bk2ycX8gVy	listened	f	24	2026-03-31 14:36:04.650946+00	\N
21	2PZL6pFPSTMgFvi36Ochkm	TURDOM#73 03/10/2025	73	https://open.spotify.com/playlist/2PZL6pFPSTMgFvi36Ochkm	listened	f	31	2026-03-31 14:36:05.356177+00	\N
22	7aXUirWX249UwMifCNu4wk	TURDOM#72 26/09/2025	72	https://open.spotify.com/playlist/7aXUirWX249UwMifCNu4wk	listened	f	34	2026-03-31 14:36:06.253352+00	\N
23	0vnIgX86xh13Z4lXQyas6x	TURDOM#71 07/09/2025	71	https://open.spotify.com/playlist/0vnIgX86xh13Z4lXQyas6x	listened	f	31	2026-03-31 14:36:07.440901+00	\N
24	2aVxrNECnShuEZTdBIMB1D	TURDOM#70 22/08/2025	70	https://open.spotify.com/playlist/2aVxrNECnShuEZTdBIMB1D	listened	f	38	2026-03-31 14:36:08.376143+00	\N
25	7BD8IlVwJ6ob6Vq6fX7YMd	TURDOM#69 18/07/2025	69	https://open.spotify.com/playlist/7BD8IlVwJ6ob6Vq6fX7YMd	listened	f	30	2026-03-31 14:36:09.152793+00	\N
26	3u6MpXUuCAjJoYt6uIOV5Y	TURDOM#68 11/07/2025	68	https://open.spotify.com/playlist/3u6MpXUuCAjJoYt6uIOV5Y	listened	f	30	2026-03-31 14:36:09.839061+00	\N
27	60KjFRif6FtICtYgvQ0nIo	TURDOM#67 20/06/2025	67	https://open.spotify.com/playlist/60KjFRif6FtICtYgvQ0nIo	listened	f	30	2026-03-31 14:36:10.441792+00	\N
28	2LhqDPIe6rgc3qagS3lFPM	TURDOM#66 06/06/2025	66	https://open.spotify.com/playlist/2LhqDPIe6rgc3qagS3lFPM	listened	f	30	2026-03-31 14:36:11.219166+00	\N
29	3MbA6n6w1wBt6QbSYBKqCJ	TURDOM#65 30/05/2025	65	https://open.spotify.com/playlist/3MbA6n6w1wBt6QbSYBKqCJ	listened	f	25	2026-03-31 14:36:11.842599+00	\N
30	4qfaLtla41oiBqEFInR7kL	TURDOM#64 23/05/2025	64	https://open.spotify.com/playlist/4qfaLtla41oiBqEFInR7kL	listened	f	32	2026-03-31 14:36:12.535696+00	\N
31	4wMlWUu4qKG2fpBKaplasB	TURDOM#62 02/05/2025	62	https://open.spotify.com/playlist/4wMlWUu4qKG2fpBKaplasB	listened	f	29	2026-03-31 14:36:13.279514+00	\N
32	2EjdjUKdBEwrzYxr2F8DEw	TURDOM#61 25/04/2025	61	https://open.spotify.com/playlist/2EjdjUKdBEwrzYxr2F8DEw	listened	f	24	2026-03-31 14:36:14.019263+00	\N
33	577wZh3EiPwvrS9Jn86BeK	TURDOM#60 18/04/2025	60	https://open.spotify.com/playlist/577wZh3EiPwvrS9Jn86BeK	listened	f	22	2026-03-31 14:36:14.558346+00	\N
34	2XXUO1RzKHRBXL2HFVRoF0	TURDOM#59 28/03/2025	59	https://open.spotify.com/playlist/2XXUO1RzKHRBXL2HFVRoF0	listened	f	25	2026-03-31 14:36:15.240974+00	\N
35	2H8JukVJojMG08Sjbn1Dg4	TURDOM#58 21/03/2025	58	https://open.spotify.com/playlist/2H8JukVJojMG08Sjbn1Dg4	listened	f	27	2026-03-31 14:36:15.964587+00	\N
36	1BB51tLA5CdtuGurauxQoe	TURDOM#57 13/03/2025	57	https://open.spotify.com/playlist/1BB51tLA5CdtuGurauxQoe	listened	f	30	2026-03-31 14:36:16.826295+00	\N
37	5KfZIkD4Vk4HmOzJF7thqT	TURDOM#56 07/03/2025	56	https://open.spotify.com/playlist/5KfZIkD4Vk4HmOzJF7thqT	listened	f	23	2026-03-31 14:36:17.408216+00	\N
38	3b8JhRRhRpFpfRiYAGrVeJ	TURDOM#55 28/02/2025	55	https://open.spotify.com/playlist/3b8JhRRhRpFpfRiYAGrVeJ	listened	f	25	2026-03-31 14:36:18.441835+00	\N
39	5GTsklxKp9WgeXR0AXphTi	TURDOM#54 14/02/2025	54	https://open.spotify.com/playlist/5GTsklxKp9WgeXR0AXphTi	listened	f	27	2026-03-31 14:36:19.157799+00	\N
40	0RK4679gUXqvbOVQ6x5QmB	TURDOM#53 07/02/2025	53	https://open.spotify.com/playlist/0RK4679gUXqvbOVQ6x5QmB	listened	f	22	2026-03-31 14:36:19.951377+00	\N
41	4TwxDlGUAAYSJcB0hEqtjS	TURDOM#52 31/01/2025	52	https://open.spotify.com/playlist/4TwxDlGUAAYSJcB0hEqtjS	listened	f	24	2026-03-31 14:36:20.638538+00	\N
42	4qARmduq35bp2VIo7LaJ2i	TURDOM#51 24/01/2025	51	https://open.spotify.com/playlist/4qARmduq35bp2VIo7LaJ2i	listened	f	32	2026-03-31 14:36:21.516684+00	\N
44	1lXKdlS8tDucVfYBwhAevf	TURDOM#49 15/12/2024	49	https://open.spotify.com/playlist/1lXKdlS8tDucVfYBwhAevf	listened	f	17	2026-03-31 14:36:23.427857+00	\N
45	5QnQnANlLUc3lJORfSvYj1	TURDOM#48 08/12/2024	48	https://open.spotify.com/playlist/5QnQnANlLUc3lJORfSvYj1	listened	f	23	2026-03-31 14:36:24.146322+00	\N
46	28JkcEhjjg354da5pMyaix	TURDOM#47 24/11/2024	47	https://open.spotify.com/playlist/28JkcEhjjg354da5pMyaix	listened	f	21	2026-03-31 14:36:24.81089+00	\N
47	6kipN71zIpw0hhWDEKYhqn	TURDOM#46 03/11/2024	46	https://open.spotify.com/playlist/6kipN71zIpw0hhWDEKYhqn	listened	f	34	2026-03-31 14:36:25.477459+00	\N
48	4EIHr4TXiYpH4b9q4Jw9NZ	TURDOM#45 20/10/2024	45	https://open.spotify.com/playlist/4EIHr4TXiYpH4b9q4Jw9NZ	listened	f	27	2026-03-31 14:36:26.347647+00	\N
50	1dD73YzLmEM5Q02mGjgguh	TURDOM#43 22/09/2024	43	https://open.spotify.com/playlist/1dD73YzLmEM5Q02mGjgguh	listened	f	34	2026-03-31 14:36:27.98277+00	\N
51	0kGEUZC2MtLXYlnbcpb8A2	TURDOM#42 18/08/2024	42	https://open.spotify.com/playlist/0kGEUZC2MtLXYlnbcpb8A2	listened	f	25	2026-03-31 14:36:28.745675+00	\N
53	0r4QaSF4aqnN0mWm2RTJeX	TURDOM#40 11/08/2024	40	https://open.spotify.com/playlist/0r4QaSF4aqnN0mWm2RTJeX	listened	f	31	2026-03-31 14:36:30.378471+00	\N
54	6JPeXuPA3TYUqVAnqxfL2Z	TURDOM#39 21/07/2024	39	https://open.spotify.com/playlist/6JPeXuPA3TYUqVAnqxfL2Z	listened	f	31	2026-03-31 14:36:31.22453+00	\N
58	03N4xNrcHMUqwcaV8Owybx	TURDOM#35 09/06/2024	35	https://open.spotify.com/playlist/03N4xNrcHMUqwcaV8Owybx	listened	f	15	2026-03-31 14:36:34.201399+00	\N
59	2pacqFAy08oKBbOaVguIvG	TURDOM#34 26/05/2024	34	https://open.spotify.com/playlist/2pacqFAy08oKBbOaVguIvG	listened	f	21	2026-03-31 14:36:34.829429+00	\N
60	35rjrbplu3LuSyWJ0IqOlV	TURDOM#33 19/05/2024	33	https://open.spotify.com/playlist/35rjrbplu3LuSyWJ0IqOlV	listened	f	23	2026-03-31 14:36:35.548544+00	\N
61	6ZqyAgJuLjhIRxzJTaJvMK	TURDOM#32 05/05/2024	32	https://open.spotify.com/playlist/6ZqyAgJuLjhIRxzJTaJvMK	listened	f	27	2026-03-31 14:36:36.196308+00	\N
62	4mUdVeYY0eSDhE94ir6xJi	TURDOM#31 21/04/2024	31	https://open.spotify.com/playlist/4mUdVeYY0eSDhE94ir6xJi	listened	f	26	2026-03-31 14:36:36.877651+00	\N
63	1dF9sfuf5t7URgqjOv4AmC	TURDOM#30 07/04/2024	30	https://open.spotify.com/playlist/1dF9sfuf5t7URgqjOv4AmC	listened	f	21	2026-03-31 14:36:37.448527+00	\N
64	5yQ5dCJqsMtMvQQOYA5og6	TURDOM#29 31/03/2024	29	https://open.spotify.com/playlist/5yQ5dCJqsMtMvQQOYA5og6	listened	f	28	2026-03-31 14:36:38.154357+00	\N
65	4eySi9oVEXIx7AgktJ2685	TURDOM#28 24/03/2024	28	https://open.spotify.com/playlist/4eySi9oVEXIx7AgktJ2685	listened	f	38	2026-03-31 14:36:39.340161+00	\N
66	06PosbBHNWjx4ucpIyAJdP	TURDOM#27 17/03/2024	27	https://open.spotify.com/playlist/06PosbBHNWjx4ucpIyAJdP	listened	f	37	2026-03-31 14:36:40.363961+00	\N
67	49oaZYrpg2r5p0wyjzeash	TURDOM#26 10/03/2024	26	https://open.spotify.com/playlist/49oaZYrpg2r5p0wyjzeash	listened	f	29	2026-03-31 14:36:41.117831+00	\N
68	7Jzh8wXLV2mTPkaZn0c9b0	TURDOM#25 03/03/2024	25	https://open.spotify.com/playlist/7Jzh8wXLV2mTPkaZn0c9b0	listened	f	31	2026-03-31 14:36:41.942508+00	\N
69	3Z7A3BZYtCzYLgHim9qzyr	TURDOM#24 25/02/2024	24	https://open.spotify.com/playlist/3Z7A3BZYtCzYLgHim9qzyr	listened	f	46	2026-03-31 14:36:42.760276+00	\N
70	1i6nK69gxu6GAP9yQv7GgM	TURDOM#23 18/02/2024	23	https://open.spotify.com/playlist/1i6nK69gxu6GAP9yQv7GgM	listened	f	39	2026-03-31 14:36:43.708875+00	\N
71	1PETrMK75PaSEA8xdPsNa7	TURDOM#22 11/02/2024	22	https://open.spotify.com/playlist/1PETrMK75PaSEA8xdPsNa7	listened	f	26	2026-03-31 14:36:44.416731+00	\N
72	4qIzSFLeScM3RJWJCztV9Q	TURDOM#21 04/02/2024	21	https://open.spotify.com/playlist/4qIzSFLeScM3RJWJCztV9Q	listened	f	27	2026-03-31 14:36:45.155089+00	\N
73	6UZpiMTQ51xmSw3ptQeb2g	TURDOM#20 28/01/2024	20	https://open.spotify.com/playlist/6UZpiMTQ51xmSw3ptQeb2g	listened	f	18	2026-03-31 14:36:45.768437+00	\N
74	0cJfRbvjH9UZZNh0JqJAhZ	TURDOM#19 21/01/2024	19	https://open.spotify.com/playlist/0cJfRbvjH9UZZNh0JqJAhZ	listened	f	8	2026-03-31 14:36:46.378494+00	\N
75	62P2oJLc7xdWn5NUY41qPY	TURDOM#18 14/01/2024	18	https://open.spotify.com/playlist/62P2oJLc7xdWn5NUY41qPY	listened	f	16	2026-03-31 14:36:46.874563+00	\N
76	6MgohZJUp5vAkxaGxRCHoL	TURDOM#17 24/12/2023	17	https://open.spotify.com/playlist/6MgohZJUp5vAkxaGxRCHoL	listened	f	11	2026-03-31 14:36:47.458569+00	\N
77	60OBNjSNR3XN9dTqt4dj74	TURDOM#16 19/11/2023	16	https://open.spotify.com/playlist/60OBNjSNR3XN9dTqt4dj74	listened	f	17	2026-03-31 14:36:48.014745+00	\N
78	0OtJFjl5H7SeHKcF3F3TWL	TURDOM#15 12/11/2023	15	https://open.spotify.com/playlist/0OtJFjl5H7SeHKcF3F3TWL	listened	f	22	2026-03-31 14:36:48.617911+00	\N
79	2yjnYC4wOlB0dZfwO9FV6p	TURDOM#14 05/11/2023	14	https://open.spotify.com/playlist/2yjnYC4wOlB0dZfwO9FV6p	listened	f	41	2026-03-31 14:36:49.273569+00	\N
80	29Tr7pAvYb3uBR1ODeNLfM	TURDOM#13 29/10/2023	13	https://open.spotify.com/playlist/29Tr7pAvYb3uBR1ODeNLfM	listened	f	22	2026-03-31 14:36:49.953813+00	\N
81	1nRup3luQ5iumdpgL7Xgrm	TURDOM#12 22/10/2023	12	https://open.spotify.com/playlist/1nRup3luQ5iumdpgL7Xgrm	listened	f	22	2026-03-31 14:36:50.692613+00	\N
82	6LxcPIJssBKzB8JSbYUljQ	TURDOM#11 15/10/2023	11	https://open.spotify.com/playlist/6LxcPIJssBKzB8JSbYUljQ	listened	f	28	2026-03-31 14:36:51.230769+00	\N
83	6y71MSTEuizcyr7TrQqSLB	TURDOM#10 08/10/2023	10	https://open.spotify.com/playlist/6y71MSTEuizcyr7TrQqSLB	listened	f	23	2026-03-31 14:36:52.268036+00	\N
84	4JHHAmmZCgOB62gDDwNUEj	TURDOM#09 01/10/2023	9	https://open.spotify.com/playlist/4JHHAmmZCgOB62gDDwNUEj	listened	f	18	2026-03-31 14:36:52.878319+00	\N
85	0sbpacTQ4OMBOPzGJrwHtd	TURDOM#08 24/09/2023	8	https://open.spotify.com/playlist/0sbpacTQ4OMBOPzGJrwHtd	listened	f	17	2026-03-31 14:36:53.445859+00	\N
86	6SyxxIBkLIzseP1nrdZoyH	TURDOM#07 03/09/2023	7	https://open.spotify.com/playlist/6SyxxIBkLIzseP1nrdZoyH	listened	f	13	2026-03-31 14:36:53.971407+00	\N
87	4L0hCWG1Yv2RzfeBwLFJQS	TURDOM#06 30/07/2023	6	https://open.spotify.com/playlist/4L0hCWG1Yv2RzfeBwLFJQS	listened	f	23	2026-03-31 14:36:54.45586+00	\N
88	3gaGNLcsyJU5ePR2DwObPB	TURDOM#05 23/07/2023	5	https://open.spotify.com/playlist/3gaGNLcsyJU5ePR2DwObPB	listened	f	19	2026-03-31 14:36:55.512802+00	\N
89	4BiaPURepAvMNuIvmKv2Cl	TURDOM#04 16/07/2023	4	https://open.spotify.com/playlist/4BiaPURepAvMNuIvmKv2Cl	listened	f	16	2026-03-31 14:36:56.10562+00	\N
90	6XBFu5fQvJIrWg9GLR3Dsk	TURDOM#03 09/07/2023	3	https://open.spotify.com/playlist/6XBFu5fQvJIrWg9GLR3Dsk	listened	f	24	2026-03-31 14:36:56.743033+00	\N
91	4LilMcikCVb6C4sWq1BCH0	TURDOM#02 02/07/2023	2	https://open.spotify.com/playlist/4LilMcikCVb6C4sWq1BCH0	listened	f	29	2026-03-31 14:36:57.403892+00	\N
92	2uK5I0yEuDiTvQA6eYqGFp	TURDOM#01 25/06/2023	1	https://open.spotify.com/playlist/2uK5I0yEuDiTvQA6eYqGFp	listened	f	24	2026-03-31 14:36:58.09293+00	\N
11	6GP41ajrSgQF1ibHQPkeSn	TURDOM#83 24/12/2025 - Happy New Year	83	https://open.spotify.com/playlist/6GP41ajrSgQF1ibHQPkeSn	listened	t	31	2026-03-31 14:35:57.796739+00	\N
14	4K89ifufAAgEBU3xujhfd3	TURDOM#80 05/12/2025 - Songs from popular series	80	https://open.spotify.com/playlist/4K89ifufAAgEBU3xujhfd3	listened	t	40	2026-03-31 14:36:00.182574+00	\N
43	5VXuMliSu0VBpeXTkTWEoh	TURDOM#50 12/01/2025 - From Movies/Games/Cartoons	50	https://open.spotify.com/playlist/5VXuMliSu0VBpeXTkTWEoh	listened	t	51	2026-03-31 14:36:22.534844+00	\N
49	4eHKzUkL3nKStyVcZusEqB	TURDOM#44 29/09/2024 - Sion	44	https://open.spotify.com/playlist/4eHKzUkL3nKStyVcZusEqB	listened	t	40	2026-03-31 14:36:27.063341+00	\N
52	6Tq70sdrnvgzRx77K5dIcS	TURDOM#41 18/08/2024 - ndomanovskiy 	41	https://open.spotify.com/playlist/6Tq70sdrnvgzRx77K5dIcS	listened	t	40	2026-03-31 14:36:29.501692+00	\N
55	4s4T79vw3rJzS1zodd9EbW	TURDOM#38 14/07/2024 - Alex	38	https://open.spotify.com/playlist/4s4T79vw3rJzS1zodd9EbW	listened	t	40	2026-03-31 14:36:31.910738+00	\N
56	220vyNKhOh9VgF6VRV01O1	TURDOM#37 23/06/2024 - AkviAkvi	37	https://open.spotify.com/playlist/220vyNKhOh9VgF6VRV01O1	listened	t	38	2026-03-31 14:36:32.828014+00	\N
57	4nstDoIFqiGLmZNoZo6LLB	TURDOM#36 16/06/2024 - Constantine	36	https://open.spotify.com/playlist/4nstDoIFqiGLmZNoZo6LLB	listened	t	20	2026-03-31 14:36:33.605424+00	\N
2	7dSN8alCVVkbzr04ynDEjU	TURDOM#91 18/03/2026	91	https://open.spotify.com/playlist/7dSN8alCVVkbzr04ynDEjU	upcoming	f	27	2026-03-31 14:35:26.180409+00	https://open.spotify.com/playlist/7dSN8alCVVkbzr04ynDEjU?si=16dd67f3c2d34200&pt=3a047f42028e034ba1a79ecae5ed3e9a
\.


--
-- Data for Name: ratings; Type: TABLE DATA; Schema: public; Owner: maspotify
--

COPY public.ratings (id, session_track_id, telegram_id, rhymes, structure, style, charisma, vibe, rated_at) FROM stdin;
\.


--
-- Data for Name: session_participants; Type: TABLE DATA; Schema: public; Owner: maspotify
--

COPY public.session_participants (id, session_id, telegram_id, joined_at) FROM stdin;
\.


--
-- Data for Name: session_tracks; Type: TABLE DATA; Schema: public; Owner: maspotify
--

COPY public.session_tracks (id, session_id, spotify_track_id, title, artist, album, cover_url, added_by_spotify_id, "position", vote_result, created_at) FROM stdin;
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: maspotify
--

COPY public.sessions (id, playlist_spotify_id, playlist_name, started_at, ended_at, status) FROM stdin;
\.


--
-- Data for Name: spotify_tokens; Type: TABLE DATA; Schema: public; Owner: maspotify
--

COPY public.spotify_tokens (id, refresh_token, access_token, expires_at) FROM stdin;
1	AQD6fqFqzBNgN-MOQErEWhlb4sYvArOPq8jC2hiuH1Z6Sw91-J3mZ8wBZfv05eX5Wzs5Z6Elh9veJVQBfyzn5OzJdnXhyhODIHZxlLp0q2F6B8AQieyOAxUEsGEA2yshXik	BQBMkJVbf2vxUR7ztaEIcWuWlCO_G_-kFRqeaCeK6OHmri7y-2cPTiPkTxlw0jTYSYWSB95nRV82xjApAo2iLaq9-vxbOZYlygHrZrgzgEPeo0qNgT2TK2xv_YJKSNDR13_m35dK6RZYk2dxBj18uf01wkZf2kT5fq-xcpTNv4nPdQPhjAXGifi8JHmkz1SPmOeTW_AymqS2ztUltsF_4frhQGxSUR3wQg1ugRO1MFwp63MaeZibdGrui_wUEQhIJC8jJUwxKScDNweWiCR_O3AJAIcdN1nT3FaL3ACXCvI2W576hQ4Pl0JYBA	2026-03-31 14:29:57.492324+00
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: maspotify
--

COPY public.users (id, telegram_id, telegram_name, spotify_id, is_admin, created_at, telegram_username) FROM stdin;
1	447516681	Nikita Domanovskiy	1qzcdqlwqtm8lnthmvh2a70p9	t	2026-03-31 13:31:47.297756+00	ndomanovskiy
2	456091644	Constantin	313neyxbfwxtbi2t52gjvliqxisa	f	2026-03-31 13:31:48.402495+00	k_turanoff
7	206499188	Aleksandr	31pd6hnytykuevog22xwj5yn2qjy	f	2026-03-31 13:54:59.543518+00	alex_ndk
3	1262596721	игорь	31ghi62vkgnlb4wqr6muaisx7ldi	f	2026-03-31 13:31:50.315072+00	Agosev
14	0	Арсений	31433d6i5sfekboj5hr2fjtnwe7u	f	2026-04-01 08:17:04.533823+00	Zero0netw02
\.


--
-- Data for Name: votes; Type: TABLE DATA; Schema: public; Owner: maspotify
--

COPY public.votes (id, session_track_id, telegram_id, vote, voted_at) FROM stdin;
\.


--
-- Name: playlist_tracks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: maspotify
--

SELECT pg_catalog.setval('public.playlist_tracks_id_seq', 5107, true);


--
-- Name: playlists_id_seq; Type: SEQUENCE SET; Schema: public; Owner: maspotify
--

SELECT pg_catalog.setval('public.playlists_id_seq', 92, true);


--
-- Name: ratings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: maspotify
--

SELECT pg_catalog.setval('public.ratings_id_seq', 2, true);


--
-- Name: session_participants_id_seq; Type: SEQUENCE SET; Schema: public; Owner: maspotify
--

SELECT pg_catalog.setval('public.session_participants_id_seq', 1, false);


--
-- Name: session_tracks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: maspotify
--

SELECT pg_catalog.setval('public.session_tracks_id_seq', 30, true);


--
-- Name: sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: maspotify
--

SELECT pg_catalog.setval('public.sessions_id_seq', 4, true);


--
-- Name: spotify_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: maspotify
--

SELECT pg_catalog.setval('public.spotify_tokens_id_seq', 1, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: maspotify
--

SELECT pg_catalog.setval('public.users_id_seq', 14, true);


--
-- Name: votes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: maspotify
--

SELECT pg_catalog.setval('public.votes_id_seq', 61, true);


--
-- Name: playlist_tracks playlist_tracks_pkey; Type: CONSTRAINT; Schema: public; Owner: maspotify
--

ALTER TABLE ONLY public.playlist_tracks
    ADD CONSTRAINT playlist_tracks_pkey PRIMARY KEY (id);


--
-- Name: playlist_tracks playlist_tracks_playlist_id_spotify_track_id_key; Type: CONSTRAINT; Schema: public; Owner: maspotify
--

ALTER TABLE ONLY public.playlist_tracks
    ADD CONSTRAINT playlist_tracks_playlist_id_spotify_track_id_key UNIQUE (playlist_id, spotify_track_id);


--
-- Name: playlists playlists_pkey; Type: CONSTRAINT; Schema: public; Owner: maspotify
--

ALTER TABLE ONLY public.playlists
    ADD CONSTRAINT playlists_pkey PRIMARY KEY (id);


--
-- Name: playlists playlists_spotify_id_key; Type: CONSTRAINT; Schema: public; Owner: maspotify
--

ALTER TABLE ONLY public.playlists
    ADD CONSTRAINT playlists_spotify_id_key UNIQUE (spotify_id);


--
-- Name: ratings ratings_pkey; Type: CONSTRAINT; Schema: public; Owner: maspotify
--

ALTER TABLE ONLY public.ratings
    ADD CONSTRAINT ratings_pkey PRIMARY KEY (id);


--
-- Name: ratings ratings_session_track_id_telegram_id_key; Type: CONSTRAINT; Schema: public; Owner: maspotify
--

ALTER TABLE ONLY public.ratings
    ADD CONSTRAINT ratings_session_track_id_telegram_id_key UNIQUE (session_track_id, telegram_id);


--
-- Name: session_participants session_participants_pkey; Type: CONSTRAINT; Schema: public; Owner: maspotify
--

ALTER TABLE ONLY public.session_participants
    ADD CONSTRAINT session_participants_pkey PRIMARY KEY (id);


--
-- Name: session_participants session_participants_session_id_telegram_id_key; Type: CONSTRAINT; Schema: public; Owner: maspotify
--

ALTER TABLE ONLY public.session_participants
    ADD CONSTRAINT session_participants_session_id_telegram_id_key UNIQUE (session_id, telegram_id);


--
-- Name: session_tracks session_tracks_pkey; Type: CONSTRAINT; Schema: public; Owner: maspotify
--

ALTER TABLE ONLY public.session_tracks
    ADD CONSTRAINT session_tracks_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: maspotify
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: spotify_tokens spotify_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: maspotify
--

ALTER TABLE ONLY public.spotify_tokens
    ADD CONSTRAINT spotify_tokens_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: maspotify
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_telegram_id_key; Type: CONSTRAINT; Schema: public; Owner: maspotify
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_telegram_id_key UNIQUE (telegram_id);


--
-- Name: votes votes_pkey; Type: CONSTRAINT; Schema: public; Owner: maspotify
--

ALTER TABLE ONLY public.votes
    ADD CONSTRAINT votes_pkey PRIMARY KEY (id);


--
-- Name: votes votes_session_track_id_telegram_id_key; Type: CONSTRAINT; Schema: public; Owner: maspotify
--

ALTER TABLE ONLY public.votes
    ADD CONSTRAINT votes_session_track_id_telegram_id_key UNIQUE (session_track_id, telegram_id);


--
-- Name: playlist_tracks playlist_tracks_playlist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: maspotify
--

ALTER TABLE ONLY public.playlist_tracks
    ADD CONSTRAINT playlist_tracks_playlist_id_fkey FOREIGN KEY (playlist_id) REFERENCES public.playlists(id) ON DELETE CASCADE;


--
-- Name: ratings ratings_session_track_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: maspotify
--

ALTER TABLE ONLY public.ratings
    ADD CONSTRAINT ratings_session_track_id_fkey FOREIGN KEY (session_track_id) REFERENCES public.session_tracks(id) ON DELETE CASCADE;


--
-- Name: session_participants session_participants_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: maspotify
--

ALTER TABLE ONLY public.session_participants
    ADD CONSTRAINT session_participants_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.sessions(id) ON DELETE CASCADE;


--
-- Name: session_tracks session_tracks_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: maspotify
--

ALTER TABLE ONLY public.session_tracks
    ADD CONSTRAINT session_tracks_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.sessions(id) ON DELETE CASCADE;


--
-- Name: votes votes_session_track_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: maspotify
--

ALTER TABLE ONLY public.votes
    ADD CONSTRAINT votes_session_track_id_fkey FOREIGN KEY (session_track_id) REFERENCES public.session_tracks(id) ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: maspotify
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict IEyNgchqznkRi6yHNtv2yACLWBPIcFoFv7V3qa16vQyMYUdnbbw4otAh0rxD4b6

